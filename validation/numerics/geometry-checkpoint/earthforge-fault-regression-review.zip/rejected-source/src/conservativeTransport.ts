import { exactLengthScale } from './exactLength';
/** Edge costs are rounded at 1e-12 of the maximum parcel weight; BigInt duals
 * give an exact optimum for that quantized objective with deterministic node ties.
 * Within the selected stencil, the raw objective gap is at most N*q*maxWeight,
 * apart from floating cost-evaluation roundoff. Tiny weights retain their parcels
 * even when their costs quantize to zero. Quantization boundaries and changes in
 * source order can still change a tied solution.
 *
 * Conservative categorical remapping. Retained hanging-wall packets are indivisible
 * parcels, each placed once in a distinct hanging-wall cell; no rescaling or
 * cross-bed mixing. Optional heights restrict destinations by their capacity.
 * Optional positive weights scale each parcel's squared placement distance.
 * Sparse minimum-cost matching minimizes quantized weighted squared distance to
 * the flow targets, first within two cells of each rounded target, then three if needed.
 * The selected radius is reported; failure at three cells throws.
 * An infeasible local assignment throws without mutating the caller's state.
 */
export interface TransportParcel { source: number; materialHeights?: readonly number[]; height?: number; weight?: number; i: number; k: number; targetI?: number; targetK?: number }
export interface TransportAssignment { destination: Int32Array; displaced: number; maxOffsetCells: number; radius: 2 | 3 }
const stencils = new Map<number, [number, number][]>();
for (const radius of [2, 3]) {
  const offsets: [number, number][] = [];
  for (let dk = -radius; dk <= radius; dk++) for (let di = -radius; di <= radius; di++) if (di * di + dk * dk <= radius * radius) offsets.push([di, dk]);
  offsets.sort((a, b) => a[0] ** 2 + a[1] ** 2 - b[0] ** 2 - b[1] ** 2 || a[1] - b[1] || a[0] - b[0]);
  stencils.set(radius, offsets);
}
export class PlacementError extends Error {}

export function assignTransport(nx: number, nz: number, allowed: Uint8Array, parcels: TransportParcel[], capacity?: Float64Array, capacityLengths?: readonly (readonly number[] | undefined)[], edgeCost?: (parcel: number, destination: number) => number): TransportAssignment {
  try { return solveTransport(nx, nz, allowed, parcels, 2, capacity, capacityLengths, edgeCost); }
  catch (error) {
    if (!(error instanceof PlacementError)) throw error;
    return solveTransport(nx, nz, allowed, parcels, 3, capacity, capacityLengths, edgeCost);
  }
}
function solveTransport(nx: number, nz: number, allowed: Uint8Array, parcels: TransportParcel[], radius: 2 | 3, capacity?: Float64Array, capacityLengths?: readonly (readonly number[] | undefined)[], edgeCost?: (parcel: number, destination: number) => number): TransportAssignment {
  if (!Number.isInteger(nx) || !Number.isInteger(nz) || nx < 1 || nz < 1 || allowed.length !== nx * nz) throw Error('Invalid transport grid');
  if (capacity && (capacity.length !== nx * nz || capacity.some(c => !Number.isFinite(c) || c < 0))) throw Error('Invalid destination capacity');
  if (parcels.some(p => p.height !== undefined && (!(p.height > 0) || !Number.isFinite(p.height)))) throw Error('Invalid parcel height');
  if (parcels.some(p => p.weight !== undefined && (!(p.weight > 0) || !Number.isFinite(p.weight)))) throw Error('Invalid parcel weight');
  if (capacityLengths && (!capacity || capacityLengths.length !== allowed.length || capacityLengths.some(c => c?.some(x => !(x > 0) || !Number.isFinite(x))))) throw Error('Invalid exact destination capacity');
  if (parcels.some(p => p.materialHeights && (!p.materialHeights.length || p.materialHeights.some(x => !(x > 0) || !Number.isFinite(x))))) throw Error('Invalid exact parcel support');
  const exact = capacityLengths ? exactLengthScale([...capacityLengths.flatMap((c,n) => c ?? [capacity![n]]), ...parcels.flatMap(p => p.materialHeights ?? [p.height ?? 1])]) : undefined;
  const total = (c: readonly number[]) => c.reduce((s,x) => s + exact!.units(x), 0n);
  const exactCapacity = exact ? capacityLengths!.map((c,n) => total(c ?? [capacity![n]])) : undefined;
  const exactSource = exact ? parcels.map(p => total(p.materialHeights ?? [p.height ?? 1])) : undefined;
  const owner = new Int32Array(allowed.length).fill(-1), destination = new Int32Array(parcels.length).fill(-1);
  const pending: number[] = [], u: bigint[] = Array(parcels.length).fill(0n), v: bigint[] = Array(allowed.length).fill(0n);
  // Relative scaling keeps common positive weight rescaling immaterial.
  const maxWeight = parcels.reduce((m, p) => Math.max(m, p.weight ?? 1), 0) || 1;
  const quantum = 1e-12;
  const fits = (p: number, n: number) => !!allowed[n] && (exactCapacity ? exactSource![p] <= exactCapacity[n] : !capacity || (parcels[p].height ?? 1) <= capacity[n]);
  const cached = edgeCost ? new Map<number, bigint>() : undefined;
  const cost = (p: number, i: number, k: number) => {
    const point = parcels[p], n = k * nx + i, key = p * allowed.length + n;
    const found = cached?.get(key); if (found !== undefined) return found;
    // Normalize default weights before multiplication, preserving finite
    // objectives even when a valid raw weight is near Number.MAX_VALUE.
    const raw = edgeCost ? edgeCost(p, n) : 0;
    if (edgeCost && (!Number.isFinite(raw) || raw < 0)) throw Error('Invalid transport edge cost');
    const normalized = edgeCost ? raw / maxWeight : ((point.weight ?? 1) / maxWeight) * ((i - (point.targetI ?? point.i)) ** 2 + (k - (point.targetK ?? point.k)) ** 2);
    const quantized = BigInt(Math.round(normalized / quantum));
    cached?.set(key, quantized); return quantized;
  };
  for (let p = 0; p < parcels.length; p++) {
    const { i, k, targetI = i, targetK = k } = parcels[p];
    if (!Number.isInteger(i) || !Number.isInteger(k) || i < 0 || i >= nx || k < 0 || k >= nz) throw Error('Boundary parcels must be accounted before local transport');
    if (!Number.isFinite(targetI) || !Number.isFinite(targetK) || Math.abs(targetI - i) > 0.500000001 || Math.abs(targetK - k) > 0.500000001) throw Error('Invalid rounded transport target');
    if (edgeCost) {
      // Nonprefix free support can put the minimum away from the rounded
      // row-top target. Seed a feasible dual using the true stencil minimum.
      let best = -1, bestCost: bigint | undefined;
      for (const [di, dk] of stencils.get(radius)!) {
        const ni = i + di, nk = k + dk;
        if (ni < 0 || ni >= nx || nk < 0 || nk >= nz) continue;
        const n = nk * nx + ni; if (!fits(p, n)) continue;
        const c = cost(p, ni, nk);
        if (bestCost === undefined || c < bestCost || (c === bestCost && n < best)) { best = n; bestCost = c; }
      }
      if (best < 0) throw new PlacementError(`No feasible destination for parcel ${p} within ${radius} cells`);
      if (owner[best] < 0) { owner[best] = p; destination[p] = best; }
      else if (bestCost! < cost(owner[best], best % nx, Math.floor(best / nx))) {
        pending.push(owner[best]); destination[owner[best]] = -1; owner[best] = p; destination[p] = best;
      } else pending.push(p);
    } else {
      // The accepted half-cell tolerance can straddle a rounding boundary.
      // Preserve legacy default initialization and its deterministic ties.
      const nearestI = Math.max(0, Math.min(nx - 1, Math.round(targetI))), nearestK = Math.max(0, Math.min(nz - 1, Math.round(targetK)));
      const n = nearestK * nx + nearestI;
      if (fits(p, n) && owner[n] < 0) { owner[n] = p; destination[p] = n; }
      else if (fits(p, n) && cost(p, nearestI, nearestK) < cost(owner[n], nearestI, nearestK)) {
        pending.push(owner[n]); destination[owner[n]] = -1; owner[n] = p; destination[p] = n;
      } else pending.push(p);
    }
  }

  // Exact nearest targets are an optimal partial matching. Maintain feasible
  // dual potentials for shortest augmenting paths (nonnegative reduced costs).
  for (let p = 0; p < parcels.length; p++) if (destination[p] >= 0) u[p] = cost(p, destination[p] % nx, Math.floor(destination[p] / nx));
  const seenP = new Int32Array(parcels.length), seenN = new Int32Array(allowed.length), doneN = new Int32Array(allowed.length);
  const distP: bigint[] = Array(parcels.length).fill(0n), distN: bigint[] = Array(allowed.length).fill(0n), parent = new Int32Array(allowed.length);
  let stamp = 0;
  for (const root of pending) {
    stamp++;
    const touchedP = [root], touchedN: number[] = [], heap: [number, bigint][] = [];
    const precedes = (a: [number,bigint],b: [number,bigint]) => a[1] < b[1] || (a[1] === b[1] && a[0] < b[0]);
    const push = (n: number, d: bigint) => {
      let j = heap.length; heap.push([n, d]);
      while (j > 0) { const p = (j - 1) >> 1; if (!precedes([n,d],heap[p])) break; heap[j] = heap[p]; j = p; }
      heap[j] = [n, d];
    };
    const pop = () => {
      const first = heap[0], last = heap.pop()!;
      if (heap.length) {
        let j = 0;
        while (2 * j + 1 < heap.length) { let c = 2 * j + 1; if (c + 1 < heap.length && precedes(heap[c + 1],heap[c])) c++; if (!precedes(heap[c],last)) break; heap[j] = heap[c]; j = c; }
        heap[j] = last;
      }
      return first;
    };
    const relax = (p: number) => {
      const target = parcels[p];
      for (const [di, dk] of stencils.get(radius)!) {
        const i = target.i + di, k = target.k + dk;
        if (i < 0 || i >= nx || k < 0 || k >= nz) continue;
        const n = k * nx + i;
        if (!fits(p, n) || doneN[n] === stamp) continue;
        const reduced = cost(p, i, k) - u[p] - v[n];
        if (reduced < 0n) throw Error('Invalid transport matching potential');
        const d = distP[p] + reduced;
        if (seenN[n] !== stamp || d < distN[n]) {
          if (seenN[n] !== stamp) { seenN[n] = stamp; touchedN.push(n); }
          distN[n] = d; parent[n] = p; push(n, d);
        }
      }
    };
    seenP[root] = stamp; distP[root] = 0n; relax(root);
    let end = -1, shortest = 0n;
    while (heap.length) {
      const [n, d] = pop();
      if (doneN[n] === stamp || d > distN[n]) continue;
      doneN[n] = stamp;
      if (owner[n] < 0) { end = n; shortest = d; break; }
      const p = owner[n];
      if (seenP[p] !== stamp) { seenP[p] = stamp; distP[p] = d; touchedP.push(p); relax(p); }
    }
    if (end < 0) throw new PlacementError(`Conservative thrust transport cannot place parcel ${root} within ${radius} cells; no sediment was discarded`);
    for (const p of touchedP) u[p] += shortest > distP[p] ? shortest - distP[p] : 0n;
    for (const n of touchedN) v[n] -= shortest > distN[n] ? shortest - distN[n] : 0n;
    for (let n = end; n >= 0;) {
      const p = parent[n], old = destination[p]; owner[n] = p; destination[p] = n; n = old;
    }
  }
  let displaced = 0, maxOffsetCells = 0;
  for (let p = 0; p < parcels.length; p++) {
    const n = destination[p], { i, k } = parcels[p], d = Math.hypot(n % nx - i, Math.floor(n / nx) - k);
    displaced += Number(d > 0); maxOffsetCells = Math.max(maxOffsetCells, d);
  }
  return { destination, displaced, maxOffsetCells, radius };
}
