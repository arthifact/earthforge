import { exactLengthScale } from './exactLength';
import { append, emptyLayer, layerLengths, withLayerLengths, type Column, type Layer } from './strata';

export interface SupportedPart { part: Layer; localLengths: readonly number[] }
export interface MovingSource extends SupportedPart { packedLengths: readonly number[] }
export interface FreeInterval { lo: readonly number[]; lengths: readonly number[] }
export interface PhysicalCellSupport {
  moving: Column;
  sources: MovingSource[];
  fixed: SupportedPart[];
  free: FreeInterval[];
  capacityLengths: readonly number[];
}
export interface AssignedSource extends SupportedPart { sourceCell: number; parcel: number }
export interface PlacedSource { source: AssignedSource; moved: Layer; destinationLocalTop: number }

export function lengthNumber(terms: readonly number[]) {
  const s = exactLengthScale(terms.map(Math.abs));
  const n = terms.reduce((n, h) => n + (h < 0 ? -s.units(-h) : s.units(h)), 0n);
  return n < 0n ? -s.number(-n) : s.number(n);
}
export function lengthTerms(terms: readonly number[]) {
  const s = exactLengthScale(terms.map(Math.abs));
  const n = terms.reduce((n, h) => n + (h < 0 ? -s.units(-h) : s.units(h)), 0n);
  if (n < 0n) throw Error('Negative physical support position');
  return s.chunks(n);
}

/** Physical-center fault classification, retaining the existing column-cut
 * approximation in x. Each stationary portion keeps its original storage
 * support. All interval complements are exact; no positive support is dropped.
 * Width-dependent clipping of an inclined interface is outside this contract. */
export function splitPhysicalCell(cell: Column, cellTop: number, x: number, h: number, depthAt: (x: number) => number): PhysicalCellSupport {
  const depths = cell.map(p => depthAt(x + p.offsetX));
  if (!(h > 0) || !Number.isFinite(cellTop) || !Number.isFinite(x) || depths.some(d => !Number.isFinite(d))) throw Error('Invalid physical cell geometry');
  const scale = exactLengthScale([h, Math.abs(cellTop), ...cell.flatMap(p => [...layerLengths(p), Math.abs(p.offsetZ)]), ...depths.map(Math.abs)]);
  const signed = (x: number) => x < 0 ? -scale.units(-x) : scale.units(x);
  const moving: Column = [], sources: MovingSource[] = [], fixed: SupportedPart[] = [];
  const gaps: { lo: bigint; length: bigint }[] = [];
  let local = 0n, packed = 0n;
  for (const [j, p] of cell.entries()) {
    const n = layerLengths(p).reduce((n, z) => n + scale.units(z), 0n);
    const raw = signed(depths[j]) - signed(cellTop) - local - signed(p.offsetZ);
    const cut = raw < 0n ? 0n : raw > n ? n : raw;
    const keep = n - cut;
    let mobile: Layer | undefined, stationary: Layer | undefined;
    if (cut > 0n) mobile = withLayerLengths(p, scale.chunks(cut));
    if (keep > 0n) stationary = withLayerLengths(p, scale.chunks(keep));
    if (mobile && stationary) {
      const small = cut <= keep ? mobile : stationary, large = cut <= keep ? stationary : mobile;
      small.solid = p.solid * (small.height / p.height); large.solid = p.solid - small.solid;
    }
    if (mobile) {
      sources.push({ part: mobile, localLengths: scale.chunks(local), packedLengths: scale.chunks(packed) });
      moving.push({ ...mobile, offsetZ: p.offsetZ + scale.number(local - packed) });
      const last = gaps.at(-1);
      if (last && last.lo + last.length === local) last.length += cut;
      else gaps.push({ lo: local, length: cut });
      packed += cut;
    }
    if (stationary) fixed.push({ part: stationary, localLengths: scale.chunks(local + cut) });
    local += n;
  }
  if (local !== scale.units(h)) throw Error('Physical cell support does not exactly fill the cell');
  return { moving, sources, fixed, free: gaps.map(g => ({ lo: scale.chunks(g.lo), lengths: scale.chunks(g.length) })), capacityLengths: scale.chunks(packed) };
}

/** Fill only the complement of the immutable stationary intervals. An assigned
 * source may be sliced by disjoint free intervals; physical movement is evaluated
 * for each final child, and its exact source local support remains explicit. */
export function placePhysicalCell(support: PhysicalCellSupport, assigned: AssignedSource[], h: number,
  move: (source: AssignedSource, destinationLocalTop: number) => Layer, markNumerical: boolean) {
  const terms = [h, ...support.fixed.flatMap(q => [...q.localLengths, ...layerLengths(q.part)]), ...support.free.flatMap(q => [...q.lo, ...q.lengths]), ...assigned.flatMap(q => [...q.localLengths, ...layerLengths(q.part)])];
  const scale = exactLengthScale(terms), sum = (xs: readonly number[]) => xs.reduce((n, z) => n + scale.units(z), 0n);
  const placed: { lo: bigint; part: Layer }[] = support.fixed.map(q => ({ lo: sum(q.localLengths), part: q.part }));
  const fragments: { source: AssignedSource; original: number; lo: bigint }[] = [], numerical: [number, number][] = [];
  const assignedLengths = assigned.map(q => sum(layerLengths(q.part)));
  let piece = 0, consumed = 0n;
  for (const gap of support.free) {
    let lo = sum(gap.lo), remaining = sum(gap.lengths);
    while (remaining > 0n && piece < assigned.length) {
      const original = assigned[piece], available = assignedLengths[piece] - consumed;
      const take = available < remaining ? available : remaining;
      if (!(take > 0n)) throw Error('Nonpositive physical support intersection');
      fragments.push({ original: piece, lo, source: { ...original,
        part: { ...withLayerLengths(original.part, scale.chunks(take)), solid: 0 },
        localLengths: scale.chunks(sum(original.localLengths) + consumed) } });
      lo += take; remaining -= take; consumed += take;
      if (consumed === assignedLengths[piece]) { piece++; consumed = 0n; }
    }
    if (remaining > 0n) {
      placed.push({ lo, part: withLayerLengths(emptyLayer(-1, 0), scale.chunks(remaining)) });
      if (markNumerical) numerical.push([scale.number(lo), scale.number(lo + remaining)]);
    }
  }
  if (piece < assigned.length || consumed !== 0n) throw Error('Physical free intervals cannot hold assigned exact support');
  const groups = assigned.map(() => [] as typeof fragments);
  for (const f of fragments) groups[f.original].push(f);
  for (const [j, group] of groups.entries()) {
    group.sort((a, b) => { const x = sum(layerLengths(a.source.part)), y = sum(layerLengths(b.source.part)); return x < y ? -1 : x > y ? 1 : 0; });
    let grains = assigned[j].part.solid;
    for (const [k, f] of group.entries()) {
      f.source.part.solid = k + 1 === group.length ? grains : assigned[j].part.solid * (f.source.part.height / assigned[j].part.height);
      if (!(f.source.part.solid >= 0) || !Number.isFinite(f.source.part.solid)) throw Error('Invalid physical support grain split');
      grains -= f.source.part.solid;
    }
  }
  const transfers: PlacedSource[] = [];
  for (const f of fragments) {
    const top = scale.number(f.lo), moved = move(f.source, top);
    if (sum(layerLengths(moved)) !== sum(layerLengths(f.source.part)) || moved.solid !== f.source.part.solid) throw Error('Physical movement changed child support or grains');
    placed.push({ lo: f.lo, part: moved }); transfers.push({ source: f.source, moved, destinationLocalTop: top });
  }
  placed.sort((a, b) => a.lo < b.lo ? -1 : a.lo > b.lo ? 1 : 0);
  let end = 0n; const column: Column = [];
  for (const q of placed) {
    if (q.lo !== end) throw Error('Physical reconstruction overlaps or leaves a storage gap');
    end += sum(layerLengths(q.part)); append(column, q.part);
  }
  if (end !== scale.units(h)) throw Error('Physical reconstruction changes cell support');
  return { column, numerical, transfers };
}
