import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
const root=process.env.EARTHFORGE_SOURCE??fileURLToPath(new URL('../',import.meta.url));
const bundle=await build({stdin:{contents:"export * from './src/conservativeTransport.ts'",resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const{assignTransport}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].contents).toString('base64'));
test('default matcher normalizes extreme finite weights before multiplying displacement',()=>{
  const allowed=Uint8Array.from([0,0,1]);
  for(const weight of [1,Number.MAX_VALUE,Number.MIN_VALUE]){
    const parcels=[{source:0,i:0,k:0,weight}],before=structuredClone(parcels);
    assert.equal(assignTransport(3,1,allowed,parcels).destination[0],2);assert.deepEqual(parcels,before);
  }
});
test('custom edge cost validation still rejects nonfinite and negative values',()=>{
  for(const value of [NaN,Infinity,-Infinity,-1])assert.throws(()=>assignTransport(1,1,Uint8Array.from([1]),[{source:0,i:0,k:0}],undefined,undefined,()=>value),/Invalid transport edge cost/);
});
