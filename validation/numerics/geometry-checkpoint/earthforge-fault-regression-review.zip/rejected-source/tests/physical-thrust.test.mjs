import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
const root=fileURLToPath(new URL('../',import.meta.url));
async function load(force=false, slow=false) {
  const built=await build({stdin:{contents:"export * from './src/basin.ts';export * from './src/strata.ts';export * from './src/sedimentBudget.ts';export * from './src/physicalThrustSupport.ts';export * from './src/exactLength.ts';export * from './src/conservativeTransport.ts';export * from './src/capacityTransport.ts';",resolveDir:root},bundle:true,platform:'node',format:'esm',write:false,plugins:force||slow?[{name:'force-capacity',setup(b){b.onLoad({filter:/\/src\/basin\.ts$/},()=>({contents:readFileSync(root+'src/basin.ts','utf8').replace(force ? 'try { assignment = assignTransport(nx, nz, allowed, parcels, capacity, capacityLengths, edgeCost); }' : '__no_forcing__',"try { throw new PlacementError('analytical fixture'); }").replace(slow ? 'if (support.free.length === 1)' : '__no_slow_path__','if (false)'),loader:'ts',resolveDir:root+'src'}));}}]:[]});
  return import('data:text/javascript;base64,'+Buffer.from(built.outputFiles[0].contents).toString('base64'));
}
const api=await load(),forced=await load(true),slow=await load(false,true),near=(a,b,t=1e-9)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const bed=(id,height,oz=0,ox=0)=>({bed:id,height,solid:.4*height,fraction:.2+.1*id,burial:70+id,loading:30+id,offsetX:ox,offsetZ:oz});
function exact(xs){const s=api.exactLengthScale(xs);return {scale:s,units:xs.reduce((n,x)=>n+s.units(x),0n)};}
function tagged(columns,h,id=0){let grain=0,mx=0,mz=0;const pieces=[];for(let i=0;i<columns.length;i++){let top=0;for(const p of columns[i]){if(p.bed===id){grain+=p.solid;mx+=p.solid*(-2000+i*h+p.offsetX);mz+=p.solid*(top+p.height/2+p.offsetZ);pieces.push({i,top,p});}top+=p.height;}}return{grain,x:mx/grain,z:mz/grain,pieces};}
test('physical HW cut follows flat-fault material coordinates across storage gauges, grids and slip signs',()=>{
  for(const h of [40,20,10])for(const sign of [-1,1])for(const physicalTop of [5*h,5.5*h,6*h])for(const storageTop of [4*h,5*h,6*h,7*h]) {
    const nx=14,nz=12,i=6,columns=Array.from({length:nx},()=>[api.emptyLayer(-1,9*h),api.emptyLayer(-2,3*h)]);
    columns[i]=[api.emptyLayer(-1,storageTop),bed(0,h,physicalTop-storageTop),api.emptyLayer(-1,9*h-storageTop-h),api.emptyLayer(-2,3*h)].filter(p=>p.height>0);
    const state={...api.rasterize(columns,nz,h),columns,nx,nz,h,beds:[{carbonate:false}]},before=structuredClone(state),old=tagged(columns,h);
    const out=api.remapThrust(state,[[-3000,6*h],[0,6*h]],sign*h,[0],true),result=api.columnsFromRaster(out,nx,nz,h),now=tagged(result,h);
    const fraction=Math.max(0,Math.min(1,(6*h-physicalTop)/h));
    near(now.grain,old.grain);near(now.x,old.x+sign*h*fraction);near(now.z,old.z);assert.deepEqual(state,before);
    near(out.transfers.filter(t=>t.source.bed===0&&!t.incoming).reduce((s,t)=>s+t.source.solid,0),old.grain*fraction);
    for(const t of out.transfers.filter(t=>t.source.bed===0)){assert.equal(t.source.fraction,.2);assert.equal(t.source.burial,70);assert.equal(t.source.loading,30);near(t.moved.offsetZ+t.destinationLocalTop+Math.floor(t.destinationCell/nx)*h,t.source.offsetZ+t.sourceLocalTop+Math.floor(t.sourceCell/nx)*h);}
    const fw=now.pieces.filter(q=>q.i===i);if(fraction<1){near(fw.reduce((s,q)=>s+q.p.solid,0),old.grain*(1-fraction));near(fw[0].top,storageTop+h*fraction);assert.equal(fw[0].p.offsetZ,physicalTop-storageTop);}
    assert.ok(api.assessBudget(api.inventoryOf(state),api.inventoryOf({...state,...out,columns:result}),out.flux).closed);
  }
});
test('zero slip preserves all support, offset and constituent state',()=>{
  const h=20,nx=5,nz=6,columns=Array.from({length:nx},()=>[api.emptyLayer(-1,20),bed(0,60,17),api.emptyLayer(-2,40)]),state={...api.rasterize(columns,nz,h),columns,nx,nz,h,beds:[{carbonate:false}]};
  const out=api.remapThrust(state,[[-3000,55],[0,55]],0,[3],true);for(const key of ['grid','solid','sandFraction','burial','effectiveBurial','offsetX','offsetZ','subcells'])assert.deepEqual(out[key],state[key]);assert.deepEqual(out.carry,[3]);
});
test('disjoint free support preserves fixed intervals and slices source physical moments',()=>{
  const h=10,cell=[bed(0,2),bed(1,3,100),bed(2,2),bed(3,3,100)],saved=structuredClone(cell),support=api.splitPhysicalCell(cell,50,0,h,()=>60);
  assert.deepEqual(support.free.map(g=>[api.lengthNumber(g.lo),api.lengthNumber(g.lengths)]),[[0,2],[5,2]]);
  const parent=bed(4,4,19),assigned=[{part:parent,localLengths:[1],sourceCell:0,parcel:0}],before=structuredClone(assigned);
  const out=api.placePhysicalCell(support,assigned,h,(q,z)=>({...q.part,offsetZ:q.part.offsetZ+api.lengthNumber(q.localLengths)-z}),true);
  assert.deepEqual(cell,saved);assert.deepEqual(assigned,before);assert.equal(out.transfers.length,2);assert.equal(out.numerical.length,0);
  const fixed=out.column.filter(p=>p.bed===1||p.bed===3);assert.deepEqual(fixed,[cell[1],cell[3]]);
  let top=0;for(const p of out.column){if(p.bed===1)assert.equal(top,2);if(p.bed===3)assert.equal(top,7);top+=p.height;}
  near(out.transfers.reduce((s,t)=>s+t.moved.solid,0),parent.solid);
  const mean=out.transfers.reduce((s,t)=>s+t.moved.solid*(t.destinationLocalTop+t.moved.height/2+t.moved.offsetZ),0)/parent.solid;near(mean,22);
});
test('almost entire and tiny physical cuts preserve positive grains on both exact support sides',()=>{
  const tiny=2**-60,h=2,parent=api.withLayerLengths(bed(0,1),[1,tiny]),cell=[parent,api.withLayerLengths(api.emptyLayer(-2,1),[1-tiny])];
  // Build an exact 2m cell: the two trailing basement pieces represent 1-tiny exactly.
  const s=api.exactLengthScale([h,1,tiny]),rest=s.chunks(s.units(1)-s.units(tiny));cell[1]=api.withLayerLengths(api.emptyLayer(-2,1),rest);
  for(const depth of [tiny,1]){
    const support=api.splitPhysicalCell(cell,0,0,h,()=>depth),moving=support.sources.filter(q=>q.part.bed===0),fixed=support.fixed.filter(q=>q.part.bed===0);
    assert.equal(moving.length,1);assert.equal(fixed.length,1);assert.ok(moving[0].part.solid>0);assert.ok(fixed[0].part.solid>0);assert.equal(moving[0].part.solid+fixed[0].part.solid,parent.solid);
    const small=depth===tiny?moving[0].part:fixed[0].part;near(small.solid,parent.solid*tiny,1e-34);assert.equal(small.height,tiny);
  }
});
test('free interval padding labels only new water and never merges natural water provenance',()=>{
  const support=api.splitPhysicalCell([bed(0,2),bed(1,3,100),bed(2,2),bed(3,3,100)],50,0,10,()=>60);
  const assigned=[{part:api.emptyLayer(-1,1),localLengths:[0],sourceCell:0,parcel:0},{part:bed(4,1),localLengths:[1],sourceCell:0,parcel:0}];
  const out=api.placePhysicalCell(support,assigned,10,(q,z)=>({...q.part,offsetZ:q.part.offsetZ+api.lengthNumber(q.localLengths)-z}),true);
  assert.deepEqual(out.numerical,[[5,7]]);assert.equal(out.transfers[0].source.part.bed,-1);assert.equal(out.transfers[0].moved.height,1);
});
test('primary matching and fractional fallback respect exact nonrepresentable capacity',()=>{
  const tiny=2**-60,allowed=Uint8Array.from([1,1]),capacity=Float64Array.from([1,1]),caps=[[1],[1,tiny]],parcel={source:0,i:0,k:0,targetI:0,targetK:0,height:1,materialHeights:[1,tiny],weight:1};
  const out=api.assignTransport(2,1,allowed,[parcel],capacity,caps);assert.equal(out.destination[0],1);
  const identical=api.assignCapacityTransport(2,1,allowed,[parcel],capacity,[[1,tiny],[1]]);assert.ok(identical.shares.every(q=>q.destination===0));
  const split=api.assignCapacityTransport(2,1,allowed,[parcel],capacity,[[1],[tiny]]);assert.ok(split.shares.some(q=>q.destination===1));
  const scale=api.exactLengthScale([1,tiny,...split.shares.map(q=>q.height)]);assert.equal(split.shares.reduce((s,q)=>s+scale.units(q.height),0n),scale.units(1)+scale.units(tiny));
});
test('forced capacity slicing uses original stationary-interleaved local coordinates',()=>{
  const h=20,nx=12,nz=10,columns=Array.from({length:nx},()=>[api.emptyLayer(-1,7*h),api.emptyLayer(-2,3*h)]);
  columns[5]=[api.emptyLayer(-1,3*h),bed(0,.5*h,0),bed(1,.5*h,100),bed(2,h,-h),api.emptyLayer(-1,2*h),api.emptyLayer(-2,3*h)];
  const state={...forced.rasterize(columns,nz,h),columns,nx,nz,h,beds:Array.from({length:3},()=>({carbonate:false}))},before=structuredClone(state),out=forced.remapThrust(state,[[-3000,5*h],[0,5*h]],.4*h,[0],true),result=forced.columnsFromRaster(out,nx,nz,h);
  assert.equal(out.placement.fallback,true);assert.deepEqual(state,before);
  for(const id of [0,1,2]){const a=tagged(columns,h,id),b=tagged(result,h,id);near(a.grain,b.grain);near(a.z,b.z);near(b.x,a.x+(id===1?0:.4*h));}
  for(const t of out.transfers){near(t.moved.offsetZ+t.destinationLocalTop+Math.floor(t.destinationCell/nx)*h,t.source.offsetZ+t.sourceLocalTop+Math.floor(t.sourceCell/nx)*h);assert.equal(t.moved.solid,t.source.solid);}
  assert.ok(api.assessBudget(api.inventoryOf(state),api.inventoryOf({...state,...out,columns:result}),out.flux).closed);
});

test('destination cost measures actual free gap placement, with a nonprefix gap known answer',()=>{
  for(const h of [40,20,10]){
    const parent=bed(0,.2*h),packet=[{part:parent,localLengths:[0],sourceCell:0,parcel:0}],supports=[undefined,
      {fixed:[{part:api.emptyLayer(-2,.8*h),localLengths:[0]}],free:[{lo:[.8*h],lengths:[.2*h]}]},
      {fixed:[{part:api.emptyLayer(-2,.8*h),localLengths:[.2*h]}],free:[{lo:[],lengths:[.2*h]}]}];
    const parcels=[{source:0,i:0,k:2,targetI:0,targetK:1.8,height:.2*h,materialHeights:[.2*h],weight:.2}],allowed=Uint8Array.from([0,1,1]),capacity=Float64Array.from([0,.2*h,.2*h]);
    // Exact support comes from representable 8/32,4/16,2/8m partitions.
    const cost=(_,n)=>api.placePhysicalCell(supports[n],packet,h,(q,local)=>({...q.part,offsetZ:1.8*h+api.lengthNumber(q.localLengths)-n*h-local}),false).transfers.reduce((s,t)=>s+t.moved.height/h*(t.moved.offsetZ/h)**2,0);
    assert.equal(api.assignTransport(1,3,allowed,parcels,capacity).destination[0],2);
    assert.equal(api.assignTransport(1,3,allowed,parcels,capacity,[[],[.2*h],[.2*h]],cost).destination[0],1);
    near(cost(0,1),0);near(cost(0,2),.008);
  }
});
test('custom gap costs retain exact matching optimality rather than invalid nearest-row duals',()=>{
  let seed=31871;const rng=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
  for(let trial=0;trial<150;trial++){
    const nx=3,nz=2,N=6,P=4,allowed=new Uint8Array(N).fill(1),capacity=new Float64Array(N).fill(1),parcels=Array.from({length:P},()=>({source:0,i:1,k:0,height:1,weight:1})),table=parcels.map(()=>Array.from({length:N},()=>Math.floor(rng()*1000)/100));
    const costs=(p,n)=>table[p][n],out=api.assignTransport(nx,nz,allowed,parcels,capacity,undefined,costs),actual=Array.from(out.destination,(n,p)=>table[p][n]).reduce((a,b)=>a+b,0);
    let best=Infinity;function visit(p,used,sum){if(p===P){best=Math.min(best,sum);return;}for(let n=0;n<N;n++)if(!(used&(1<<n)))visit(p+1,used|(1<<n),sum+table[p][n]);}visit(0,0,0);near(actual,best,1e-10);
  }
});

test('each vertical child receives its own independent rectangular bend-flow moment',()=>{
  const h=40,nx=61,nz=30,i=7,P=[[-2000,700],[-1600,700],[-1400,500],[400,500]];
  const columns=Array.from({length:nx},(_,j)=>{const x=-2000+j*h,d=x<=-1600?700:x>=-1400?500:700-(x+1600);return[forced.emptyLayer(-1,d),forced.emptyLayer(-2,nz*h-d)];});
  const bed=(id,height,ox,oz)=>({bed:id,height,solid:.4*height,fraction:.4,burial:90+id,loading:70,offsetX:ox,offsetZ:oz});
  columns[i]=[forced.emptyLayer(-1,600),bed(0,40,20,0),forced.emptyLayer(-1,40),bed(1,20,19,-77),forced.emptyLayer(-2,500)];
  const state={...forced.rasterize(columns,nz,h),nx,nz,h,beds:[{carbonate:false},{carbonate:false}]};
  const moved=forced.remapThrust(state,P,62,[0,0,0],true);
  const children=moved.transfers.filter(t=>t.source.bed===0);
  assert.ok(children.length>=2,'The fixture must split the marked parent');
  // Independent cubic corner integral of remaining travel beyond the45° bend.
  function expected(x,top,height){const t=Math.tan(Math.PI/8),cube=(x,z)=>Math.max(0,62+x+1600+(700-z)*t)**3;
    const mean=(cube(x+20,top)-cube(x-20,top)-cube(x+20,top+height)+cube(x-20,top+height))/(6*t*40*height);
    return[x+62-(1-1/Math.SQRT2)*mean,top+height/2-mean/Math.SQRT2];}
  for(const t of children){
    const oldX=-2000+t.sourceCell%nx*h+t.source.offsetX;
    const oldTop=Math.floor(t.sourceCell/nx)*h+t.sourceLocalTop+t.source.offsetZ;
    const target=expected(oldX,oldTop,t.source.height);
    const actual=[-2000+t.destinationCell%nx*h+t.moved.offsetX,
      Math.floor(t.destinationCell/nx)*h+t.destinationLocalTop+t.moved.height/2+t.moved.offsetZ];
    near(actual[0],target[0]);near(actual[1],target[1]);
  }
});

test('almost entire gap allocation retains a 2^-60 source child and its grain first moment',()=>{
  const tiny=2**-60,h=2,scale=api.exactLengthScale([h,1,tiny]),parent=api.withLayerLengths(bed(0,1),[1,tiny]);
  const support={fixed:[{part:api.withLayerLengths(api.emptyLayer(-2,1),scale.chunks(scale.units(1)-scale.units(tiny))),localLengths:[tiny]}],free:[{lo:[],lengths:[tiny]},{lo:[1],lengths:[1]}]};
  const assigned=[{part:parent,localLengths:[0],sourceCell:0,parcel:0}],out=api.placePhysicalCell(support,assigned,h,(q,z)=>({...q.part,offsetZ:api.lengthNumber(q.localLengths)-z}),false);
  assert.equal(out.transfers.length,2);const child=out.transfers.find(q=>q.moved.height===tiny);assert.ok(child);assert.ok(child.moved.solid>0);assert.equal(child.moved.solid,parent.solid*tiny);assert.equal(out.transfers.reduce((s,q)=>s+q.moved.solid,0),parent.solid);
  for(const t of out.transfers)near(t.destinationLocalTop+t.moved.offsetZ,api.lengthNumber(t.source.localLengths));
});

test('single-interval cost reuse is exactly equivalent to full child reconstruction',()=>{
  for(const h of [40,20,10])for(const sign of [-1,1]){
    const nx=14,nz=12,columns=Array.from({length:nx},()=>[api.emptyLayer(-1,9*h),api.emptyLayer(-2,3*h)]);
    columns[6]=[api.emptyLayer(-1,4*h),bed(0,.25*h,h,.2*h),bed(1,.75*h,0,-.1*h),api.emptyLayer(-1,4*h),api.emptyLayer(-2,3*h)];
    const state={...api.rasterize(columns,nz,h),columns,nx,nz,h,beds:[{carbonate:false},{carbonate:false}]},P=[[-3000,6*h],[0,6*h]];
    assert.deepEqual(api.remapThrust(state,P,sign*.65*h,[0],true),slow.remapThrust(state,P,sign*.65*h,[0],true));
  }
});
