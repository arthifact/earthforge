import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {build} from './physical-cut-candidate/node_modules/esbuild/lib/main.js';
const cwd=fileURLToPath(new URL('../../../',import.meta.url));
const source=cwd+'work/physical-coordinate-fix/earthforge';
const helper=cwd+'work/physical-coordinate-fix/velocity-review/candidate/src/canonicalSurface-v2.ts';
const built=await build({stdin:{contents:"export * from 'isolated-canonical';export * from './src/strata.ts';",resolveDir:source},bundle:true,platform:'node',format:'esm',write:false,plugins:[{name:'exact-helper',setup(b){b.onResolve({filter:/^isolated-canonical$/},()=>({path:helper,namespace:'canonical'}));b.onLoad({filter:/.*/,namespace:'canonical'},()=>({contents:readFileSync(helper,'utf8'),loader:'ts',resolveDir:source+'/src'}));}}]});
const{canonicalSurfaceColumn,emptyLayer,surface}=await import('data:text/javascript;base64,'+Buffer.from(built.outputFiles[0].contents).toString('base64'));
const bed=(id,height,offsetX)=>({bed:id,height,solid:.4*height,fraction:.2+.3*id,burial:80+id,loading:60+id,offsetX,offsetZ:0});
function rectangles(columns,h){const out=[];for(let i=0;i<columns.length;i++){let top=0;for(const p of columns[i]){if(p.bed!==-1)out.push({bed:p.bed,xlo:i*h+p.offsetX-h/2,xhi:i*h+p.offsetX+h/2,top:top+p.offsetZ,bottom:top+p.offsetZ+p.height,solid:p.solid,fraction:p.fraction,burial:p.burial,loading:p.loading});top+=p.height;}}return out.sort((a,b)=>a.xlo-b.xlo||a.top-b.top||a.bed-b.bed);}
// Independent geometric oracle. Split each target stripe at every source
// rectangle's lateral edge, then integrate the exposed upper envelope.
function ownedSurface(rects,i,h){const lo=i*h-h/2,hi=i*h+h/2,cuts=[lo,hi];for(const r of rects){if(r.xlo>lo&&r.xlo<hi)cuts.push(r.xlo);if(r.xhi>lo&&r.xhi<hi)cuts.push(r.xhi);}cuts.sort((a,b)=>a-b);let integral=0;for(let j=1;j<cuts.length;j++){const a=cuts[j-1],b=cuts[j];if(a===b)continue;const x=(a+b)/2,tops=rects.filter(r=>r.xlo<x&&r.xhi>x).map(r=>r.top);assert.ok(tops.length);integral+=(b-a)*Math.min(...tops);}return integral/h;}
const evidence=[];
for(const h of [40,20,10])test(`counterexample: local first-rock marker is not an owned physical surface at h=${h}`,()=>{
  const shifted=[ [emptyLayer(-1,100),bed(0,10,h),{...emptyLayer(-2,190),offsetX:h}], [emptyLayer(-1,200),bed(1,10,-h),{...emptyLayer(-2,90),offsetX:-h}] ];
  const owned=[ [emptyLayer(-1,200),bed(1,10,0),emptyLayer(-2,90)], [emptyLayer(-1,100),bed(0,10,0),emptyLayer(-2,190)] ];
  const before=structuredClone(shifted),a=rectangles(shifted,h),b=rectangles(owned,h);assert.deepEqual(a,b,'every physical rock rectangle, grain and history is identical');
  const expected=[ownedSurface(a,0,h),ownedSurface(a,1,h)];assert.deepEqual(expected,[200,100]);
  const shiftedResult=shifted.map(c=>canonicalSurfaceColumn(c)),ownedResult=owned.map(c=>canonicalSurfaceColumn(c));
  assert.deepEqual(rectangles(shiftedResult.map(q=>q.column),h),a);assert.deepEqual(shifted,before);
  const shiftedMarker=shiftedResult.map(q=>surface(q.column)),ownedMarker=ownedResult.map(q=>surface(q.column));
  assert.deepEqual(shiftedMarker,[100,200]);assert.deepEqual(ownedMarker,expected);
  assert.notDeepEqual(shiftedMarker,expected,'conservative rebase does not infer lateral ownership');
  const fill=.8,expectedDeposit=expected.map(z=>z*fill),markerDeposit=shiftedMarker.map(z=>z*fill);
  assert.deepEqual(expectedDeposit,[160,80]);assert.deepEqual(markerDeposit,[80,160]);
  evidence.push({h,physical_rectangles_identical:true,owned_upper_envelope_m:expected,first_stored_marker_m:shiftedMarker,zero_offset_equivalent_marker_m:ownedMarker,fill,owned_deposition_m:expectedDeposit,marker_deposition_m:markerDeposit,grain_history_and_physical_rectangles_preserved:true,input_unchanged:true});
});
process.on('exit',()=>{const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');writeFileSync(cwd+'work/physical-coordinate-fix/transport-review/canonical-horizontal-gauge-evidence.json',JSON.stringify({schema:'earthforge.canonical-surface-horizontal-gauge-counterexample.v1',helper_sha256:sha(helper),strata_sha256:sha(source+'/src/strata.ts'),exact_length_sha256:sha(source+'/src/exactLength.ts'),runner_sha256:sha(fileURLToPath(import.meta.url)),findings:evidence,claim:'A first-stored-parcel physical marker is not invariant to horizontally compensated material ownership. This is an analytical counterexample, not a measured cause of the A regression.',scope:'Whole h-wide rock stacks are exchanged using offsetX=+/-h; their physical supports form exactly the same two packed columns. The upper-envelope oracle has no overlap ambiguity in this fixture.',holdout_or_observational_arrays_read:false},null,2)+'\n');});
