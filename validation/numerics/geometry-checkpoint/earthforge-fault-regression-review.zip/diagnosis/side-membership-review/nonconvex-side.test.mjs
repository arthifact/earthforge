import assert from 'node:assert/strict';
import {test} from 'node:test';
import {build} from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const here=new URL('./',import.meta.url).pathname,root=new URL('../earthforge/',import.meta.url).pathname;
const hashes=Object.fromEntries(['basin.ts','strata.ts'].map(f=>[f,createHash('sha256').update(readFileSync(root+'src/'+f)).digest('hex')]));
const b=await build({stdin:{contents:'export * from "./src/basin.ts";export * from "./src/strata.ts";',resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const {flowLine,flowMove,flowAreaDisplacement,compactColumn,emptyLayer}=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].contents).toString('base64'));
const near=(a,b,t=2e-10)=>assert.ok(Math.abs(a-b)<t,`${a} != ${b}`),rows=[];
// Independent point flow along the three offset straight segments. δ>0 is
// signed normal distance. Both bend intersections shift left by(√2−1)δ.
function pointFlow(x,delta,slip,upperX,lowerZ){const c=Math.SQRT2-1,r=x+slip+c*delta,L=upperX*Math.SQRT2;if(r<=0)return[x+slip,lowerZ-delta];if(r<L)return[-c*delta+r/Math.SQRT2,lowerZ-delta-r/Math.SQRT2];return[upperX-c*delta+r-L,lowerZ-upperX-delta];}
function oracle(w,H,margin,upperX,upperZ){const c=Math.SQRT2-1,beta=1-1/Math.SQRT2,D=margin+H/2,D2=margin*margin+margin*H+H*H/3,A=w/8+c*D/2+c*c*D2/(2*w);return[upperX-c*beta*D+beta*A,upperZ-(1+c/Math.SQRT2)*D+A/Math.SQRT2];}
test('true fault-parallel HW support can have a centroid inside apparent FW in a nonconvex hanging wall',()=>{
 for(const h of[40,20,10]){
  const w=h,H=h/40,margin=h/320,upperX=5*h,lowerZ=25*h,upperZ=20*h,x=-h,top=lowerZ-margin-H,s=h+upperX*Math.SQRT2;
  const P=[[-25*h,lowerZ],[0,lowerZ],[upperX,upperZ],[25*h,upperZ]],F=flowLine(P),depth=x=>x<=0?lowerZ:x<upperX?lowerZ-x:upperZ;
  const expected=oracle(w,H,margin,upperX,upperZ),d=flowAreaDisplacement(F,s,w)(x,top,H),actual=[x+d[0],top+H/2+d[1]];
  near(actual[0],expected[0]);near(actual[1],expected[1]);
  assert.ok(expected[0]>upperX);assert.ok(expected[1]-H/2>upperZ,'Every point of the recentered vertical interval is classified FW');
  let minimum=Infinity,maxPointError=0;
  for(let i=0;i<=40;i++)for(let j=0;j<=20;j++){
   const sx=x-w/2+i*w/40,delta=margin+j*H/20,q=pointFlow(sx,delta,s,upperX,lowerZ),v=flowMove(F,sx,lowerZ-delta,s);
   near(q[0],v[0]);near(q[1],v[1]);minimum=Math.min(minimum,depth(q[0])-q[1]);maxPointError=Math.max(maxPointError,Math.hypot(q[0]-v[0],q[1]-v[1]));
  }
  assert.ok(minimum>=margin-1e-10);
  // After another width of slip every TRUE source point is on the upper flat.
  // Record the repeated mean-flow result separately; side failure alone does
  // not imply a centroid error for this symmetric fixture.
  const second=flowAreaDisplacement(F,w,w)(actual[0],actual[1]-H/2,H),reprojected=[actual[0]+second[0],actual[1]+second[1]],trueAfter=[upperX+w,upperZ-margin-H/2];
  const one=flowAreaDisplacement(F,s+w,w)(x,top,H);near(x+one[0],trueAfter[0]);near(top+H/2+one[1],trueAfter[1]);
  const error=Math.hypot(reprojected[0]-trueAfter[0],reprojected[1]-trueAfter[1]);
  rows.push({h,source:{x,top,width:w,height:H,minimum_margin:margin},fault:P,slip:s,closed_form_target_centroid:expected,production_target_centroid:actual,apparent_FW_height:H,minimum_sampled_true_HW_clearance:minimum,point_oracle_max_error:maxPointError,subsequent_slip:w,true_final_centroid:trueAfter,reprojected_final_centroid:reprojected,repeated_projection_error:error});
 }
});
let compaction;
test('current differential-offset compaction is not a common material-and-fault map that guarantees immutable side labels',()=>{
 const p=(bed,solid,offsetZ)=>({bed,height:100,solid,fraction:.5,burial:0,loading:0,offsetX:0,offsetZ});
 // Physical A is100..200, B is200..300. Storage is B thenA with compensating
 // translations, so the initial physical section is coherent and nonoverlapping.
 const column=[emptyLayer(-1,100),p(1,25,100),p(0,50,-100),emptyLayer(-2,700)];
 const out=compactColumn(column,[{carbonate:false},{carbonate:false}],null,{porosity:()=>.5,effectiveDepth:d=>d});
 const initialFault=290,initialPoint=289,storedPoint=189;
 const currentFault=out.mapDepth(initialFault),currentPoint=out.mapDepth(storedPoint)+100;
 near(currentFault,290,1e-8);near(currentPoint,294.5,1e-8);assert.ok(initialPoint<initialFault&&currentPoint>currentFault);
 compaction={initial_physical_order:['A100..200','B200..300'],initialFault,initialPoint,storedPoint,currentFault,currentPoint,point_crossing_m:currentPoint-currentFault,reason:'Marker uses F(physical z), while the material uses F(storage z)+offset. They are different maps for differential offsets.'};
});
test('save exact mathematical proof and unchanged-source receipt',()=>{
 for(const[f,h]of Object.entries(hashes))assert.equal(createHash('sha256').update(readFileSync(root+'src/'+f)).digest('hex'),h);
 writeFileSync(here+'nonconvex-side-proof.json',JSON.stringify({schema:'earthforge.nonconvex-thrust-side-proof.v1',source_sha256:hashes,closed_form:'Let c=√2−1, β=1−1/√2, D=Eδ=m+H/2, D2=Eδ²=m²+mH+H²/3, A=E[(y+cδ)+]=w/8+cD/2+c²D2/(2w), for y uniform[-w/2,w/2]. At s=−sourceCenter+upperX√2, mean x=upperX−cβD+βA, mean z=upperZ−(1+c/√2)D+A/√2.',side_proof:'Each independent point lies on a lower-flat, ramp or upper-flat line of positive normal distanceδ. Comparing with the actual fault on every applicable segment gives vertical clearance≥δ≥m. The recentered rectangle, however, has its whole centerline interval below the upper flat.',fixtures:rows,compaction_counterexample:compaction,scope:'Synthetic analytical identities only; no development metrics, plan or observational material read or changed. This invalidates treating the translated rectangle as ground truth for a material side after a bend.'},null,2)+'\n');
});
