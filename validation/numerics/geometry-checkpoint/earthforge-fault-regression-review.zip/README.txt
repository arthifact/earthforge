EarthForge fault-regression review — rejected experiment, 2026-10-14 UTC

The main simulator is unchanged; only the new 3-grid regression guard was added.
The requested travel-time/thickness fixes remain unresolved. Do not treat the
rejected-source/ tree as an accepted update.

current-source/ includes the frozen current code and the new passing guard.
rejected-source/ includes the experimental physical-coordinate cut implementation.
rejected-study/ contains all 50 raw files from its 36-run frozen comparison.
current-study/ contains baseline summary/series and the 12 matched-sample files.
audit/ contains recomputed shared cohorts, full metrics, budgets and outliers.
diagnosis/ contains synthetic analytical proofs and their stated limitations.
test-logs/ omit large inline base64 bundles while retaining failure text.

For portable project tests, install dependencies from package-lock.json in a
copied source tree and run node --test tests/thrust-side-continuity.test.mjs.
The rejected tree predates the new guard: copy just that test into it to see
the three expected failures. The general diagnostic scripts preserve their
original local paths for traceability; those paths may need updating elsewhere.
The frozen full study command is node --max-old-space-size=8192
validation/numerics/run.mjs data/numerics/physical-thrust-review.
Running the study is substantially more expensive than the new guard.

No holdout or observational data are included or were accessed.
manifest.json lists every archive member's SHA-256 (excluding itself).
