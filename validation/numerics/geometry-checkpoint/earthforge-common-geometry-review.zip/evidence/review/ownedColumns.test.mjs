import assert from 'node:assert/strict';import{test}from'node:test';import{build}from'/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';import{writeFileSync}from'node:fs';
const here=new URL('.',import.meta.url).pathname;
const b=await build({stdin:{contents:'export * from "./ownedColumns";export * from "../design/geometricSupport";export * from "../design/ownedProfiles";',resolveDir:here},bundle:true,platform:'node',format:'esm',write:false});
const a=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].contents).toString('base64'));
const near=(x,y,t=2e-9)=>assert.ok(Math.abs(x-y)<=t,`${x} != ${y}`),beds=[{carbonate:false},{carbonate:false}],law={porosity:()=>.5,effectiveDepth:d=>d};
const piece=(bed,x,z,w,H,rho)=>({support:a.rectangle(x,z,w,H),bed,solid:bed<0?0:w*H*rho,fraction:.37,burial:0,loading:0});
const grain=p=>p.reduce((s,q)=>s+q.solid,0),area=p=>p.reduce((s,q)=>s+a.measure(q.support).area,0);
const column=(h)=>[piece(-1,0,0,h,100,0),piece(0,0,100,h,100,.5),piece(1,0,200,h,100,.25),piece(-2,0,300,h,700,0)];
let receipt={};
test('conforming support and fault compaction have the independent two-bed physical map at40/20/10',()=>{
 for(const h of[40,20,10]){const p=column(h),copy=structuredClone(p),r=a.deformOwnedColumns(p,{h,x0:0,xmax:h,zmax:1000},beds,null,law,{mode:'compact',constitutiveTolerance:1e-10});
  assert.deepEqual(p,copy);near(grain(r.pieces),grain(p));near(area(r.pieces),h*1000);near(r.faces[0].map(290),295);near(r.faces[0].map(289),294.5);
  const section=a.ownedProfile(r.pieces,h*.37);const rock=section.filter(q=>q.piece.bed>=0);near(Math.min(...rock.map(q=>q.top)),150);near(Math.max(...rock.map(q=>q.bottom)),300);
  const fault=r.mapSegments([[[0,290],[h,290]]]);near(fault[0][0][1],295);near(fault.at(-1)[1][1],295);
  for(let j=1;j<fault.length;j++)assert.deepEqual(fault[j-1][1],fault[j][0]);
  assert.ok(r.diagnostics.minDeterminant>0);near(r.diagnostics.meanConstitutiveError,0,1e-10);
 }
});
test('identity preserves area, grains, material positions and full fault path through triangle seams',()=>{
 const h=40,p=column(h);p[2].solid=2000;
 const r=a.deformOwnedColumns(p,{h,x0:0,xmax:h,zmax:1000},beds,null,law,{mode:'compact',constitutiveTolerance:1e-10});
 near(grain(r.pieces),grain(p));near(area(r.pieces),40000);const f=r.mapSegments([[[0,50],[40,350]]]);
 for(const segment of f)for(const[x,z]of segment)near(z,50+7.5*x);
});
test('local physical water collapse closes gaps with the same fault map and zero grain loss',()=>{
 const p=[piece(-1,0,0,40,100,0),piece(0,0,100,40,100,.5),piece(-1,0,200,40,50,0),piece(1,0,250,40,50,.5),piece(-2,0,300,40,700,0)];
 const r=a.deformOwnedColumns(p,{h:40,x0:0,xmax:40,zmax:1000},beds,null,law,{mode:'collapse'});
 near(area(r.pieces),40000);near(grain(r.pieces),grain(p));near(r.faces[0].map(200),250);near(r.faces[0].map(250),250);
 const f=r.mapSegments([[[0,225],[40,225]]]);for(const s of f)for(const q of s)near(q[1],250);
 assert.ok(r.diagnostics.collapsedWaterArea>=2000);for(const q of r.pieces.filter(p=>p.bed>=0)){assert.equal(q.loading,0);assert.equal(q.burial,0);}
});
test('lateral dense-loose closure stays continuous, admissible and converges in integrated residual',()=>{
 const rows=[];
 for(const h of[40,20,10]){const pieces=[];for(let x=0;x<400;x+=h)pieces.push(piece(-1,x,0,h,100,0),piece(x<200?0:1,x,100,h,100,x<200?.5:.25),piece(-2,x,200,h,800,0));
  const r=a.deformOwnedColumns(pieces,{h,x0:0,xmax:400,zmax:1000},beds,null,law,{mode:'compact'});
  near(grain(r.pieces),grain(pieces),1e-7);near(area(r.pieces),400000,1e-7);
  for(const q of r.pieces)assert.ok(q.solid<=a.measure(q.support).area*(1+1e-12));
  const f=r.mapSegments([[[0,150],[400,150]]]);for(let j=1;j<f.length;j++)near(Math.hypot(f[j][0][0]-f[j-1][1][0],f[j][0][1]-f[j-1][1][1]),0);
  rows.push({h,...r.diagnostics});
 }
 assert.ok(rows[1].meanConstitutiveError<rows[0].meanConstitutiveError&&rows[2].meanConstitutiveError<rows[1].meanConstitutiveError);receipt.refinement=rows;
});
test('invalid overlap/gap and unresolved sub-ULP shared interfaces fail without dropping grains',()=>{
 const p=column(40),d={h:40,x0:0,xmax:40,zmax:1000};
 const overlap=structuredClone(p);overlap[1].support.origin[1]=99;assert.throws(()=>a.deformOwnedColumns(overlap,d,beds,null,law,{mode:'compact'}),/gap or overlap/);
 const gap=structuredClone(p);gap[1].support.origin[1]=101;assert.throws(()=>a.deformOwnedColumns(gap,d,beds,null,law,{mode:'compact'}),/gap or overlap/);
 const tiny=[piece(-1,0,0,40,100,0),piece(0,0,100,40,1e-18,.5),piece(-2,0,100,40,900,0)];const copy=structuredClone(tiny);assert.throws(()=>a.deformOwnedColumns(tiny,d,beds,null,law,{mode:'compact'}),/Unresolved shared/);assert.deepEqual(tiny,copy);
});
test('configured constitutive acceptance gate rejects an unresolved lateral closure',()=>{
 const p=[];for(const x of[0,40])p.push(piece(-1,x,0,40,100,0),piece(x?1:0,x,100,40,100,x?.25:.5),piece(-2,x,200,40,800,0));
 assert.throws(()=>a.deformOwnedColumns(p,{h:40,x0:0,xmax:80,zmax:1000},beds,null,law,{mode:'compact',constitutiveTolerance:1e-6}),/Constitutive closure/);
});
test('repeated slanted owned stacks retain seam ownership and one common identity map',()=>{
 const polygon=(bed,ring,rho)=>{const support=a.rectangle(0,0,64,1024);support.ring=ring.map(([x,z])=>[x/64,z/1024]);return{support,bed,solid:bed<0?0:a.measure(support).area*rho,fraction:.37,burial:0,loading:0};};
 let p=[polygon(-1,[[0,0],[64,0],[64,144],[0,128]],0),polygon(0,[[0,128],[64,144],[64,288],[0,256]],.5),polygon(-2,[[0,256],[64,288],[64,1024],[0,1024]],0)];
 const total=grain(p),counts=[];
 for(let cycle=0;cycle<20;cycle++){
  const r=a.deformOwnedColumns(p,{h:16,x0:0,xmax:64,zmax:1024},beds,null,law,{mode:'compact',constitutiveTolerance:1e-10});
  near(grain(r.pieces),total,1e-8);near(area(r.pieces),65536,1e-8);
  for(const x of[0,16,32,48,64])for(const side of['left','right']){if(x===0&&side==='left'||x===64&&side==='right')continue;
   const q=a.ownedProfile(r.pieces,x,side);let end=0;for(const v of q){near(v.top,end,1e-9);end=v.bottom;}near(end,1024);
   const rock=q.filter(v=>v.piece.bed===0);near(rock[0].top,128+x/4);near(rock.at(-1).bottom,256+x/2);
  }
  const fault=r.mapSegments([[[0,150],[64,230]]]);for(const segment of fault)for(const[x,z]of segment)near(z,150+1.25*x);
  counts.push(r.pieces.length);p=r.pieces;
 }
 assert.equal(Math.max(...counts),counts[0]);receipt.repeatedSlanted={cycles:20,counts};
});
test('common fault map retains every positive leading and trailing support interval',()=>{
 for(const delta of[2**-40,2**-44])for(const seam of[delta,40-delta]){
  const p=[];for(const[left,width]of[[0,seam],[seam,40-seam]])p.push(piece(-1,left,0,width,100,0),piece(0,left,100,width,100,.5),piece(-2,left,200,width,800,0));
  const r=a.deformOwnedColumns(p,{h:40,x0:0,xmax:40,zmax:1000},beds,null,law,{mode:'compact',constitutiveTolerance:1e-10});
  const fault=r.mapSegments([[[0,150],[40,150]]]);assert.deepEqual(fault[0][0],[0,150]);assert.deepEqual(fault.at(-1)[1],[40,150]);
  assert.ok(fault.some(([u,v])=>u[0]===seam||v[0]===seam));
  let total=0;for(let j=0;j<fault.length;j++){const[u,v]=fault[j];assert.ok(v[0]>u[0]);total+=v[0]-u[0];if(j)assert.deepEqual(fault[j-1][1],u);}assert.equal(total,40);
 }
});
test('save analytical receipt',()=>writeFileSync(here+'ownedColumns-evidence.json',JSON.stringify(receipt,null,2)+'\n'));
