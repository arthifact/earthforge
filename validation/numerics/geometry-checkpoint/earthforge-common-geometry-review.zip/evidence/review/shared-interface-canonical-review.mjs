import {build} from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
import {writeFileSync,readFileSync} from 'node:fs';import{createHash}from'node:crypto';import assert from'node:assert/strict';
const here=new URL('.',import.meta.url).pathname;
const b=await build({stdin:{contents:'export * from "../design/geometricSupport";export * from "../design/ownedProfiles";export * from "./ownedColumns";',resolveDir:here},bundle:true,platform:'node',format:'esm',write:false});
const a=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].contents).toString('base64'));
const polygon=(bed,ring,rho)=>{const support=a.rectangle(0,0,80,1000);support.ring=ring.map(([x,z])=>[x/80,z/1000]);return{support,bed,solid:bed<0?0:a.measure(support).area*rho,fraction:.37,burial:0,loading:0};};
const pieces=[polygon(-1,[[0,0],[80,0],[80,120],[0,100]],0),polygon(0,[[0,100],[80,120],[80,240],[0,200]],.5),polygon(-2,[[0,200],[80,240],[80,1000],[0,1000]],0)];
const before=structuredClone(pieces),checks=[];
for(const x of[0,.1,1,1.1,3.3,7.7,10,20,30,40,50,60,70,79.9,80])for(const side of['left','right']){
 if(x===0&&side==='left'||x===80&&side==='right')continue;
 const p=a.ownedProfile(pieces,x,side);let end=0;
 for(const s of p){if(s.top!==end)checks.push({x,side,priorBottom:end,top:s.top,mismatch:s.top-end,bed:s.piece.bed});end=s.bottom;}
}
const literalSharedEdgeFixed=checks.length===0;
let error;
try{a.deformOwnedColumns(pieces,{h:7.7,x0:0,xmax:80,zmax:1000},[{carbonate:false}],null,{porosity:()=>.5,effectiveDepth:d=>d},{mode:'compact'});}catch(e){error=e.message;}
assert.deepEqual(pieces,before);
const files=['ownedColumns.ts','../design/geometricSupport.ts','../design/ownedProfiles.ts'];
const result={status:literalSharedEdgeFixed?'literal-edge orientation fixed; later admission assessed separately':'shared-edge discrepancy remains',literalSharedEdgeFixed,fixture:'Three polygons share the exact same affine chart and matching ring edge endpoints, with opposite half-edge orientations. Querying each side independently rounds an algebraically identical intersection differently.',pieces,checks,rejection:error,requiredCorrection:{topology:'Assign each common material interface one canonical edge identity, with a single orientation and shared endpoint objects or exact local coordinate expansions.',intersection:'Evaluate each (canonical edge, vertical profile cut) intersection once and reuse its depth node for all incident owners and fault-map regions. Use shared oriented chart coordinates or filtered exact predicates/constructions when the event cannot resolve in global Number coordinates.',prohibited:'Do not identify interfaces merely by coordinate proximity; do not epsilon-snap independent contacts, trim tiny supports, sort away overlap, or average conflicting nodes.',remaining:'Axis boundary tags solve domain and cell cut provenance only. Nonhorizontal material edges and sub-ULP x/z events require the shared construction above; current test suite does not claim that implementation.'},hashes:Object.fromEntries(files.map(p=>[p,createHash('sha256').update(readFileSync(here+p)).digest('hex')]))};
writeFileSync(here+'shared-interface-canonical-review.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({checks,rejection:error},null,2));
