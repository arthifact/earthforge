import{build}from'/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';import{readFileSync}from'node:fs';import assert from'node:assert/strict';
const here=new URL('.',import.meta.url).pathname;
const source=JSON.parse(readFileSync(here+'actual-shared-node-witness.json','utf8'));
const b=await build({stdin:{contents:'export * from "../design/ownedProfiles";',resolveDir:here},bundle:true,platform:'node',format:'esm',write:false});
const a=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].contents).toString('base64'));
const [upper,lower]=source.owners.map(q=>a.verticalSection(q.section.piece.support,source.x,'right'));
assert.ok(upper&&lower);assert.equal(upper.bottom,97.71229010920061);assert.equal(lower.top,97.71229010920058);assert.equal(lower.top-upper.bottom,-2.842170943040401e-14);console.log(JSON.stringify({status:'explicit shared-node admission failure reproduced from just two saved supports',upperBottom:upper.bottom,lowerTop:lower.top,difference:lower.top-upper.bottom}));
