import assert from 'node:assert/strict';import{test}from'node:test';import{build}from'/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';import{fileURLToPath}from'node:url';
const here=fileURLToPath(new URL('.',import.meta.url));
await build({stdin:{contents:'export * from "./geometricSupport";export * from "./ownedProfiles";',resolveDir:here},bundle:true,platform:'node',format:'esm',outfile:here+'ownedProfiles-bundle.mjs'});
const a=await import('./ownedProfiles-bundle.mjs');const near=(x,y,t=1e-10)=>assert.ok(Math.abs(x-y)<=t,`${x} != ${y}`);
test('vertical section retains sub-ULP height at a large physical depth',()=>{for(const h of[40,20,10]){const p=a.rectangle(0,700,h,1e-18),q=a.verticalSection(p,h/2);near(q.height/1e-18,1);assert.equal(q.top,q.bottom);}});
test('one-sided seam ownership counts adjacent cells once',()=>{const q=[a.rectangle(0,100,20,5),a.rectangle(20,100,20,5)];assert.equal(q.filter(p=>a.verticalSection(p,20)).length,1);assert.equal(q.filter(p=>a.verticalSection(p,20,'left')).length,1);near(a.verticalSection(q[1],20).height,5);assert.equal(a.verticalSection(q[0],20),null);});
test('sheared thin support retains the determinant-correct vertical thickness',()=>{const p=a.rectangle(0,700,20,1e-18),q=a.affineMap(p,[[1,2],[.3,1.6]],[0,700],1);const s=a.verticalSection(q,10);near(s.height/1e-18,1);});
test('axis exchange and reflected support yield positive correct sections',()=>{const p=a.rectangle(0,0,8,3);const rotated=a.affineMap(p,[[0,-1],[1,0]],[0,0],1);near(a.verticalSection(rotated,-1).height,8);const mirror={...p,axes:[[-8,0],[0,3]],xBounds:[-8,0]};near(a.verticalSection(mirror,-4).height,3);});
test('cell overlay and unsplit support have identical owned profile intervals',()=>{const p=a.affineMap(a.rectangle(3,7,30,8),[[1,.5],[.2,1.1]],[6.5,8.3],1),whole=a.verticalSection(p,20);const children=a.cellIntersections(p,10).map(q=>q.support);const sections=children.map(q=>a.verticalSection(q,20)).filter(Boolean);near(sections.reduce((s,q)=>s+q.height,0),whole.height);near(Math.min(...sections.map(q=>q.top)),whole.top);near(Math.max(...sections.map(q=>q.bottom)),whole.bottom);});
test('line-profile grain heights use retained owned area density',()=>{const p=a.rectangle(0,700,20,3),piece={support:p,bed:2,solid:30,fraction:.2,burial:80,loading:70};const [q]=a.ownedProfile([piece],10);near(q.grainDensity,.5);near(q.solidHeight,1.5);assert.equal(q.piece,piece);});
test('literal shared edges have identical section nodes across reversed and reflected orientations',()=>{
  const rings=[[[0,0],[1,0],[1,.12],[0,.1]],[[0,.1],[1,.12],[1,.24],[0,.2]],[[0,.2],[1,.24],[1,1],[0,1]]];
  for(const direction of[-1,1])for(let reversed=0;reversed<8;reversed++){
    const pieces=rings.map((ring,i)=>{
      const support=a.rectangle(0,0,80,1000);support.axes[0][0]*=direction;support.xBounds=direction<0?[-80,0]:[0,80];support.ring=ring.map(q=>[...q]);
      if(reversed&(1<<i))support.ring.reverse();
      return{support,bed:i===0?-1:i===1?0:-2,solid:i===1?a.measure(support).area*.5:0,fraction:.37,burial:0,loading:0};
    });
    for(const x of[.1,1,1.1,3.3,7.7,10,20,30,40,50,60,70,79.9])for(const side of['left','right']){
      const profile=a.ownedProfile(pieces,direction*x,side);assert.equal(profile.length,3);
      assert.equal(profile[0].bottom,profile[1].top);assert.equal(profile[1].bottom,profile[2].top);
      assert.equal(profile[0].top,0);assert.equal(profile[2].bottom,1000);
    }
  }
});
test('different exact local charts of one world edge share a canonical profile depth',()=>{
  const q=(bed,origin,axes,ring,rho)=>{const support={origin,axes,ring,jacobian:axes[0][0]*axes[1][1]-axes[0][1]*axes[1][0],xBounds:[0,80]};return{support,bed,solid:bed<0?0:a.measure(support).area*rho,fraction:.37,burial:0,loading:0};};
  const pieces=[q(-1,[0,0],[[80,0],[0,10]],[[0,0],[1,0],[1,12],[0,10]],0),q(0,[0,100],[[80,20],[0,128]],[[0,0],[1,0],[1,120/128],[0,100/128]],.5),q(-2,[0,200],[[80,40],[0,1024]],[[0,0],[1,0],[1,760/1024],[0,800/1024]],0)];
  for(const x of[.1,1.1,3.3,7.7,13.3,27.1,39.9,61.7,77.7])for(const side of['left','right']){
    const p=a.ownedProfile(pieces,x,side);assert.equal(p.length,3);
    assert.equal(p[0].bottom,p[1].top);assert.equal(p[1].bottom,p[2].top);
    assert.equal(p[0].bottom,100+x/80*20);assert.equal(p[1].bottom,200+x/80*40);
  }
});
test('nearby distinct world interfaces remain distinct without proximity merging',()=>{
  const gap=2**-40,upper=a.rectangle(0,0,80,100),lower=a.rectangle(0,100+gap,80,20);
  for(const x of[.1,3.3,40,79.9])assert.equal(a.verticalSection(lower,x).top-a.verticalSection(upper,x).bottom,gap);
});
test('per-endpoint shared depth provenance preserves declared nodes and untagged sub-ULP charts',()=>{
  const declared=a.rectangle(0,.1,20,.2);declared.vertexZ=[.1,.1,.3,.3];
  for(const x of[0,10]){
    const s=a.verticalSection(declared,x);assert.equal(s.topWorldNode,.1);assert.equal(s.bottomWorldNode,.3);
    assert.notEqual(declared.origin[1]+declared.axes[1][1],s.bottomWorldNode);assert.equal(s.height,.2);
  }
  const thin=a.rectangle(0,700,20,2**-60);
  for(const x of[0,10]){
    const s=a.verticalSection(thin,x);assert.equal(s.top,s.bottom);assert.equal(s.height,2**-60);
    assert.equal(s.topWorldNode,null);assert.equal(s.bottomWorldNode,null);
  }
  const sloped=a.affineMap(a.rectangle(0,0,20,10),[[1,0],[.1,1]],[0,0],1);sloped.vertexZ=[0,2,12,10];
  const s=a.verticalSection(sloped,10);assert.equal(s.topWorldNode,1);assert.equal(s.bottomWorldNode,11);
});
