import { build } from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root = new URL('.', import.meta.url);
const bundle = await build({ stdin: { contents: `export * from '../metrics/baseline/src/basin'; export * from '../integration/ownedSurface'; export * from './domainThrust'; export * from './geometricSupport'; export * from './ownedProfiles';`, resolveDir: root.pathname }, bundle: true, format: 'esm', platform: 'node', write: false });
const { simulate, BASIN_DEFAULTS, flowLine, initializeOwned, deformDomainThrust, extendedFaultGraph, cutFault, deformHangingWall, intersectBox, measure, world, ownedProfile, rectangle } = await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString('base64')}`);
let before, fault;
const stop = new Error('captured');
try {
 simulate({ ...BASIN_DEFAULTS, seed: 765184, h: 40, setting: 'compression', overpressure: 1, record: false }, state => {
  if (state.process === 'subsidence' && state.faults.length === 0) before = structuredClone({ columns: state.columns, nx: state.nx, nz: state.nz, h: state.h, step: state.step });
  if (state.process === 'thrust-slip') { fault = structuredClone(state.faults[0]); throw stop; }
 });
} catch (e) { if (e !== stop) throw e; }
const domain={h:before.h,x0:-2000-before.h/2,xmax:-2000-before.h/2+before.nx*before.h,zmax:before.nz*before.h};
const source=initializeOwned(before.columns,domain), F=flowLine(fault.thrust.points),slip=fault.heaves[0];
const moved=deformDomainThrust(source,F,slip,domain);
const inspect=p=>{
 const vertices=p.ring.map(q=>world(p,q)),xs=vertices.map(v=>v[0]);
 return {measure:measure(p),vertices,xMin:Math.min(...xs),xMax:Math.max(...xs)};
};
const unresolved=moved.pieces.flatMap((piece,index)=>{const geometry=inspect(piece.support);return geometry.xMax>geometry.xMin?[]:[{index,piece,geometry}];});
const halo=Math.abs(slip)+domain.h,graph=extendedFaultGraph(F,domain.x0-halo-domain.h,domain.xmax+halo+domain.h);
let outputIndex=0, minimal=null;
const ghosts=[];
for(const face of ['left','right'])for(const q of ownedProfile(source,face==='left'?domain.x0:domain.xmax,face==='left'?'right':'left')){
 const support=rectangle(face==='left'?domain.x0-halo:domain.xmax,q.top,halo,q.height);
 ghosts.push({piece:{...q.piece,support,solid:q.grainDensity*measure(support).area},face});
}
for(const [face,top,bed]of[['top',-halo,-1],['bottom',domain.zmax,-2]])ghosts.push({piece:{support:rectangle(domain.x0-halo,top,domain.xmax-domain.x0+2*halo,halo),bed,solid:0,fraction:0,burial:0,loading:0},face});
const sources=[...source.map(piece=>({piece,face:'interior'})),...ghosts];
for(let sourceIndex=0;sourceIndex<sources.length;sourceIndex++){
 const {piece,face}=sources[sourceIndex],cut=cutFault(piece.support,graph);
 const parts=[...cut.footwall.map(support=>({support,side:'footwall',before:support})),...cut.hangingWall.flatMap(before=>deformHangingWall(before,F,slip).map(support=>({support,side:'hangingWall',before})))];
 for(const part of parts){
  const support=intersectBox(part.support,domain.x0,0,domain.xmax,domain.zmax);
  if(!support)continue;
  if(unresolved.some(p=>p.index===outputIndex)&&!minimal)minimal={sourceIndex,outputIndex,source:piece,sourceFace:face,faultGraph:graph,F,slip,domain,side:part.side,cut:part.before,transported:part.support,clipped:support,geometry:inspect(support)};
  outputIndex++;
 }
}
const paths=['geometricSupport.ts','ownedProfiles.ts','domainThrust.ts','../integration/ownedSurface.ts','../review/ownedColumns.ts','capture-horizontal-witness.mjs'];
const hashes=Object.fromEntries(await Promise.all(paths.map(async path=>[path,createHash('sha256').update(await readFile(new URL(path,root))).digest('hex')])));
const receipt={schema:'earthforge.horizontal-support-admission-witness.v1',case:'coupled-compression-a',h:40,step:before.step,status:'rejected-before-compaction; no correction applied',sourceHashes:hashes,unresolvedCount:unresolved.length,unresolved,minimal,transport:moved.diagnostics};
await writeFile(new URL('horizontal-support-witness.json',root),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({unresolvedCount:unresolved.length,minimal,transport:moved.diagnostics},null,2));
