import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { build } from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
const root=new URL('.',import.meta.url);
const witness=JSON.parse(await readFile(new URL('horizontal-support-witness.json',root),'utf8'));
const actual=createHash('sha256').update(await readFile(new URL('horizontal-support-before-fix.ts',root))).digest('hex');
assert.equal(actual,witness.sourceHashes['geometricSupport.ts'],'Frozen source changed');
const bundle=await build({entryPoints:[new URL('horizontal-support-before-fix.ts',root).pathname],bundle:true,format:'esm',platform:'node',write:false});
const {intersectBox,measure,world}=await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString('base64')}`);
const {transported,domain,clipped:expected}=witness.minimal;
const support=intersectBox(transported,domain.x0,0,domain.xmax,domain.zmax);
assert.deepEqual(support,expected);
const geometry=measure(support),vertices=support.ring.map(q=>world(support,q));
assert(geometry.area>0);
assert(vertices.every(q=>q[0]===domain.x0));
assert.deepEqual(support.xBounds,[domain.x0,domain.x0]);
// TwoSum recovers the exact error of adding these two finite binary64 values.
// The authored local chart extends beyond its declared right boundary by this
// residual, although its rounded world vertices all lie on that boundary.
const a=transported.origin[0],b=transported.axes[0][0],rounded=a+b;
const z=rounded-a,residual=(a-(rounded-z))+(b-z);
const result={schema:'earthforge.horizontal-support-minimal-reproducer.v1',status:'known admission failure reproduced; no correction applied',sourceHash:witness.sourceHashes['geometricSupport.ts'],sourceFace:witness.minimal.sourceFace,side:witness.minimal.side,sourceRightBoundary:transported.xBounds[1],roundedChartRightBoundary:rounded,exactBinary64ChartRightResidual:residual,area:geometry.area,chartArea:geometry.chartArea,worldVertices:vertices,xBounds:support.xBounds,expectedAdmissionError:'Unresolved horizontal support extent'};
await writeFile(new URL('horizontal-support-reproducer-result.json',root),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
