import {build} from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
import {writeFileSync,readFileSync} from 'node:fs';import{createHash}from'node:crypto';
const root=new URL('../../',import.meta.url).pathname;
const b=await build({stdin:{contents:'export * from "./review/ownedColumns";export * from "./design/geometricSupport";',resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const a=await import('data:text/javascript;base64,'+Buffer.from(b.outputFiles[0].contents).toString('base64'));
const delta=2**-40,ps=[];
for(const[left,width]of[[0,delta],[delta,40-delta]])for(const[bed,top,height,rho]of[[-1,0,100,0],[0,100,100,.5],[-2,200,800,0]])ps.push({support:a.rectangle(left,top,width,height),bed,solid:bed<0?0:width*height*rho,fraction:.37,burial:0,loading:0});
let evidence;try{const r=a.deformOwnedColumns(ps,{h:40,x0:0,xmax:40,zmax:1000},[{carbonate:false}],null,{porosity:()=>.5,effectiveDepth:d=>d},{mode:'compact',constitutiveTolerance:1e-10});const mapped=r.mapSegments([[[0,150],[40,150]]]);evidence={status:'completed',delta,first:mapped[0][0],last:mapped.at(-1)[1],segments:mapped,sourceGrains:ps.reduce((n,p)=>n+p.solid,0),resultGrains:r.pieces.reduce((n,p)=>n+p.solid,0),diagnostics:r.diagnostics};}catch(e){evidence={status:'rejected',delta,error:e.message};}
evidence.sourceSha256=createHash('sha256').update(readFileSync(root+'review/ownedColumns.ts')).digest('hex');writeFileSync(new URL('short-segment.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence));
