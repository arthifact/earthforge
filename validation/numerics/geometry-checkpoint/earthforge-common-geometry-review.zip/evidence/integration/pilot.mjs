import { build } from '/Users/torus/Desktop/Research/earthforge/node_modules/esbuild/lib/main.js';
import { writeFile } from 'node:fs/promises';
const root = new URL('.', import.meta.url);
const bundle = await build({ stdin: { contents: `export * from '../metrics/baseline/src/basin'; export * from './ownedSurface'; export * from '../design/domainThrust'; export * from '../design/geometricSupport'; export * from '../design/ownedProfiles'; export * from '../review/ownedColumns';`, resolveDir: root.pathname }, bundle: true, format: 'esm', platform: 'node', write: false });
const { simulate, BASIN_DEFAULTS, flowLine, initializeOwned, deformDomainThrust, deformOwnedColumns, porosity, effectiveDepth, ownedProfile, measure } = await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString('base64')}`);
let before, witness;
const stop = new Error('captured');
try {
  simulate({ ...BASIN_DEFAULTS, seed: 765184, h: 40, setting: 'compression', overpressure: 1, record: false }, state => {
    if (state.process === 'subsidence' && state.faults.length === 0) before = structuredClone({ columns: state.columns, nx: state.nx, nz: state.nz, h: state.h, step: state.step, beds: state.beds, overpressure: state.overpressure });
    if (state.process === 'thrust-slip') { witness = structuredClone(state.faults[0]); throw stop; }
  });
} catch (e) { if (e !== stop) throw e; }
const domain = { h: before.h, x0: -2000 - before.h / 2, xmax: -2000 - before.h / 2 + before.nx * before.h, zmax: before.nz * before.h };
const receipt = { case: 'coupled-compression-a', h: 40, stage: 'first thrust only; integration admission, not completed comparison', step: before.step, domain, status: 'running' };
try {
  const source = initializeOwned(before.columns, domain), F = flowLine(witness.thrust.points);
  receipt.sourcePieces = source.length;
  const start = performance.now();
  const moved = deformDomainThrust(source, F, witness.heaves[0], domain);
  receipt.transport = { ...moved.diagnostics, seconds: (performance.now() - start) / 1000 };
  let maxGap = 0, maxOverlap = 0, worst = null;
  for (let i = 0; i < before.nx; i++) {
    const profile = ownedProfile(moved.pieces, -2000 + i * before.h); let last = 0;
    for (const p of profile) { if(Math.abs(p.top-last)>Math.max(maxGap,maxOverlap)) worst={x:-2000+i*before.h, priorBottom:last, section:{top:p.top,bottom:p.bottom,height:p.height,bed:p.piece.bed,support:p.piece.support}}; maxGap = Math.max(maxGap, p.top - last); maxOverlap = Math.max(maxOverlap, Math.max(0, Math.min(last,p.bottom)-p.top)); last = Math.max(last,p.bottom); }
    maxGap = Math.max(maxGap, domain.zmax - last);
  }
  receipt.partition = { maxGap, maxOverlap, worst };
  let maxRockOverlap=0, rockWitness=null, maxDistinctBedOverlap=0, distinctBedWitness=null;
  for(let i=0;i<before.nx;i++) {
    const x=-2000+i*before.h, profile=ownedProfile(moved.pieces,x).filter(p=>p.piece.bed!==-1); let last=null;
    for(const p of profile) {
      if(last && Math.min(last.bottom,p.bottom)-p.top>maxRockOverlap) { maxRockOverlap=Math.min(last.bottom,p.bottom)-p.top;rockWitness={x,beds:[last.piece.bed,p.piece.bed],upperBottom:last.bottom,lowerTop:p.top}; }
      if(last && last.piece.bed!==p.piece.bed && Math.min(last.bottom,p.bottom)-p.top>maxDistinctBedOverlap) { maxDistinctBedOverlap=Math.min(last.bottom,p.bottom)-p.top; distinctBedWitness={x,beds:[last.piece.bed,p.piece.bed],upperBottom:last.bottom,lowerTop:p.top}; }
      if(!last || p.bottom>last.bottom)last=p;
    }
  }
  receipt.rockPartition={maxRockOverlap,rockWitness,maxDistinctBedOverlap,distinctBedWitness};
  const collapsed = deformOwnedColumns(moved.pieces, domain, before.beds, before.overpressure, { porosity, effectiveDepth }, { mode: 'collapse' });
  receipt.collapse = collapsed.diagnostics;
  const compacted = deformOwnedColumns(collapsed.pieces, domain, before.beds, before.overpressure, { porosity, effectiveDepth }, { mode: 'compact' });
  receipt.compaction = compacted.diagnostics;
  receipt.status = 'passed-first-thrust-admission';
} catch (e) {
  receipt.status = 'rejected'; receipt.reason = String(e.message);
  receipt.stack = String(e.stack).replace(/data:text\/javascript;base64,[A-Za-z0-9+/=]+/g, '[bundle]').split('\n').slice(0, 8);
}
await writeFile(new URL('pilot-receipt.json', root), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
