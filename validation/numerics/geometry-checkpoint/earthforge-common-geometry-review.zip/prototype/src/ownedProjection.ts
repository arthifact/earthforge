import { cellIntersections, measure, world, type MaterialPiece } from './geometricSupport';
import { ownedProfile, type MaterialSection } from './ownedProfiles';
import { exactLengthScale } from './exactLength';
import { addParcel, emptyInventory } from './sedimentBudget';
import { layerLengths, withLayerLengths, rasterize, type Column, type Layer } from './strata';

/** Geometry is authoritative. These stacks are compatibility projections only;
 * do not use them to reconstruct material support or to update the geometry. */
export interface ProjectionGrid { nx: number; nz: number; h: number; x0: number; }
export interface InertProjectionAdjustment {
  column: number; row: number | null; bed: number; added: boolean;
  lengths: number[]; height: number; limit: number;
}
export interface CellProjectionDiagnostic {
  column: number; row: number; pieces: number; rawHeight: number;
  exactHeightResidual: number; rawSolidHeight: number; adjustment: InertProjectionAdjustment | null;
}
export interface PieceProjectionDiagnostic {
  piece: number; bed: number; sourceArea: number; projectedArea: number;
  areaResidual: number; sourceSolid: number; projectedSolid: number; solidResidual: number;
}
export interface ProfileDiagnostic {
  x: number; side: 'right' | 'left'; pieces: number; rawHeight: number;
  exactHeightResidual: number; adjustment: InertProjectionAdjustment | null;
}
const sum = (values: readonly number[]) => {
  let s = 0, c = 0;
  for (const x of values) { const n = s + x; c += Math.abs(s) >= Math.abs(x) ? (s - n) + x : (x - n) + s; s = n; }
  return s + c;
};
function payload(p: MaterialPiece, height: number, solid: number): Layer {
  if (!(height > 0) || !Number.isFinite(height) || !Number.isFinite(solid) || solid < 0) throw Error('Unrepresentable positive projection');
  return { bed: p.bed, height, solid, fraction: p.fraction, burial: p.burial, loading: p.loading, offsetX: 0, offsetZ: 0 };
}
function validate(p: MaterialPiece) {
  const area = measure(p.support).area;
  if (!(area > 0) || !Number.isInteger(p.bed) || p.bed < -2 || ![p.solid,p.fraction,p.burial,p.loading].every(Number.isFinite) || p.solid < 0 || p.solid > area || p.fraction < 0 || p.fraction > 1 || p.burial < 0 || p.loading < 0) throw Error('Invalid owned material payload');
  if (p.bed < 0 && p.solid !== 0) throw Error('Inert material cannot contain sediment grains');
  return area;
}
/** This is an explicit compatibility-projection roundoff gate, not a geometric
 * overlap/gap tolerance. It never certifies the input partition or alters it. */
export const projectionRoundoffLimit = (extent: number, terms: number) =>
  64 * Number.EPSILON * Math.max(Math.abs(extent), Number.MIN_VALUE) * (1 + Math.ceil(Math.log2(Math.max(1,terms))));
function completeInertExtent(parts: Column, extent: number, column: number, row: number | null) {
  if (!parts.length) throw Error('Empty owned projection');
  const scale = exactLengthScale([extent,...parts.flatMap(layerLengths)]), target = scale.units(extent);
  const lengths = parts.map(p=>layerLengths(p).reduce((n,h)=>n+scale.units(h),0n));
  const total = lengths.reduce((a,b)=>a+b,0n), difference = target-total;
  const residual = scale.number(difference < 0n ? -difference : difference) * (difference < 0n ? -1 : 1);
  const limit = projectionRoundoffLimit(extent,parts.length);
  if (difference === 0n) return { residual, adjustment: null as InertProjectionAdjustment | null };
  if (Math.abs(residual) > limit) throw Error(`Owned projection does not fill extent: residual ${residual}, limit ${limit}`);
  // Alter only the compatibility length of an existing zero-grain inert piece.
  // Prefer the largest, so a physically distinct tiny inert interval survives.
  const inert = parts.map((p,j)=>({p,j})).filter(({p})=>(p.bed===-1||p.bed===-2)&&p.solid===0)
    .sort((a,b)=>b.p.height-a.p.height)[0];
  if (!inert) throw Error(`Sediment-only projection has nonzero exact extent residual ${residual}; no grain/height normalization is permitted`);
  const next = lengths[inert.j]+difference;
  if (!(next > 0n)) throw Error('Projection correction would erase an inert interval');
  parts[inert.j] = withLayerLengths(inert.p,scale.chunks(next));
  return { residual, adjustment: { column,row,bed:inert.p.bed,added:difference>0n,lengths:scale.chunks(difference<0n?-difference:difference),height:Math.abs(residual),limit } };
}

/** Integral overlap projection, h-wide cells including both endpoint columns.
 * piece.solid is area; output Layer.solid is solid height. Water and basement
 * must be present in the same input partition. Outside support is an error;
 * clipping/flux accounting belongs to the geometry operator, not this export. */
export function projectOwnedSupport(pieces: readonly MaterialPiece[], grid: ProjectionGrid) {
  const {nx,nz,h,x0}=grid;
  if (!Number.isInteger(nx)||nx<=0||!Number.isInteger(nz)||nz<=0||!(h>0)||![h,x0,nx*h,nz*h].every(Number.isFinite)) throw Error('Invalid projection grid');
  const cells: {part:Layer;cx:number;cz:number;source:number}[][] = Array.from({length:nx*nz},()=>[]);
  const pieceDiagnostics: PieceProjectionDiagnostic[]=[];
  for (let source=0;source<pieces.length;source++) {
    const p=pieces[source],area=validate(p),areas:number[]=[],solids:number[]=[];
    for (const hit of cellIntersections(p.support,h,x0,0)) {
      const q=measure(hit.support),{i,k}=hit;
      if(i<0||i>=nx||k<0||k>=nz)throw Error(`Owned support lies outside projection domain: piece ${source}, cell ${i}/${k}`);
      const height=q.area/h,solid=p.solid*(q.area/area)/h;
      if(p.solid>0&&solid===0)throw Error('Positive grain projection underflows; cannot discard material');
      const part=payload(p,height,solid);
      cells[k*nx+i].push({part,cx:q.centroid[0],cz:q.centroid[1],source});
      areas.push(q.area);solids.push(solid*h);
    }
    const projectedArea=sum(areas),projectedSolid=sum(solids);
    if(!(projectedArea>0))throw Error('Positive support disappeared during projection');
    const areaResidual=projectedArea-area,solidResidual=projectedSolid-p.solid;
    const limit=projectionRoundoffLimit(area,areas.length*8);
    if(Math.abs(areaResidual)>limit)throw Error(`Owned area lost in cell intersection: piece ${source}, residual ${areaResidual}`);
    if(Math.abs(solidResidual)>projectionRoundoffLimit(p.solid,solids.length*8))throw Error(`Owned grains lost in cell intersection: piece ${source}, residual ${solidResidual}`);
    pieceDiagnostics.push({piece:source,bed:p.bed,sourceArea:area,projectedArea,areaResidual,sourceSolid:p.solid,projectedSolid,solidResidual});
  }
  const areaColumns:Column[]=Array.from({length:nx},()=>[]),columnRows:typeof cells=Array.from({length:nx},()=>[]),cellDiagnostics:CellProjectionDiagnostic[]=[];
  const adjustments:InertProjectionAdjustment[]=[];
  for(let k=0;k<nz;k++)for(let i=0;i<nx;i++) {
    const rows=cells[k*nx+i];
    // Centroid order affects this nonphysical storage projection only; true
    // vertical order is queried from owned polygons by physicalProfileColumn.
    rows.sort((a,b)=>a.cz-b.cz||a.source-b.source);
    const parts=rows.map(q=>q.part),rawHeight=sum(parts.map(p=>p.height)),rawSolidHeight=sum(parts.map(p=>p.solid));
    const scale=exactLengthScale([h,...parts.flatMap(layerLengths)]),total=parts.reduce((n,p)=>n+scale.units(p.height),0n),difference=scale.units(h)-total;
    const residual=scale.number(difference<0n?-difference:difference)*(difference<0n?-1:1);
    if(Math.abs(residual)>projectionRoundoffLimit(h,parts.length))throw Error(`Owned cell does not form a full area partition: ${i}/${k}, residual ${residual}`);
    areaColumns[i].push(...parts);columnRows[i].push(...rows);
    cellDiagnostics.push({column:i,row:k,pieces:parts.length,rawHeight,exactHeightResidual:residual,rawSolidHeight,adjustment:null});
  }
  for(let i=0;i<nx;i++) {
    const completion=completeInertExtent(areaColumns[i],nz*h,i,null);if(completion.adjustment)adjustments.push(completion.adjustment);
    let top=0;
    for(let j=0;j<areaColumns[i].length;j++) {
      const p=areaColumns[i][j],q=columnRows[i][j];
      p.offsetX=q.cx-(x0+(i+.5)*h);p.offsetZ=q.cz-(top+p.height/2);top+=p.height;
    }
  }
  const raster=rasterize(areaColumns,nz,h);
  if(raster.domainAdjustments.length||raster.bottomOutside.size)throw Error('Exact area projection unexpectedly required a second domain correction');
  return {areaColumns,raster,diagnostics:{kind:'integral area projection; never authoritative physical geometry',pieceDiagnostics,cellDiagnostics,
    sourceSolidArea:sum(pieces.map(p=>p.solid)),projectedSolidArea:sum(areaColumns.flatMap(c=>c.map(p=>p.solid*h))),
    adjustments}};
}

function sectionEndpoint(s:MaterialSection,which:'topLocal'|'bottomLocal'):number[] {
  const tagged=which==='topLocal'?s.topWorldNode:s.bottomWorldNode;
  // Explicit shared-node coordinates have already been resolved by the owned
  // section query. Re-evaluating their chart expression can invent an ULP gap.
  if(tagged!==null)return[tagged];
  const p=s.piece.support,q=s[which];
  // Untagged endpoints keep the three terms separate: adding a sub-ULP sheet
  // to a large origin would collapse a physically distinct positive extent.
  return[p.origin[1],p.axes[0][1]*q[0],p.axes[1][1]*q[1]];
}
function exactDifference(a:readonly number[],b:readonly number[]) {
  const scale=exactLengthScale([...a,...b].map(Math.abs));
  const integer=(terms:readonly number[])=>terms.reduce((n,x)=>n+(x<0?-scale.units(-x):scale.units(x)),0n);
  const d=integer(a)-integer(b);
  return {equal:d===0n,value:scale.number(d<0n?-d:d)*(d<0n?-1:1)};
}
/** Exact one-sided line measurement. The caller chooses the limit at vertical
 * seams. It is intentionally distinct from areaColumns: pointwise thickness
 * cannot also be a finite-width material-volume integral in a sloping cell. */
export function physicalProfileColumn(pieces:readonly MaterialPiece[],x:number,end:number,side:'right'|'left'='right') {
  if(!(end>0)||!Number.isFinite(end))throw Error('Invalid physical profile extent');
  for(const p of pieces)validate(p);
  const sections=ownedProfile(pieces,x,side);
  if(!sections.length)throw Error('No material at physical profile');
  const column:Column=[];let previous:number[]=[0];
  for(const s of sections) {
    const gap=exactDifference(sectionEndpoint(s,'topLocal'),previous);
    if(!gap.equal)throw Error(`Owned physical profile has ${gap.value>0?'gap':'overlap'} ${gap.value} at x=${x}; cannot pack geometry into a false profile`);
    const p=payload(s.piece,s.height,s.solidHeight);
    if(s.piece.solid>0&&p.solid===0)throw Error('Positive physical profile grains underflow');
    column.push(p);previous=sectionEndpoint(s,'bottomLocal');
  }
  const trailing=exactDifference(previous,[end]);
  if(!trailing.equal)throw Error(`Physical profile endpoint does not equal domain: ${trailing.value}`);
  const rawHeight=sum(column.map(p=>p.height)),completion=completeInertExtent(column,end,-1,null);
  const diagnostics:ProfileDiagnostic={x,side,pieces:column.length,rawHeight,exactHeightResidual:completion.residual,adjustment:completion.adjustment};
  return{column,sections,diagnostics};
}
export function physicalProfileColumns(pieces:readonly MaterialPiece[],grid:ProjectionGrid) {
  const {nx,nz,h,x0}=grid;
  const index=indexOwnedProfiles(pieces,grid);
  const result=Array.from({length:nx},(_,i)=>physicalProfileColumn(index[i],x0+(i+.5)*h,nz*h));
  return{profileColumns:result.map(q=>q.column),diagnostics:result.map(q=>q.diagnostics)};
}

/** Broad-phase index only; ownedProfile still decides exact one-sided line
 * ownership. One neighboring column is retained on both sides of a rounded
 * world bound, so the acceleration cannot decide thin-piece membership. */
export function indexOwnedProfiles(pieces:readonly MaterialPiece[],grid:ProjectionGrid) {
  const {nx,h,x0}=grid;
  if(!Number.isInteger(nx)||nx<=0||!(h>0)||![x0,h].every(Number.isFinite))throw Error('Invalid profile grid');
  const index:MaterialPiece[][]=Array.from({length:nx},()=>[]);
  for(const p of pieces){validate(p);const xs=p.support.ring.map(q=>world(p.support,q)[0]);
    if(!xs.length||!xs.every(Number.isFinite))throw Error('Invalid profile support bounds');
    const lo=Math.max(0,Math.floor((Math.min(...xs)-x0)/h)-1),hi=Math.min(nx-1,Math.ceil((Math.max(...xs)-x0)/h)+1);
    for(let i=lo;i<=hi;i++)index[i].push(p);
  }
  return index;
}
/** Direct grain inventory in square metres. Physical line profiles must never
 * be integrated as if they were finite-width cell-average inventories. */
export function inventoryOfOwnedSupport(pieces:readonly MaterialPiece[],beds:readonly {carbonate:boolean}[]) {
  const out=emptyInventory();
  for(const p of pieces){validate(p);if(p.bed>=0){if(!beds[p.bed])throw Error('Unknown owned material bed');addParcel(out,p.bed,p.solid,p.fraction,beds[p.bed].carbonate,1);}}
  return out;
}
