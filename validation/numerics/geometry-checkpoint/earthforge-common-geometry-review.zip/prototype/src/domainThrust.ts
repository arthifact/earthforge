import {affineMap,cellIntersections,cutFault,deformHangingWall,halfPlane,intersectBox,measure,rectangle,type FlowLine,type MaterialPiece,type Support,type V} from './geometricSupport';
import {ownedProfile,verticalSection} from './ownedProfiles';
export interface OwnedDomain {h:number;x0:number;xmax:number;zmax:number;}
type Face='left'|'right'|'top'|'bottom';
export interface DomainFlux {inflow:Record<Face,MaterialPiece[]>;outflow:Record<Face,MaterialPiece[]>;}
const faces:Face[]=['left','right','top','bottom'];
const emptyFaces=():Record<Face,MaterialPiece[]>=>({left:[],right:[],top:[],bottom:[]});
const cloneWith=(piece:MaterialPiece,support:Support):MaterialPiece=>({...piece,support,solid:piece.solid*measure(support).area/measure(piece.support).area});
const dummy=(support:Support,bed:number):MaterialPiece=>({support,bed,solid:0,fraction:0,burial:0,loading:0});
const extentArea=(d:OwnedDomain)=>(d.xmax-d.x0)*d.zmax;
/** External material is anchored at its shared inner face. Keeping that face
 * at local coordinate zero makes contact-only clipping exactly zero without
 * inferring zero thickness from rounded world-coordinate extent bounds. */
export function boundaryGhostRectangle(face:Face,domain:OwnedDomain,halo:number,top?:number,height?:number):Support{
  const {x0,xmax,zmax}=domain;
  if(face==='left'||face==='right'){
    if(top===undefined||height===undefined)throw Error('Missing side profile extent');
    const p=rectangle(face==='left'?x0-halo:xmax,top,halo,height);
    if(face==='left'){p.origin[0]=x0;p.axes[0][0]=-halo;}
    return p;
  }
  const p=rectangle(x0-halo,face==='top'?-halo:zmax,xmax-x0+2*halo,halo);
  if(face==='top'){p.origin[1]=0;p.axes[1][1]=-halo;}
  return p;
}
const sum=(values:Iterable<number>)=>{let total=0,correction=0;for(const value of values){const next=total+value;correction+=Math.abs(total)>=Math.abs(value)?(total-next)+value:(value-next)+total;total=next;}return total+correction;};
const totalArea=(pieces:readonly MaterialPiece[])=>sum(pieces.map(p=>measure(p.support).area));
const assertNear=(a:number,b:number,message:string)=>{if(Math.abs(a-b)>1e-7+2e-11*Math.max(Math.abs(a),Math.abs(b)))throw Error(`${message}: ${a} != ${b}`);};
/** Continue the end-segment lines across the halo. This is necessary when
 * compaction/subsidence has tilted an outer segment: horizontal graph extension
 * would disagree with the infinite outer flow tangent. */
export function extendedFaultGraph(F:FlowLine,left:number,right:number):V[]{
  if(F.P.length<2)throw Error('Invalid fault graph');
  const P=F.P,forward=P.at(-1)![0]>P[0][0];
  const extrapolate=(a:V,b:V,x:number):V=>{if(a[0]===b[0])throw Error('Vertical outer fault segment');return[x,a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0])];};
  const first=forward?Math.min(left,P[0][0]):Math.max(right,P[0][0]);
  const last=forward?Math.max(right,P.at(-1)![0]):Math.min(left,P.at(-1)![0]);
  return [...(first===P[0][0]?[]:[extrapolate(P[0],P[1],first)]),...P.map(p=>[...p] as V),...(last===P.at(-1)![0]?[]:[extrapolate(P.at(-1)!,P.at(-2)!,last)])];
}
/** Full water + basement + sediment partition required. The ghost rule is
 * physical side-profile extrusion, external water above, and basement below.
 * Bottom sediment is deliberately rejected rather than inventing its source.
 * Flux face labels identify the disjoint donor/outflow partition; no correction
 * of missing area, negative pores, or grains is performed. */
export function deformDomainThrust(pieces:readonly MaterialPiece[],F:FlowLine,slip:number,domain:OwnedDomain,options:{cellOverlay?:boolean}={}){
  const {h,x0,xmax,zmax}=domain;
  if(![h,x0,xmax,zmax,slip].every(Number.isFinite)||!(h>0&&xmax>x0&&zmax>0))throw Error('Invalid owned domain');
  assertNear(totalArea(pieces),extentArea(domain),'Input is not a full-domain area partition');
  const flux:DomainFlux={inflow:emptyFaces(),outflow:emptyFaces()};
  if(slip===0)return{pieces:pieces.map(p=>({...p,support:{...p.support,origin:[...p.support.origin] as V,axes:p.support.axes.map(v=>[...v]) as [V,V],ring:p.support.ring.map(v=>[...v] as V),...(p.support.xBounds?{xBounds:[...p.support.xBounds] as [number,number]}:{}),...(p.support.vertexX?{vertexX:[...p.support.vertexX]}:{})}})),flux,diagnostics:{sourcePieces:pieces.length,ghostPieces:0,outputPieces:pieces.length,areaBefore:totalArea(pieces),areaAfter:totalArea(pieces),grainResidual:0}};
  const halo=Math.abs(slip)+h,cutP=extendedFaultGraph(F,x0-halo-h,xmax+halo+h);
  const ghosts:{piece:MaterialPiece;face:Face}[]=[];
  for(const face of ['left','right'] as const){
    const profile=ownedProfile(pieces,face==='left'?x0:xmax,face==='left'?'right':'left');
    assertNear(profile.reduce((s,q)=>s+q.height,0),zmax,`Incomplete ${face} boundary profile`);
    for(const q of profile){const support=boundaryGhostRectangle(face,domain,halo,q.top,q.height);
      ghosts.push({piece:{...q.piece,support,solid:q.grainDensity*measure(support).area},face});}
  }
  // The bottom continuation is explicitly checked at its actual physical face.
  let bottomWidth=0;
  for(const p of pieces){const rotated=affineMap(p.support,[[0,1],[-1,0]],[p.support.origin[1],-p.support.origin[0]],1),section=verticalSection(rotated,zmax,'left');
    if(!section)continue;bottomWidth+=section.height;
    if(p.bed!==-2)throw Error('Bottom boundary continuation requires basement; found sediment or water');
  }
  assertNear(bottomWidth,xmax-x0,'Incomplete basement boundary');
  ghosts.push({piece:dummy(boundaryGhostRectangle('top',domain,halo),-1),face:'top'});
  ghosts.push({piece:dummy(boundaryGhostRectangle('bottom',domain,halo),-2),face:'bottom'});
  const output:MaterialPiece[]=[];
  const moved=(p:MaterialPiece)=>{const area=measure(p.support).area,cut=cutFault(p.support,cutP);return[...cut.footwall,...cut.hangingWall.flatMap(q=>deformHangingWall(q,F,slip))].map(support=>({...p,support,solid:p.solid*measure(support).area/area}));};
  const addInside=(p:MaterialPiece)=>{const support=intersectBox(p.support,x0,0,xmax,zmax);if(!support)return null;const inside=cloneWith(p,support);
    if(options.cellOverlay){for(const q of cellIntersections(support,h,x0,0))output.push(cloneWith(inside,q.support));}
    else output.push(inside);return inside;};
  for(const p of pieces)for(const q of moved(p)){
    addInside(q);
    const left=halfPlane(q.support,[-1,0],[x0,0]),right=halfPlane(q.support,[1,0],[xmax,0]);
    if(left)flux.outflow.left.push(cloneWith(q,left));if(right)flux.outflow.right.push(cloneWith(q,right));
    let middle=halfPlane(q.support,[1,0],[x0,0]);if(middle)middle=halfPlane(middle,[-1,0],[xmax,0]);
    if(middle){const top=halfPlane(middle,[0,-1],[0,0]),bottom=halfPlane(middle,[0,1],[0,zmax]);if(top)flux.outflow.top.push(cloneWith(q,top));if(bottom)flux.outflow.bottom.push(cloneWith(q,bottom));}
  }
  for(const {piece,face}of ghosts)for(const q of moved(piece)){const inside=addInside(q);if(inside)flux.inflow[face].push(inside);}
  const areaAfter=totalArea(output),areaBefore=totalArea(pieces);
  assertNear(areaAfter,extentArea(domain),'Transport lost full-domain support coverage');
  const grains=(pp:readonly MaterialPiece[])=>sum(pp.filter(p=>p.bed>=0).map(p=>p.solid));
  const incoming=faces.reduce((s,f)=>s+grains(flux.inflow[f]),0),outgoing=faces.reduce((s,f)=>s+grains(flux.outflow[f]),0);
  const grainResidual=grains(output)-grains(pieces)-incoming+outgoing;
  const grainTolerance=1e-6+1e-10*Math.max(grains(output),grains(pieces),incoming,outgoing);
  if(Math.abs(grainResidual)>grainTolerance)throw Error(`Open-boundary grain budget failed: ${grainResidual}`);
  return{pieces:output,flux,diagnostics:{sourcePieces:pieces.length,ghostPieces:ghosts.length,outputPieces:output.length,areaBefore,areaAfter,grainResidual,incomingGrains:incoming,outgoingGrains:outgoing}};
}
