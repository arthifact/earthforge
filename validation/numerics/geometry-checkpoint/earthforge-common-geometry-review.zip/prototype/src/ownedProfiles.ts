import { measure, world, type MaterialPiece, type Support, type V } from './geometricSupport';
export interface Section {
  x: number; top: number; bottom: number; height: number;
  /** Retained chart depths are authoritative for small differences; world
   * top/bottom are compatibility coordinates and may round to the same Number. */
  originZ: number; topOffset: number; bottomOffset: number; topLocal: V; bottomLocal: V;
  /** Declared shared depth node, or null when endpoint comparison must retain
   * the local chart expression. Rounded compatibility top/bottom alone never
   * promote an untagged sub-ULP material interface to an authoritative node. */
  topWorldNode: number | null; bottomWorldNode: number | null;
}
/** Exact affine-chart section through a convex owned polygon, within ordinary
 * floating-point predicate accuracy. The chosen one-sided limit avoids counting
 * both children when a profile lies exactly on a vertical remap seam. */
export function verticalSection(p: Support, x: number, side: 'right' | 'left' = 'right'): Section | null {
  if (!Number.isFinite(x)) throw Error('Invalid profile coordinate');
  if (!p.ring.length) return null;
  if (p.xBounds && (side === 'right' ? !(x >= p.xBounds[0] && x < p.xBounds[1]) : !(x > p.xBounds[0] && x <= p.xBounds[1]))) return null;
  const a=p.axes[0][0],b=p.axes[1][0],c=p.origin[0]-x;
  const rawValue=(q:V)=>c+a*q[0]+b*q[1],values=p.ring.map((q,i)=>p.vertexX?.[i]===x?0:rawValue(q));
  if(!values.every(Number.isFinite))throw Error('Invalid section predicate');
  const lo=Math.min(...values),hi=Math.max(...values);
  if(side==='right' ? !(lo<=0&&hi>0) : !(lo<0&&hi>=0))return null;
  const hits:{local:V;z:number|null;node:number|null}[]=[];
  let u=p.ring.at(-1)!,fu=values.at(-1)!,zu=p.vertexZ?.at(-1)??null;
  for(const [index,v] of p.ring.entries()){const fv=values[index],zv=p.vertexZ?.[index]??null;
    if(fu===0)hits.push({local:[...u],z:zu??world(p,u)[1],node:zu});
    if(fu<0&&fv>0||fu>0&&fv<0){
      // Incident polygons traverse a literal shared chart edge in opposite
      // directions. Choose one endpoint order before evaluating its cut node
      // so both owners perform exactly the same floating-point operations.
      // This establishes equality only for exact shared endpoints; it does
      // not match nearby edges or merge genuinely distinct thin interfaces.
      const forward=u[0]<v[0]||u[0]===v[0]&&u[1]<v[1];
      const start=forward?u:v,end=forward?v:u,fStart=forward?fu:fv,fEnd=forward?fv:fu;
      const t=fStart/(fStart-fEnd);
      let z=zu!==null&&zu===zv?zu:null;
      let node=z;
      // Different local charts can own the same literal world edge. Their
      // compatibility depth comes from one canonical WORLD endpoint order,
      // while local intersection and Jacobian thickness stay authoritative.
      // No coordinate proximity or thin-interface merging is used. If the
      // world endpoints cannot resolve the event, keep the local chart value.
      const wu=world(p,u),wv=world(p,v),worldForward=wu[0]<wv[0]||wu[0]===wv[0]&&wu[1]<wv[1];
      const ws=worldForward?wu:wv,we=worldForward?wv:wu;
      if(z===null&&ws[0]<we[0]&&x>=ws[0]&&x<=we[0]){
        z=x===ws[0]?ws[1]:x===we[0]?we[1]:ws[1]+((x-ws[0])/(we[0]-ws[0]))*(we[1]-ws[1]);
        // Only explicit depth provenance can create an authoritative node.
        // Canonical projection of ordinary rounded world endpoints remains a
        // compatibility coordinate, especially for unresolved thin sheets.
        if(zu!==null&&zv!==null)node=z;
        else if(x===wu[0]&&zu!==null)node=zu;
        else if(x===wv[0]&&zv!==null)node=zv;
      }
      hits.push({local:[start[0]+t*(end[0]-start[0]),start[1]+t*(end[1]-start[1])],z,node});
    }
    u=v;fu=fv;zu=zv;
  }
  if(hits.length<2)return null;
  const norm0=Math.max(Math.abs(p.axes[0][0]),Math.abs(p.axes[0][1])),norm1=Math.max(Math.abs(p.axes[1][0]),Math.abs(p.axes[1][1]));
  const det=(p.axes[0][0]/norm0)*(p.axes[1][1]/norm1)-(p.axes[0][1]/norm0)*(p.axes[1][0]/norm1);
  if(!Number.isFinite(det)||det===0)throw Error('Unresolved affine-chart orientation');
  const useV=Math.abs(a)>=Math.abs(b),component=useV?1:0,denominator=useV?a:b;
  hits.sort((u,v)=>u.local[component]-v.local[component]);
  let topHit=hits[0],bottomHit=hits.at(-1)!;
  const height=p.jacobian*Math.abs((bottomHit.local[component]-topHit.local[component])/denominator);
  if(!(height>=0)||!Number.isFinite(height))throw Error('Invalid section height');
  if(height===0)return null;
  const slopeSign=useV?Math.sign(det)*Math.sign(a):-Math.sign(det)*Math.sign(b);
  if(slopeSign<0)[topHit,bottomHit]=[bottomHit,topHit];
  const topLocal=topHit.local,bottomLocal=bottomHit.local;
  const offset=(q:V)=>p.axes[0][1]*q[0]+p.axes[1][1]*q[1];
  const topOffset=topHit.z===null?offset(topLocal):topHit.z-p.origin[1],bottomOffset=bottomHit.z===null?offset(bottomLocal):bottomHit.z-p.origin[1];
  return{x,top:topHit.z??(p.origin[1]+topOffset),bottom:bottomHit.z??(p.origin[1]+bottomOffset),height,originZ:p.origin[1],topOffset,bottomOffset,topLocal:[...topLocal],bottomLocal:[...bottomLocal],topWorldNode:topHit.node,bottomWorldNode:bottomHit.node};
}
export interface MaterialSection extends Section {
  piece: MaterialPiece; solidHeight: number; grainDensity: number;
}
export function ownedProfile(pieces: readonly MaterialPiece[],x:number,side:'right'|'left'='right'):MaterialSection[]{
  const out:MaterialSection[]=[];
  for(const piece of pieces){const section=verticalSection(piece.support,x,side);if(!section)continue;
    const area=measure(piece.support).area;
    if(!(area>0))throw Error('Profile encountered empty material support');
    const grainDensity=piece.solid/area;
    out.push({...section,piece,grainDensity,solidHeight:grainDensity*section.height});
  }
  out.sort((a,b)=>(a.originZ-b.originZ)+(a.topOffset-b.topOffset));
  return out;
}
