/** Local geometric ALE prototype. Convex owned support is retained through the
 * deformation and target-cell intersection; centroids are diagnostics only.
 * See shared-map-contract.json for scope and primary-method references. */
export type V = [number, number];
export interface Support {
  /** Affine chart keeps thin extents separate from large world coordinates. */
  origin: V; axes: [V, V]; ring: V[]; jacobian: number;
  /** Exact axis-aligned clipping bounds for half-open profile ownership. */
  xBounds?: [number, number]; zBounds?: [number, number];
  /** Exact world x of vertices created on declared vertical cuts. null means
   * unconstrained; this avoids epsilon snapping when querying a cell seam. */
  vertexX?: (number | null)[]; vertexZ?: (number | null)[];
}
export interface FlowLine { P: V[]; t: V[]; n: V[]; b: V[]; m: V[] }
export interface MaterialPiece {
  support: Support; bed: number; solid: number; fraction: number; burial: number; loading: number;
}
const dot = (a: V, b: V) => a[0] * b[0] + a[1] * b[1];
const sub = (a: V, b: V): V => [a[0] - b[0], a[1] - b[1]];
const copy = (p: Support): Support => ({ origin: [...p.origin], axes: [[...p.axes[0]], [...p.axes[1]]], ring: p.ring.map(v => [...v]), jacobian: p.jacobian, ...(p.xBounds ? {xBounds: [...p.xBounds] as [number,number]} : {}), ...(p.vertexX ? {vertexX: [...p.vertexX]} : {}), ...(p.zBounds ? {zBounds: [...p.zBounds] as [number,number]} : {}), ...(p.vertexZ ? {vertexZ: [...p.vertexZ]} : {}) });
export function world(p: Support, q: V): V {
  const index=p.ring.indexOf(q),x=index<0?null:p.vertexX?.[index],z=index<0?null:p.vertexZ?.[index];
  return [x??(p.origin[0]+p.axes[0][0]*q[0]+p.axes[1][0]*q[1]),z??(p.origin[1]+p.axes[0][1]*q[0]+p.axes[1][1]*q[1])];
}
export function rectangle(left: number, top: number, width: number, height: number): Support {
  if (![left, top, width, height].every(Number.isFinite) || !(width > 0 && height > 0) || !(width * height > 0) || !Number.isFinite(width * height)) throw Error('Invalid representable rectangle');
  return { origin: [left, top], axes: [[width, 0], [0, height]], ring: [[0, 0], [1, 0], [1, 1], [0, 1]], jacobian: width * height, xBounds: [left, left + width], zBounds: [top, top + height] };
}
export function measure(p: Support) {
  const o = p.ring[0] ?? [0, 0]; let area2 = 0, mx = 0, mz = 0;
  for (let i = 1; i + 1 < p.ring.length; i++) {
    const a = sub(p.ring[i], o), b = sub(p.ring[i + 1], o), cross = a[0] * b[1] - a[1] * b[0];
    area2 += cross; mx += cross * (a[0] + b[0]); mz += cross * (a[1] + b[1]);
  }
  const area = Math.abs(area2) * p.jacobian / 2;
  if (!Number.isFinite(area) || (area2 !== 0 && area === 0)) throw Error('Support area is outside floating-point range');
  const local: V = area2 ? [o[0] + mx / (3 * area2), o[1] + mz / (3 * area2)] : [...o];
  return { area, centroid: world(p, local), localCentroid: local, chartArea: Math.abs(area2) / 2 };
}
/** Closed half-plane clipping. No positive-area epsilon or thin-piece cutoff. */
export function clip(p: Support, value: (local: V) => number, cutX?: number, cutZ?: number): Support | null {
  if (!p.ring.length) return null;
  const out: V[] = [], tags: (number | null)[] = [], tagsZ: (number|null)[] = []; let a = p.ring.at(-1)!, fa = value(a), tagA = p.vertexX?.at(-1) ?? null, tagZA=p.vertexZ?.at(-1)??null;
  for (const [index,b] of p.ring.entries()) {
    const fb = value(b), tagB = p.vertexX?.[index] ?? null, tagZB=p.vertexZ?.[index]??null;
    if (!Number.isFinite(fa) || !Number.isFinite(fb)) throw Error('Invalid clipping predicate');
    if ((fa >= 0) !== (fb >= 0)) {
      const t = fa / (fa - fb); out.push([a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])]);
      tags.push(cutX ?? (tagA !== null && tagA === tagB ? tagA : null));
      tagsZ.push(cutZ ?? (tagZA !== null && tagZA === tagZB ? tagZA : null));
    }
    if (fb >= 0) { out.push([...b]); tags.push(fb === 0 && cutX !== undefined ? cutX : tagB); tagsZ.push(fb === 0 && cutZ !== undefined ? cutZ : tagZB); }
    a = b; fa = fb; tagA = tagB; tagZA=tagZB;
  }
  const candidate = { ...p, ring: out, vertexX: tags, vertexZ: tagsZ };
  return measure(candidate).area > 0 ? candidate : null;
}
export function halfPlane(p: Support, normal: V, point: V, positive = true) {
  const c = dot(sub(p.origin, point), normal), u = dot(p.axes[0], normal), v = dot(p.axes[1], normal), sign = positive ? 1 : -1;
  const axis = normal[1] === 0 && normal[0] !== 0 ? 0 : normal[0] === 0 && normal[1] !== 0 ? 1 : null;
  const value=(q:V)=>{
    // Declared cut nodes are authoritative in every consumer, including the
    // predicate. Re-evaluating their chart expansion can turn exact contact
    // into a spurious positive outside-domain fragment. Untagged nodes retain
    // their full local chart predicate, including genuinely sub-ULP extents.
    if(axis!==null){const index=p.ring.indexOf(q),tag=axis===0?p.vertexX?.[index]:p.vertexZ?.[index];
      if(tag!==undefined&&tag!==null)return sign*normal[axis]*(tag-point[axis]);}
    return sign*(c+u*q[0]+v*q[1]);
  };
  const out = clip(p, value, normal[1] === 0 && normal[0] !== 0 ? point[0] : undefined, normal[0] === 0 && normal[1] !== 0 ? point[1] : undefined);
  if (out && normal[1] === 0 && normal[0] !== 0) {
    const bounds: [number,number] = [...(p.xBounds ?? [-Infinity, Infinity])];
    if (sign * normal[0] > 0) bounds[0] = Math.max(bounds[0], point[0]);
    else bounds[1] = Math.min(bounds[1], point[0]);
    out.xBounds = bounds;
  }
  if (out && normal[0] === 0 && normal[1] !== 0) {
    const bounds: [number,number] = [...(p.zBounds ?? [-Infinity, Infinity])];
    if (sign * normal[1] > 0) bounds[0] = Math.max(bounds[0], point[1]);
    else bounds[1] = Math.min(bounds[1], point[1]);
    out.zBounds = bounds;
  }
  return out;
}
export function intersectBox(p: Support, left: number, top: number, right: number, bottom: number): Support | null {
  let q: Support | null = p;
  for (const [normal, point] of [ [[1,0],[left,0]], [[-1,0],[right,0]], [[0,1],[0,top]], [[0,-1],[0,bottom]] ] as [V,V][]) {
    if (q) q = halfPlane(q, normal, point);
  }
  return q;
}
/** Fault graphs extend horizontally beyond their endpoint controls, matching
 * the basin's polyline-depth contract. Vertical segments are unsupported. */
export function cutFault(p: Support, fault: readonly V[]): { hangingWall: Support[]; footwall: Support[] } {
  if (fault.length < 2 || fault.some(q => !q.every(Number.isFinite))) throw Error('Invalid fault graph');
  const P = fault[0][0] <= fault.at(-1)![0] ? fault : [...fault].reverse();
  for (let i = 1; i < P.length; i++) if (!(P[i][0] > P[i-1][0])) throw Error('Fault must be an ordered x graph');
  const hangingWall: Support[] = [], footwall: Support[] = [];
  const add = (q: Support | null, normal: V, point: V) => {
    if (!q) return;
    const hw = halfPlane(q, normal, point, true), fw = halfPlane(q, normal, point, false);
    if (hw) hangingWall.push(hw); if (fw) footwall.push(fw);
  };
  add(halfPlane(p, [-1,0], P[0]), [0,-1], P[0]);
  for (let j = 0; j + 1 < P.length; j++) {
    let q = halfPlane(p, [1,0], P[j]);
    if (q) q = halfPlane(q, [-1,0], P[j+1]);
    const d = sub(P[j+1], P[j]); add(q, [d[1], -d[0]], P[j]);
  }
  add(halfPlane(p, [1,0], P.at(-1)!), [0,-1], P.at(-1)!);
  return { hangingWall, footwall };
}
export function affineMap(p: Support, matrix: [V,V], originImage: V, determinant?: number): Support {
  const mul = (v: V): V => [dot(matrix[0], v), dot(matrix[1], v)];
  const det = determinant ?? matrix[0][0]*matrix[1][1] - matrix[0][1]*matrix[1][0];
  if (!(det > 0) || !Number.isFinite(det) || !Number.isFinite(p.jacobian * det) || !(p.jacobian * det > 0) || !originImage.every(Number.isFinite) || !matrix.flat().every(Number.isFinite)) throw Error('Noninvertible or inverted material map');
  const out:Support={ origin: [...originImage], axes: [mul(p.axes[0]), mul(p.axes[1])], ring: p.ring.map(q=>[...q]), jacobian: p.jacobian * det };
  if(matrix[0][0]===1&&matrix[0][1]===0){const shift=originImage[0]-p.origin[0];if(p.xBounds)out.xBounds=p.xBounds.map(v=>v+shift) as [number,number];if(p.vertexX)out.vertexX=p.vertexX.map(v=>v===null?null:v+shift);}
  if(matrix[1][0]===0&&matrix[1][1]===1){const shift=originImage[1]-p.origin[1];if(p.zBounds)out.zBounds=p.zBounds.map(v=>v+shift) as [number,number];if(p.vertexZ)out.vertexZ=p.vertexZ.map(v=>v===null?null:v+shift);}
  return out;
}
/** Split by initial/final flow region before applying its exact affine map.
 * The construction matches flowAreaDisplacement but keeps every support piece. */
export function deformHangingWall(p: Support, F: FlowLine, slip: number): Support[] {
  if (!Number.isFinite(slip) || !F.t.length) throw Error('Invalid thrust flow');
  if (slip === 0) return [copy(p)];
  const count = F.t.length, A = [0], C = [0], B = [0];
  for (let j = 1; j < count; j++) {
    const oldBeta = dot(F.b[j], F.t[j-1]) / dot(F.b[j], F.n[j-1]), newBeta = dot(F.b[j], F.t[j]) / dot(F.b[j], F.n[j]);
    A[j] = A[j-1] + dot(sub(F.P[j], F.P[j-1]), F.t[j-1]); C[j] = C[j-1] + oldBeta - newBeta; B[j] = newBeta + C[j];
  }
  const out: Support[] = []; let remaining: Support | null = p;
  for (let j = 0; j < count && remaining; j++) {
    const source = j === count-1 ? remaining : halfPlane(remaining, F.m[j+1], F.P[j+1], false);
    if (j < count-1) remaining = halfPlane(remaining, F.m[j+1], F.P[j+1]);
    if (!source) continue;
    const delta0 = dot(sub(source.origin, F.P[j]), F.n[j]);
    const distance0 = dot(sub(source.origin, F.P[j]), F.t[j]) + A[j] + C[j]*delta0 + slip;
    let rest: Support | null = source;
    for (let k = 0; k < count && rest; k++) {
      const crossing = (q: V) => {
        const along: V = [F.t[j][0] + (C[j]-B[k+1])*F.n[j][0], F.t[j][1] + (C[j]-B[k+1])*F.n[j][1]];
        return distance0-A[k+1]-B[k+1]*delta0 + dot(source.axes[0], along)*q[0] + dot(source.axes[1], along)*q[1];
      };
      const part = k===count-1 ? rest : clip(rest, q=>-crossing(q));
      if (k < count-1) rest = clip(rest, crossing);
      if (!part) continue;
      if (j === k) {
        // Within one region the map is exactly a translation. Reconstructing
        // a large absolute point from fault coordinates needlessly moves flat
        // interfaces by an ULP and can create spurious boundary-water slivers.
        out.push(affineMap(part, [[1,0],[0,1]], [part.origin[0]+slip*F.t[j][0], part.origin[1]+slip*F.t[j][1]], 1));
        continue;
      }
      const beta: V = [(C[j]-C[k])*F.t[k][0]+F.n[k][0], (C[j]-C[k])*F.t[k][1]+F.n[k][1]];
      const matrix: [V,V] = [[F.t[k][0]*F.t[j][0]+beta[0]*F.n[j][0], F.t[k][0]*F.t[j][1]+beta[0]*F.n[j][1]],
        [F.t[k][1]*F.t[j][0]+beta[1]*F.n[j][0], F.t[k][1]*F.t[j][1]+beta[1]*F.n[j][1]]];
      const u = distance0-A[k]-C[k]*delta0;
      const originImage: V = [F.P[k][0]+F.t[k][0]*u+F.n[k][0]*delta0, F.P[k][1]+F.t[k][1]*u+F.n[k][1]*delta0];
      const det = matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0];
      if (Math.abs(det-1)>1e-12) throw Error('Thrust flow is not area preserving');
      out.push(affineMap(part, matrix, originImage, 1));
    }
  }
  return out;
}
/** Material payload uses area fractions of owned support; no neighboring
 * identity, composition or history is averaged into a piece. */
export function transportPiece(piece: MaterialPiece, F: FlowLine, slip: number) {
  if (slip === 0) return [{ ...piece, support: copy(piece.support) }];
  const area = measure(piece.support).area;
  if (!(area > 0) || !Number.isFinite(piece.solid) || piece.solid < 0) throw Error('Invalid material support or grains');
  const cut = cutFault(piece.support, F.P);
  return [...cut.footwall, ...cut.hangingWall.flatMap(q=>deformHangingWall(q,F,slip))]
    .map(support=>({...piece,support,solid:piece.solid*(measure(support).area/area)}));
}
export function cellIntersections(p: Support, h: number, x0=0, z0=0) {
  if (!(h>0) || !Number.isFinite(h)) throw Error('Invalid grid');
  if (!(measure(p).area > 0)) return [];
  const vertices = p.ring.map(q=>world(p,q));
  if (!vertices.flat().every(Number.isFinite)) throw Error('Invalid support coordinates');
  const xs=vertices.map(q=>q[0]), zs=vertices.map(q=>q[1]);
  const ilo=Math.floor((Math.min(...xs)-x0)/h), ihi=Math.floor((Math.max(...xs)-x0)/h);
  const klo=Math.floor((Math.min(...zs)-z0)/h), khi=Math.floor((Math.max(...zs)-z0)/h);
  const out: {i:number;k:number;support:Support}[]=[];
  for(let k=klo;k<=khi;k++)for(let i=ilo;i<=ihi;i++) {
    const support=intersectBox(p,x0+i*h,z0+k*h,x0+(i+1)*h,z0+(k+1)*h);
    if(support)out.push({i,k,support});
  }
  return out;
}
