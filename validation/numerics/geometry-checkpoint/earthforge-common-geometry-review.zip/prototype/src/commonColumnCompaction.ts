import { compactColumn, emptyLayer, layerLengths, withLayerLengths, type Column, type ColumnPhysics } from './strata';
import { exactLengthScale } from './exactLength';

/** A guarded one-dimensional physical primitive, not a reconstruction of
 * overlapping parcel rectangles. All rock must share one lateral footprint
 * and tile [physical surface, end] exactly. Water is an untracked pore/surface
 * fluid; its stored gaps do not establish physical rock occupancy.
 *
 * Storage translations are removed only after the physical partition has been
 * verified. The existing constitutive solve then acts in physical order. The
 * returned mapDepth is the SAME physical map to apply to fault/material points.
 * It must never receive z-offset and then have offset re-added by its caller.
 */
export function compactPhysicalColumn(column: Column, end: number,
  beds: { carbonate: boolean }[], pressure: number | null, physics: ColumnPhysics) {
  if (!(end > 0) || !Number.isFinite(end) || !column.length)
    throw Error('Invalid physical compaction domain');
  for (const p of column) {
    if (![p.height, p.solid, p.fraction, p.burial, p.loading, p.offsetX, p.offsetZ].every(Number.isFinite) ||
      p.height < 0 || p.solid < 0 || p.solid > p.height || p.fraction < 0 || p.fraction > 1 ||
      p.burial < 0 || p.loading < 0 || !Number.isInteger(p.bed) || p.bed < -2 ||
      (p.bed >= 0 && !beds[p.bed]) || (p.bed < 0 && p.solid !== 0))
      throw Error('Invalid physical compaction constituent');
  }
  const values = [end, ...column.flatMap(p => [...layerLengths(p), Math.abs(p.offsetZ)])];
  const scale = exactLengthScale(values), domain = scale.units(end);
  const signed = (x: number) => x < 0 ? -scale.units(-x) : scale.units(x);
  let cursor = 0n;
  const intervals = column.flatMap((p, source) => {
    const length = layerLengths(p).reduce((sum, h) => sum + scale.units(h), 0n);
    if (scale.number(length) !== p.height) throw Error('Inconsistent physical compaction extent');
    const start = cursor + signed(p.offsetZ); cursor += length;
    if (p.bed === -1 || length === 0n) return [];
    return [{ p, source, start, end: start + length }];
  });
  if (cursor !== domain) throw Error('Storage column does not exactly cover compaction domain');
  if (!intervals.length) return {
    column: [emptyLayer(-1, end)] as Column,
    mapDepth: (z: number) => {
      if (!Number.isFinite(z) || z < 0 || z > end) throw Error('Fault point outside compaction domain');
      return z;
    },
    physicalOffsetX: 0, sourceOrder: [] as number[], oldSurface: end, newSurface: end,
  };
  const physicalOffsetX = intervals[0].p.offsetX;
  if (intervals.some(q => q.p.offsetX !== physicalOffsetX))
    throw Error('Physical compaction requires one common lateral footprint');
  intervals.sort((a, b) => a.start < b.start ? -1 : a.start > b.start ? 1 : a.source - b.source);
  const top = intervals[0].start;
  if (top < 0n || intervals.at(-1)!.end > domain)
    throw Error('Physical rock extends outside compaction domain');
  for (let j = 1; j < intervals.length; j++) {
    if (intervals[j].start < intervals[j - 1].end)
      throw Error('Overlapping physical rock intervals cannot be compacted as a column');
    if (intervals[j].start > intervals[j - 1].end)
      throw Error('Physical rock gap requires an explicit collapse model');
  }
  if (intervals.at(-1)!.end !== domain)
    throw Error('Physical rock does not meet the fixed bottom boundary');
  const canonical: Column = [];
  if (top > 0n) canonical.push(withLayerLengths(emptyLayer(-1, 0), scale.chunks(top)));
  for (const { p } of intervals) canonical.push({ ...p, offsetZ: 0 });
  const checked: ColumnPhysics = {
    porosity: (...args) => {
      const phi = physics.porosity(...args);
      if (!(phi >= 0 && phi < 1) || !Number.isFinite(phi)) throw Error('Invalid physical compaction porosity');
      return phi;
    },
    effectiveDepth: (...args) => {
      const d = physics.effectiveDepth(...args);
      if (!(d >= 0) || !Number.isFinite(d)) throw Error('Invalid physical compaction effective depth');
      return d;
    },
  };
  const result = compactColumn(canonical, beds, pressure, checked);
  const first = result.column.findIndex(p => p.bed !== -1);
  const newSurface = result.column.slice(0, first < 0 ? result.column.length : first).reduce((sum, p) => sum + p.height, 0);
  return { column: result.column,
    mapDepth: (z: number) => {
      if (!Number.isFinite(z) || z < 0 || z > end) throw Error('Fault point outside compaction domain');
      return result.mapDepth(z);
    },
    physicalOffsetX, sourceOrder: intervals.map(q => q.source),
    oldSurface: scale.number(top), newSurface,
  };
}
