import { affineMap, halfPlane, measure, rectangle, world, type MaterialPiece, type Support, type V } from './geometricSupport';
import { ownedProfile, verticalSection } from './ownedProfiles';
import { depositedLayer, type Column, type ColumnPhysics } from './strata';

export interface Domain { h: number; x0: number; xmax: number; zmax: number }
export interface SurfaceFacet { left: number; right: number; topLeft: number; topRight: number }
const water = (support: Support): MaterialPiece => ({ support, bed: -1, solid: 0, fraction: 0, burial: 0, loading: 0 });
const portion = (p: MaterialPiece, support: Support): MaterialPiece => ({ ...p, support, solid: p.solid * measure(support).area / measure(p.support).area });

/** One convex trapezoid. Horizontal differences remain local so a thin bed
 * need not be represented as the subtraction of two large world depths. */
export function trapezoid(left: number, right: number, topLeft: number, topRight: number, heightLeft: number, heightRight: number): Support | null {
  const width = right - left, height = Math.max(heightLeft, heightRight);
  if (!(width > 0) || heightLeft < 0 || heightRight < 0 || ![left, right, topLeft, topRight, heightLeft, heightRight].every(Number.isFinite)) throw Error('Invalid surface trapezoid');
  if (height === 0) return null;
  return { origin: [left, topLeft], axes: [[width, topRight - topLeft], [0, height]],
    ring: [[0, 0], [1, 0], [1, heightRight / height], [0, heightLeft / height]], jacobian: width * height, xBounds: [left, right] };
}

/** Initialization is allowed only before any slot translation: offsets do not
 * contain enough information to reconstruct an already-deformed polygon. */
export function initializeOwned(columns: readonly Column[], domain: Domain): MaterialPiece[] {
  if (![domain.h, domain.x0, domain.xmax, domain.zmax].every(Number.isFinite) || !(domain.h > 0 && domain.zmax > 0) || columns.length * domain.h !== domain.xmax - domain.x0) throw Error('Initial columns do not cover the horizontal domain');
  const out: MaterialPiece[] = [];
  for (let i = 0; i < columns.length; i++) {
    let z = 0;
    for (let j = 0; j < columns[i].length; j++) {
      const p = columns[i][j];
      if (![p.height, p.solid, p.fraction, p.burial, p.loading, p.offsetX, p.offsetZ].every(Number.isFinite) || p.height < 0 || p.solid < 0 || p.solid > p.height || p.fraction < 0 || p.fraction > 1 || p.burial < 0 || p.loading < 0 || !Number.isInteger(p.bed) || p.bed < -2 || (p.bed < 0 && p.solid !== 0)) throw Error('Invalid initial material');
      if (p.offsetX !== 0 || p.offsetZ !== 0) throw Error('Cannot reconstruct owned support from translated parcel centers');
      let height = p.height;
      if (height > 0 && z + height === z) throw Error('Unresolved shared vertical interface in owned initialization');
      if (j === columns[i].length - 1 && p.bed === -2 && p.solid === 0) {
        // The exact interval column may have a rounded Number sum. Anchor only
        // its terminal inert basement to the declared physical bottom.
        const remainder = domain.zmax - z;
        if (Math.abs(remainder - height) > 32 * Number.EPSILON * domain.zmax * columns[i].length) throw Error('Initial inert bottom adjustment exceeds arithmetic error');
        height = remainder;
      }
      if (height > 0) out.push({ support: rectangle(domain.x0 + i * domain.h, z, domain.h, height),
        bed: p.bed, solid: p.solid * domain.h, fraction: p.fraction, burial: p.burial, loading: p.loading });
      z += height;
    }
    if (Math.abs(z - domain.zmax) > 1e-8) throw Error('Initial support does not fill the domain');
  }
  return out;
}

/** Local x-event sweep of the exposed rock envelope. This reads actual owned
 * support, never the center or area-equivalent thickness of a storage parcel. */
export function surfaceFacets(pieces: readonly MaterialPiece[], domain: Domain): SurfaceFacet[] {
  const nx = Math.round((domain.xmax - domain.x0) / domain.h);
  const buckets: MaterialPiece[][] = Array.from({ length: nx }, () => []);
  for (const p of pieces) {
    if (p.bed === -1) continue;
    const xs = p.support.ring.map(q => world(p.support, q)[0]);
    const lo = Math.max(0, Math.floor((Math.min(...xs) - domain.x0) / domain.h));
    const hi = Math.min(nx - 1, Math.ceil((Math.max(...xs) - domain.x0) / domain.h) - 1);
    for (let i = lo; i <= hi; i++) buckets[i].push(p);
  }
  const facets: SurfaceFacet[] = [];
  for (let i = 0; i < nx; i++) {
    const left = domain.x0 + i * domain.h, right = left + domain.h, local = buckets[i];
    const events = [...new Set([left, right, ...local.flatMap(p => p.support.ring.map(q => world(p.support, q)[0])).filter(x => x > left && x < right)])].sort((a, b) => a - b);
    for (let j = 0; j + 1 < events.length; j++) {
      const a = events[j], b = events[j + 1], mid = a + (b - a) / 2;
      if (!(mid > a && mid < b)) throw Error('Surface interval below coordinate resolution');
      const first = ownedProfile(local, mid)[0];
      if (!first) { facets.push({ left: a, right: b, topLeft: domain.zmax, topRight: domain.zmax }); continue; }
      // Sample within the same convex edge interval. No endpoint ownership
      // ambiguity and no extrapolation across a polygon vertex.
      const x1 = a + (b - a) / 4, x2 = a + 3 * (b - a) / 4;
      const s1 = verticalSection(first.piece.support, x1), s2 = verticalSection(first.piece.support, x2);
      if (!s1 || !s2) throw Error('Exposed support does not span its surface slab');
      const dz = (s2.originZ - s1.originZ) + (s2.topOffset - s1.topOffset);
      const z1 = s1.top;
      facets.push({ left: a, right: b, topLeft: z1 - dz / 2, topRight: z1 + 3 * dz / 2 });
    }
  }
  return facets;
}

/** Affine regional subsidence has determinant one. The open bottom exports
 * exactly the clipped sediment, and the newly exposed top is explicit water. */
export function subsideOwned(pieces: readonly MaterialPiece[], domain: Domain, displacement: { atLeft: number; gradient: number }) {
  if (!displacement || typeof displacement !== 'object' || ![displacement.atLeft, displacement.gradient].every(Number.isFinite)) throw Error('Owned subsidence requires explicit affine displacement coefficients');
  const slope = displacement.gradient, shift = (x: number) => displacement.atLeft + slope * (x - domain.x0);
  const s0 = shift(domain.x0), s1 = shift(domain.xmax);
  if (Math.min(s0, s1) < 0 || Math.max(s0, s1) >= domain.zmax) throw Error('Owned subsidence requires positive in-domain downshift');
  const retained: MaterialPiece[] = [], outflowBottom: MaterialPiece[] = [];
  for (const p of pieces) {
    const support = affineMap(p.support, [[1, 0], [slope, 1]], [p.support.origin[0], p.support.origin[1] + shift(p.support.origin[0])], 1);
    const q = { ...p, support };
    const inside = halfPlane(support, [0, -1], [0, domain.zmax]);
    const outside = halfPlane(support, [0, 1], [0, domain.zmax]);
    if (inside) retained.push(portion(q, inside));
    if (outside) outflowBottom.push(portion(q, outside));
  }
  const top = trapezoid(domain.x0, domain.xmax, 0, 0, s0, s1);
  if (top) retained.push(water(top));
  return { pieces: retained, outflowBottom, mapPoint: ([x, z]: V): V => [x, z + shift(x)] };
}

export function erodeOwned(pieces: readonly MaterialPiece[], domain: Domain, waveBase: number) {
  if (waveBase <= 0) return { pieces: pieces.slice(), eroded: [] as MaterialPiece[] };
  if (!(waveBase < domain.zmax)) throw Error('Wave base below model bottom');
  const retained: MaterialPiece[] = [], eroded: MaterialPiece[] = [];
  for (const p of pieces) {
    const low = halfPlane(p.support, [0, 1], [0, waveBase]);
    const high = halfPlane(p.support, [0, -1], [0, waveBase]);
    if (low) retained.push(portion(p, low));
    if (high && p.bed !== -1) eroded.push(portion(p, high));
  }
  retained.push(water(rectangle(domain.x0, 0, domain.xmax - domain.x0, waveBase)));
  return { pieces: retained, eroded };
}

export interface DepositPlan {
  first: number; count: number; fill: number; drape: number;
  base: (x: number) => number; fraction: (bed: number, x: number) => number;
  beds: { carbonate: boolean }[]; pressure: number | null; physics: ColumnPhysics;
}
/** Deposition follows the exposed surface, including partial-width relief.
 * Horizontal composition/constitutive quadrature is one midpoint per surface
 * slab; vertical quadrature is the existing 10 m depositedLayer rule. */
export function depositOwned(pieces: readonly MaterialPiece[], domain: Domain, plan: DepositPlan) {
  if (!(plan.fill >= 0 && plan.fill <= 1) || !(plan.drape >= 0) || !Number.isInteger(plan.count) || plan.count < 1) throw Error('Invalid deposition plan');
  const facets = surfaceFacets(pieces, domain);
  // Surface deposition may replace only surface water. Check the actual water
  // supports, not merely their area sum (which could conceal offsetting holes).
  for (const p of pieces) if (p.bed === -1) {
    const xs = p.support.ring.map(q => world(p.support, q)[0]);
    const lo = Math.min(...xs), hi = Math.max(...xs);
    if (lo < domain.x0 || hi > domain.xmax) throw Error('Water support outside surface domain');
    for (const f of facets) {
      if (f.right <= lo || f.left >= hi) continue;
      let q = halfPlane(p.support, [1, 0], [f.left, 0]);
      if (q) q = halfPlane(q, [-1, 0], [f.right, 0]);
      if (q) q = halfPlane(q, [-(f.topRight - f.topLeft) / (f.right - f.left), 1], [f.left, f.topLeft]);
      if (q) throw Error('Surface deposition requires physical internal-water collapse first');
    }
  }
  const next = pieces.filter(p => p.bed !== -1), deposited: MaterialPiece[] = [];
  let thickest = 0;
  for (const facet of facets) {
    const { left, right } = facet, zAt = (x: number) => facet.topLeft + (facet.topRight - facet.topLeft) * (x - left) / (right - left);
    const events = [left, right];
    const d0 = facet.topLeft - plan.base(left), d1 = facet.topRight - plan.base(right);
    if (d0 * d1 < 0) events.push(left + (right - left) * d0 / (d0 - d1));
    events.sort((a, b) => a - b);
    for (let e = 0; e + 1 < events.length; e++) {
      const a = events[e], b = events[e + 1];
      const thick = (x: number) => Math.max(0, zAt(x) - plan.base(x)) * plan.fill + plan.drape;
      const cuts = [a, b];
      // Each depositional boundary is affine between forcing switches. Split
      // its sea-level crossing explicitly before constructing trapezoids.
      for (let k = 0; k <= plan.count; k++) {
        const l = zAt(a) - thick(a) * (1 - k / plan.count), r = zAt(b) - thick(b) * (1 - k / plan.count);
        if (l * r < 0) cuts.push(a + (b - a) * l / (l - r));
      }
      cuts.sort((x, y) => x - y);
      for (let c = 0; c + 1 < cuts.length; c++) {
        const l = cuts[c], r = cuts[c + 1]; if (!(r > l)) continue;
        const m = l + (r - l) / 2;
        const boundary = (x: number, k: number) => Math.max(0, zAt(x) - thick(x) * (1 - k / plan.count));
        const floorL = boundary(l, 0), floorR = boundary(r, 0), floorM = boundary(m, 0);
        const waterSupport = trapezoid(l, r, 0, 0, floorL, floorR);
        if (waterSupport) next.push(water(waterSupport));
        thickest = Math.max(thickest, thick(l), thick(r));
        for (let j = 0; j < plan.count; j++) {
          const id = plan.first + j, loL = boundary(l, j), loR = boundary(r, j);
          const hL = boundary(l, j + 1) - loL, hR = boundary(r, j + 1) - loR, hM = (hL + hR) / 2;
          if (!(hM > 0)) {
            if (thick(m) > 0 && boundary(m, j + 1) > 0) throw Error('Unresolved positive deposited bed: shared chart-node boundaries required');
            continue;
          }
          const fraction = plan.fraction(id, m);
          const quadrature = depositedLayer(id, hM, fraction, plan.beds[id].carbonate, boundary(m, j) - floorM, plan.pressure, plan.physics);
          let t = 0;
          for (const q of quadrature) {
            const dt = q.height / hM, support = trapezoid(l, r, loL + hL * t, loR + hR * t, hL * dt, hR * dt);
            if (!support) throw Error('Positive deposited material lost its support');
            const p = { support, bed: id, solid: measure(support).area * q.solid / q.height, fraction, burial: q.burial, loading: q.loading };
            next.push(p); deposited.push(p); t += dt;
          }
        }
      }
    }
  }
  return { pieces: next, deposited, thickest };
}
