import { affineMap, halfPlane, measure, rectangle, world, type MaterialPiece, type Support, type V } from './geometricSupport';
import { ownedProfile, verticalSection, type MaterialSection } from './ownedProfiles';
import type { ColumnPhysics } from './strata';
export interface OwnedDomain { h:number; x0:number; xmax:number; zmax:number }
export interface OwnedOptions { mode:'compact'|'collapse'|'compact-and-collapse'; maxSlabWidth?:number; constitutiveTolerance?:number }
export interface FaceMap { x:number; z:number[]; image:number[]; map:(z:number)=>number }
export interface MapRegion { support:Support; matrix:[V,V]; originImage:V; determinant:number; source:number }
export interface OwnedSlab { left:number; right:number; surfaceLeft:number; surfaceRight:number; mappedSurfaceLeft:number; mappedSurfaceRight:number }
const finite=(x:number)=>Number.isFinite(x);
const clone=(p:MaterialPiece):MaterialPiece=>({...p,support:{...p.support,origin:[...p.support.origin],axes:p.support.axes.map(v=>[...v]) as [V,V],ring:p.support.ring.map(v=>[...v]),...(p.support.xBounds?{xBounds:[...p.support.xBounds] as [number,number]}:{}),...(p.support.vertexX?{vertexX:[...p.support.vertexX]}:{}),...(p.support.zBounds?{zBounds:[...p.support.zBounds] as [number,number]}:{}),...(p.support.vertexZ?{vertexZ:[...p.support.vertexZ]}:{})}});
const vertices=(p:Support):V[]=>p.ring.map((q,i)=>{const v=world(p,q);return[p.vertexX?.[i]??v[0],v[1]];});
const interp=(a:number,b:number,t:number)=>a+(b-a)*t;
const EPS=128*Number.EPSILON;
/** Conforming, local column deformation prototype. Polygon topology uses the
 * supplied owned geometry, never centroids. Endpoint maps use the least-
 * contraction admissible envelope of the two one-sided column laws. This is an
 * explicit lateral closure; constitutive mismatch is measured, not hidden.
 * World vertex coordinates must resolve vertical interfaces. Sub-ULP chart
 * pieces are rejected before mutation until shared chart-node support exists. */
export function deformOwnedColumns(input:readonly MaterialPiece[], domain:OwnedDomain,
 beds:readonly {carbonate:boolean}[],pressure:number|null,physics:ColumnPhysics,options:OwnedOptions) {
 const {h,x0,xmax,zmax}=domain, compact=options.mode!=='collapse', collapse=options.mode!=='compact';
 if(![h,x0,xmax,zmax].every(finite)||!(h>0&&xmax>x0&&zmax>0)||!input.length)throw Error('Invalid owned column domain');
 const maxWidth=options.maxSlabWidth??h;
 if(!(maxWidth>0)||!finite(maxWidth))throw Error('Invalid local quadrature width');
 if(options.constitutiveTolerance!==undefined&&(!(options.constitutiveTolerance>=0)||!finite(options.constitutiveTolerance)))throw Error('Invalid constitutive tolerance');
 const pieces=input.map(clone), nx=Math.ceil((xmax-x0)/h), bins=Array.from({length:nx},()=>[] as number[]);
 const area=pieces.map((p,n)=>{const a=measure(p.support).area;
  if(!(a>0)||!finite(p.solid)||p.solid<0||p.solid>a*(1+EPS)||!finite(p.fraction)||p.fraction<0||p.fraction>1||!finite(p.loading)||!finite(p.burial)||p.loading<0||p.burial<0||!Number.isInteger(p.bed)||p.bed< -2||(p.bed>=0&&!beds[p.bed])||(p.bed<0&&p.solid!==0))throw Error('Invalid owned material');
  const v=vertices(p.support),xs=v.map(q=>q[0]),zs=v.map(q=>q[1]),lo=Math.min(...xs),hi=Math.max(...xs);
  if(!v.flat().every(finite)||lo<x0||hi>xmax||Math.min(...zs)<0||Math.max(...zs)>zmax)throw Error('Owned material outside domain');
  if(!(hi>lo))throw Error('Unresolved horizontal support extent');
  for(let i=Math.max(0,Math.floor((lo-x0)/h));i<=Math.min(nx-1,Math.ceil((hi-x0)/h)-1);i++)bins[i].push(n);
  return a;
 });
 const sourceIndex=new Map(pieces.map((p,n)=>[p,n]));
 const rho=pieces.map((p,i)=>p.bed===-2?1:p.solid/area[i]);
 let maxCoverageDefect=0;
 const verify=(sections:MaterialSection[])=>{
  if(!sections.length)throw Error('Missing physical column coverage');
  let end=0;
  for(const p of sections){
   if(!(p.bottom>p.top))throw Error('Unresolved shared vertical interface: retain chart-node geometry before compaction');
   maxCoverageDefect=Math.max(maxCoverageDefect,Math.abs(p.top-end));
   // No tolerance-based deletion or snapping of positive material intervals.
   if(p.top!==end)throw Error(`Owned physical partition has a gap or overlap (${p.top-end}m)`);
   end=p.bottom;
  }
  maxCoverageDefect=Math.max(maxCoverageDefect,Math.abs(end-zmax));
  if(end!==zmax)throw Error('Owned physical partition does not cover domain bottom');
  if(!collapse){let rock=false;for(const p of sections){if(p.piece.bed!==-1)rock=true;else if(rock)throw Error('Compaction requires physical water collapse first');}}
  return sections;
 };
 const candidates=(x:number)=>{const i=Math.floor((x-x0)/h),ids=new Set<number>();for(const j of[i-1,i,i+1])if(bins[j])for(const n of bins[j])ids.add(n);return [...ids].map(n=>pieces[n]);};
 const checkedDepth=(d:number)=>{const q=physics.effectiveDepth(Math.max(0,d),pressure);if(!(q>=0)||!finite(q))throw Error('Invalid effective depth');return q;};
 const porosity=(p:MaterialPiece,d:number)=>{const q=physics.porosity(p.fraction,Math.max(p.loading,checkedDepth(d)),beds[p.bed].carbonate);if(!(q>=0&&q<1)||!finite(q))throw Error('Invalid porosity');return q;};
 const profiles=new Map<string,MaterialSection[]>();
 const profile=(x:number,side:'left'|'right')=>{const key=x+':'+side;let q=profiles.get(key);if(!q){q=verify(ownedProfile(candidates(x),x,side));profiles.set(key,q);}return q;};
 const faceCache=new Map<number,FaceMap>();
 const makeFace=(x:number):FaceMap=>{
  const cached=faceCache.get(x);if(cached)return cached;
  const sides=[] as MaterialSection[][];if(x>x0)sides.push(profile(x,'left'));if(x<xmax)sides.push(profile(x,'right'));
  const z=[...new Set([0,zmax,...sides.flatMap(q=>q.flatMap(p=>[p.top,p.bottom]))])].sort((a,b)=>a-b);
  const surfaces=sides.map(q=>q.find(p=>p.piece.bed!==-1)?.top??zmax),top=Math.min(...surfaces),topIndex=z.indexOf(top);
  if(top===zmax){const out={x,z,image:[...z],map:(v:number)=>v};faceCache.set(x,out);return out;}
  const T=new Array(z.length).fill(0),pointer=sides.map(()=>0);
  for(let j=topIndex;j+1<z.length;j++){
   const H=z[j+1]-z[j],mid=(z[j]+z[j+1])/2;
   const owners=sides.map((q,k)=>{while(pointer[k]+1<q.length&&q[pointer[k]].bottom<=mid)pointer[k]++;return q[pointer[k]];});
   const target=(r:number)=>Math.max(...owners.map((s,k)=>{
    const p=s.piece;if(p.bed===-1)return owners.every(o=>o.piece.bed===-1)?(collapse?0:1):0;if(p.bed===-2||!compact)return 1;
    const floorIndex=z.indexOf(surfaces[k]),depth=T[j]-T[floorIndex]+r*H/2;
    return Math.min(1,s.grainDensity/(1-porosity(p,depth)));
   }));
   let r=1;
   if(target(1)<1){let lo=Math.max(...owners.map(s=>s.piece.bed===-2?1:s.grainDensity)),hi=1;
    for(let n=0;n<48;n++){const m=(lo+hi)/2;if(m<target(m))lo=m;else hi=m;}r=(lo+hi)/2;
    if(owners.every(s=>s.piece.bed===-1)&&collapse)r=0;
   }
   T[j+1]=T[j]+r*H;
  }
  const shift=zmax-T.at(-1)!;
  const image=z.map((v,j)=>j<topIndex?(top>0?v*shift/top:shift):shift+T[j]);
  const map=(v:number)=>{if(v<0||v>zmax||!finite(v))throw Error('Point outside common map');let j=0;while(j+1<z.length-1&&v>z[j+1])j++;return interp(image[j],image[j+1],(v-z[j])/(z[j+1]-z[j]));};
  const out={x,z,image,map};faceCache.set(x,out);return out;
 };
 const regions:MapRegion[]=[],slabs:OwnedSlab[]=[],out:MaterialPiece[]=[],ownership:number[]=[],oldAreas:number[]=[],outSlab:number[]=[];
 const sourceOutputs=pieces.map(()=>[] as number[]),sourceAreas=pieces.map(()=>0),regionBins=bins.map(()=>[] as number[]);
 let currentStrip=0,currentSlab=0,affineFastPaths=0;
 let minDeterminant=Infinity,collapsedWaterArea=0,addedWaterArea=0;
 const addSupport=(support:Support,matrix:[V,V],originImage:V,r:number,source:number,vertexImageZ?:number[])=>{
  if(!finite(r)||r<0||!matrix.flat().every(finite))throw Error('Invalid common material map');
  const oldArea=measure(support).area;
  regionBins[currentStrip].push(regions.length);regions.push({support,matrix,originImage,determinant:r,source});sourceAreas[source]+=oldArea;
  if(r===0){if(pieces[source].bed!==-1)throw Error('Common map collapsed material grains');collapsedWaterArea+=oldArea;return;}
  minDeterminant=Math.min(minDeterminant,r);
  const mapped=affineMap(support,matrix,originImage,r),newArea=measure(mapped).area,p=pieces[source];
  // These maps keep x exactly; preserve authoritative vertical-cut ownership.
  if(support.xBounds)mapped.xBounds=[...support.xBounds];
  if(support.vertexX)mapped.vertexX=[...support.vertexX];
  // A conforming output uses the shared face-node images, not a second
  // independently rounded evaluation of its affine chart at that same node.
  if(vertexImageZ){mapped.vertexZ=[...vertexImageZ];mapped.zBounds=[Math.min(...vertexImageZ),Math.max(...vertexImageZ)];}
  if(r+EPS<rho[source]&&p.bed!==-1)throw Error('Common map overcompacts material below grain area');
  sourceOutputs[source].push(out.length);outSlab.push(currentSlab);
  out.push({...p,support:mapped,solid:p.solid*oldArea/area[source]});ownership.push(source);oldAreas.push(oldArea);
  if(p.bed===-1&&newArea<oldArea)collapsedWaterArea+=oldArea-newArea;
 };
 const addTriangle=(v:[V,V,V],g:[number,number,number],source:number)=>{
  const u:V=[v[1][0]-v[0][0],v[1][1]-v[0][1]],w:V=[v[2][0]-v[0][0],v[2][1]-v[0][1]],jac=u[0]*w[1]-u[1]*w[0];
  if(jac===0)return;if(!(jac>0))throw Error('Inverted source column triangle');
  const sameX=v[0][0]===v[2][0],a=sameX?0:1,b=2,r=(g[b]-g[a])/(v[b][1]-v[a][1]);
  const shear=(g[1]-g[0]-r*u[1])/u[0];
  const support:Support={origin:[...v[0]],axes:[u,w],ring:[[0,0],[1,0],[0,1]],jacobian:jac,xBounds:[Math.min(...v.map(q=>q[0])),Math.max(...v.map(q=>q[0]))],vertexX:v.map(q=>q[0]),vertexZ:v.map(q=>q[1])};
  addSupport(support,[[1,0],[shear,r]],[v[0][0],g[0]],r,source,g);
 };
 const edgeNodes=(support:Support,x:number,side:'left'|'right',face:FaceMap)=>{
  const q=verticalSection(support,x,side),boundary=vertices(support).filter(p=>p[0]===x);
  const lo=q?.top??Math.min(...boundary.map(p=>p[1])),hi=q?.bottom??Math.max(...boundary.map(p=>p[1]));
  if(!finite(lo)||!finite(hi))throw Error('Unresolved local trapezoid endpoint');
  return [...new Set([lo,...face.z.filter(z=>z>lo&&z<hi),hi])].sort((a,b)=>a-b);
 };
 for(let i=0;i<nx;i++){
  currentStrip=i;
  const l=x0+i*h,r=Math.min(xmax,l+h),events=[l,r];
  for(const n of bins[i])for(const q of vertices(pieces[n].support)){const x=q[0];if(x>l&&x<r)events.push(x);}
  const coarse=[...new Set(events)].sort((a,b)=>a-b),cuts:number[]=[];
  for(let j=0;j+1<coarse.length;j++){const count=Math.ceil((coarse[j+1]-coarse[j])/maxWidth);for(let k=0;k<count;k++)cuts.push(interp(coarse[j],coarse[j+1],k/count));}cuts.push(r);
  for(let j=0;j+1<cuts.length;j++){
   const left=cuts[j],right=cuts[j+1],L=makeFace(left),R=makeFace(right),middle=(left+right)/2;
   const mid=verify(ownedProfile(bins[i].map(n=>pieces[n]),middle));
   const sourceSurface=(x:number,side:'left'|'right')=>profile(x,side).find(s=>s.piece.bed!==-1)?.top??zmax;
   const surfaceLeft=sourceSurface(left,'right'),surfaceRight=sourceSurface(right,'left');
   const slab={left,right,surfaceLeft,surfaceRight,mappedSurfaceLeft:L.map(surfaceLeft),mappedSurfaceRight:R.map(surfaceRight)};currentSlab=slabs.length;slabs.push(slab);
   for(const section of mid){const source=sourceIndex.get(section.piece)!;let q=halfPlane(pieces[source].support,[1,0],[left,0]);if(q)q=halfPlane(q,[-1,0],[right,0]);if(!q)continue;
    const a=edgeNodes(q,left,'right',L),b=edgeNodes(q,right,'left',R);let m=0,n=0;
    // A full horizontal stack (and any exactly affine trapezoid) needs one
    // region, not two new material fragments at every repeated call.
    if(a.length>1&&b.length>1){
     const ratio=(L.map(a.at(-1)!)-L.map(a[0]))/(a.at(-1)!-a[0]);
     const leftIntercept=L.map(a[0])-ratio*a[0],rightIntercept=R.map(b[0])-ratio*b[0];
     const affineLeft=a.every(z=>L.map(z)===ratio*z+leftIntercept),affineRight=b.every(z=>R.map(z)===ratio*z+rightIntercept);
     if(affineLeft&&affineRight){const shear=(rightIntercept-leftIntercept)/(right-left),matrix:[V,V]=[[1,0],[shear,ratio]];
      const originImage:V=[q.origin[0],ratio*q.origin[1]+leftIntercept+shear*(q.origin[0]-left)];
      addSupport(q,matrix,originImage,ratio,source,vertices(q).map(v=>{if(v[0]===left)return L.map(v[1]);if(v[0]===right)return R.map(v[1]);throw Error('Unresolved interior trapezoid vertex');}));affineFastPaths++;continue;
     }
    }
    while(m+1<a.length||n+1<b.length){
     const takeLeft=n+1===b.length||(m+1<a.length&&(a[m+1]-a[0])/(a.at(-1)!-a[0])<=(b[n+1]-b[0])/(b.at(-1)!-b[0]));
     const v:[V,V,V]=[[left,a[m]],[right,b[n]],takeLeft?[left,a[m+1]]:[right,b[n+1]]];
     addTriangle(v,[L.map(a[m]),R.map(b[n]),takeLeft?L.map(a[m+1]):R.map(b[n+1])],source);
     if(takeLeft)m++;else n++;
    }
   }
   // A column initially filled with rock can create accommodation at its top.
   // This is untracked water, not new sediment or an inferred grain flux.
   const wl=L.map(0),wr=R.map(0),H=Math.max(wl,wr);
   if(H>0){const support=rectangle(left,0,right-left,H);support.ring=[[0,0],[1,0],[1,wr/H],[0,wl/H]];support.vertexX=[left,right,right,left];support.vertexZ=[0,0,wr,wl];const A=measure(support).area;
    if(A>0){out.push({support,bed:-1,solid:0,fraction:0,burial:0,loading:0});ownership.push(-1);oldAreas.push(0);outSlab.push(currentSlab);addedWaterArea+=A;}}
  }
 }
 // Largest-slice residual closes each original grain budget, preserving small
 // positive children instead of assigning the cancellation residual to them.
 let maxGrainRoundoff=0;
 for(let n=0;n<pieces.length;n++){
  const ids=sourceOutputs[n];if(!ids.length){if(pieces[n].solid!==0)throw Error('Lost material during column decomposition');continue;}
  const sum=sourceAreas[n];if(Math.abs(sum-area[n])>EPS*Math.max(sum,area[n]))throw Error('Local decomposition does not partition source support');
  if(pieces[n].solid===0)continue;ids.sort((a,b)=>oldAreas[a]-oldAreas[b]);let allocated=0;
  for(let j=0;j<ids.length;j++){const i=ids[j],s=j+1===ids.length?pieces[n].solid-allocated:pieces[n].solid*(oldAreas[i]/area[n]);maxGrainRoundoff=Math.max(maxGrainRoundoff,Math.abs(s-out[i].solid));if(s<0)throw Error('Negative grain allocation');out[i].solid=s;allocated+=s;}
 }
 let integratedConstitutiveError=0,rockArea=0,maxConstitutiveError=0;
 out.forEach((p,i)=>{const n=ownership[i];if(n<0||p.bed<0)return;const m=measure(p.support),slab=slabs[outSlab[i]];
  const floor=interp(slab.mappedSurfaceLeft,slab.mappedSurfaceRight,(m.centroid[0]-slab.left)/(slab.right-slab.left)),d=Math.max(0,m.centroid[1]-floor);
  if(compact){p.burial=Math.max(p.burial,d);p.loading=Math.max(p.loading,checkedDepth(d));
   const expected=Math.max(rho[n],1-porosity(pieces[n],d)),actual=p.solid/m.area,error=Math.abs(actual-expected);
   integratedConstitutiveError+=m.area*error;rockArea+=m.area;maxConstitutiveError=Math.max(maxConstitutiveError,error);
  }
  if(p.solid>m.area*(1+EPS))throw Error('Grain area exceeds final material support');
 });
 const meanConstitutiveError=rockArea?integratedConstitutiveError/rockArea:0;
 if(options.constitutiveTolerance!==undefined&&meanConstitutiveError>options.constitutiveTolerance)throw Error(`Constitutive closure residual ${meanConstitutiveError} exceeds tolerance`);
 const mapPoint=(r:MapRegion,p:V):V=>[p[0],r.originImage[1]+r.matrix[1][0]*(p[0]-r.support.origin[0])+r.matrix[1][1]*(p[1]-r.support.origin[1])];
 const mapSegments=(segments:readonly (readonly [V,V])[])=>segments.flatMap(([a,b])=>{
  if(![...a,...b].every(finite)||[a,b].some(p=>p[0]<x0||p[0]>xmax||p[1]<0||p[1]>zmax))throw Error('Fault segment outside physical domain');
  const hits:{lo:number;hi:number;start:V;end:V;region:MapRegion}[]=[];
  const selected=new Set<number>();for(let i=Math.max(0,Math.floor((Math.min(a[0],b[0])-x0)/h)-1);i<=Math.min(nx-1,Math.floor((Math.max(a[0],b[0])-x0)/h));i++)for(const r of regionBins[i])selected.add(r);
  for(const index of selected){const r=regions[index],polygon=vertices(r.support);let lo=0,hi=1;
   for(let j=0;j<polygon.length;j++){const p=polygon[j],q=polygon[(j+1)%polygon.length],cross=(v:V)=>(q[0]-p[0])*(v[1]-p[1])-(q[1]-p[1])*(v[0]-p[0]);const fa=cross(a),fb=cross(b);
    if(fa<0&&fb<0){lo=1;hi=0;break;}if(fa<0)lo=Math.max(lo,fa/(fa-fb));if(fb<0)hi=Math.min(hi,fa/(fa-fb));}
   if(hi>lo){const start:V=[interp(a[0],b[0],lo),interp(a[1],b[1],lo)],end:V=[interp(a[0],b[0],hi),interp(a[1],b[1],hi)];hits.push({lo,hi,start:mapPoint(r,start),end:mapPoint(r,end),region:r});}
  }
  hits.sort((a,b)=>a.lo-b.lo||a.hi-b.hi);const result:[V,V][]= [];let last=0;
  for(const hit of hits){if(hit.hi<=last)continue;if(hit.lo>last)throw Error('Fault segment has an unowned interval');
   // Positive source intervals are never discarded by a geometric tolerance.
   // Shared-edge candidates may overlap; own only their as-yet-unmapped suffix.
   const start=hit.lo===last?hit.start:mapPoint(hit.region,[interp(a[0],b[0],last),interp(a[1],b[1],last)]);
   if(result.length){const previous=result.at(-1)![1];if(Math.hypot(previous[0]-start[0],previous[1]-start[1])>EPS*Math.max(1,zmax,xmax-x0))throw Error('Discontinuous common fault map');}
   result.push([start,hit.end]);last=hit.hi;}
  if(last<1)throw Error('Fault segment not fully mapped');return result;
 });
 return {pieces:out,faces:[...faceCache.values()].sort((a,b)=>a.x-b.x),slabs,regions,mapSegments,
  diagnostics:{inputPieces:pieces.length,outputPieces:out.length,affineFastPaths,slabs:slabs.length,regions:regions.length,maxCoverageDefect,minDeterminant,collapsedWaterArea,addedWaterArea,maxGrainRoundoff,meanConstitutiveError,maxConstitutiveError,constitutiveAccepted:options.constitutiveTolerance===undefined?null:true,closure:'shared-face least-contraction envelope with conforming affine triangulation',unresolvedSubUlpInterfaces:'explicit rejection; chart-node mesh required'}};
}
