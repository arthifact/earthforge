import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
const { outputFiles } = await build({ stdin: { contents: `export * from '../src/ownedSurface'; export * from '../src/geometricSupport'; export * from '../src/ownedProfiles';`, resolveDir: new URL('.', import.meta.url).pathname }, bundle: true, format: 'esm', platform: 'node', write: false });
const api = await import(`data:text/javascript;base64,${Buffer.from(outputFiles[0].contents).toString('base64')}`);
const { rectangle, measure, ownedProfile, trapezoid, surfaceFacets, subsideOwned, erodeOwned, depositOwned, initializeOwned } = api;
const piece = (support, bed = 0, density = .5) => ({ support, bed, solid: bed >= 0 ? density * measure(support).area : 0, fraction: .3, burial: 20, loading: 10 });
const near = (a, b, tol = 1e-9) => assert.ok(Math.abs(a - b) <= tol, `${a} != ${b}`);
const grain = ps => ps.reduce((s, p) => s + p.solid, 0);
const area = ps => ps.reduce((s, p) => s + measure(p.support).area, 0);
const domain = { h: 10, x0: 0, xmax: 20, zmax: 200 };
const physics = { porosity: () => .5, effectiveDepth: d => d };

test('initial ownership rejects a translated-center reconstruction', () => {
  assert.throws(() => initializeOwned([[{ bed: 0, height: 200, solid: 100, fraction: .3, burial: 20, loading: 10, offsetX: 1, offsetZ: 0 }]], { ...domain, xmax: 10 }), /Cannot reconstruct/);
});
test('a sloping exposed bed supplies its actual linear surface', () => {
  const ps = [piece(trapezoid(0, 20, 20, 60, 180, 140))];
  const facets = surfaceFacets(ps, domain);
  assert.deepEqual(facets, [{ left: 0, right: 10, topLeft: 20, topRight: 40 }, { left: 10, right: 20, topLeft: 40, topRight: 60 }]);
});
test('partial-width accommodation creates no sediment on the exposed half', () => {
  const ps = [piece(rectangle(0, 0, 10, 200), -2), piece(rectangle(10, 0, 10, 100), -1), piece(rectangle(10, 100, 10, 100), -2)];
  const next = depositOwned(ps, domain, { first: 0, count: 1, fill: .8, drape: 0, base: () => 0, fraction: () => .3, beds: [{ carbonate: false }], pressure: null, physics });
  near(grain(next.deposited), 400); near(area(next.pieces), 4000);
  assert.equal(ownedProfile(next.pieces, 5).some(p => p.piece.bed >= 0), false);
  near(ownedProfile(next.pieces, 15).filter(p => p.piece.bed >= 0).reduce((s, p) => s + p.height, 0), 80);
});
test('deposition splits sea-level and base-level switches geometrically', () => {
  const ps = [piece(trapezoid(0, 20, 0, 100, 200, 100), -2), piece(trapezoid(0, 20, 0, 0, 0, 100), -1)];
  const next = depositOwned(ps, domain, { first: 0, count: 2, fill: .8, drape: 10, base: () => 50, fraction: () => .3, beds: [{ carbonate: false }, { carbonate: false }], pressure: null, physics });
  near(area(next.pieces), 4000);
  // Integral: triangle 10 + rectangle 80 + trapezoid 300 = 390 m².
  near(grain(next.deposited), 195);
  for (const x of [1, 5, 9, 11, 15, 19]) {
    const col = ownedProfile(next.pieces, x); near(col.reduce((s, p) => s + p.height, 0), 200);
    for (let j = 1; j < col.length; j++) near(col[j - 1].bottom, col[j].top);
  }
});
test('affine subsidence accounts clipped sediment and preserves solid composition', () => {
  const ps = [piece(rectangle(0, 0, 20, 200))], frozen = JSON.stringify(ps);
  const q = subsideOwned(ps, domain, { atLeft: 10, gradient: 1 });
  near(grain(q.pieces) + grain(q.outflowBottom), grain(ps)); near(grain(q.outflowBottom), 200);
  near(area(q.pieces), 4000); assert.equal(JSON.stringify(ps), frozen);
  assert.deepEqual(q.mapPoint([5, 10]), [5, 25]);
  for (const p of q.pieces.filter(p => p.bed >= 0)) { assert.equal(p.fraction, .3); assert.equal(p.burial, 20); assert.equal(p.loading, 10); }
});
test('erosion uses the clipped support rather than an area-equivalent column', () => {
  const ps = [piece(trapezoid(0, 20, 0, 100, 200, 100)), piece(trapezoid(0, 20, 0, 0, 0, 100), -1)];
  const q = erodeOwned(ps, domain, 50);
  near(grain(q.eroded), 125); near(grain(q.pieces) + grain(q.eroded), grain(ps)); near(area(q.pieces), 4000);
});
test('thin positive surface trapezoids retain area and profile thickness', () => {
  const support = trapezoid(0, 20, 2000, 2100, 1e-18, 2e-18);
  assert.ok(support); near(measure(support).area, 3e-17, 1e-30);
  const section = ownedProfile([piece(support)], 10)[0]; near(section.height, 1.5e-18, 1e-30);
});
