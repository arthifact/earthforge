import assert from 'node:assert/strict';
import {test} from 'node:test';
import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
import {readFile} from 'node:fs/promises';
const here=fileURLToPath(new URL('.',import.meta.url));
await build({stdin:{contents:'export * from "../src/geometricSupport"; export {boundaryGhostRectangle} from "../src/domainThrust"; export {flowLine,flowMove,flowAreaDisplacement} from "../src/basin";',resolveDir:here},bundle:true,platform:'node',format:'esm',outfile:here+'geometricSupport-bundle.mjs'});
const a=await import('./geometricSupport-bundle.mjs');
const near=(x,y,atol=2e-9)=>assert.ok(Math.abs(x-y)<=atol,`${x} != ${y}`);
const sum=(pieces)=>pieces.reduce((s,p)=>s+a.measure(p).area,0);
const centroid=pieces=>{let area=0,x=0,z=0;for(const p of pieces){const m=a.measure(p);area+=m.area;x+=m.area*m.centroid[0];z+=m.area*m.centroid[1];}return[x/area,z/area];};
const fault=[[-3000,700],[-1600,700],[-1400,500],[400,500]];
const depth=x=>x<=-1600?700:x>=-1400?500:700-(x+1600);
const payload=support=>({support,bed:7,solid:a.measure(support).area*.57,fraction:.37,burial:80,loading:60});
test('boundary-anchored ghost charts eliminate the exact contact-only admission witness',async()=>{
  const witness=JSON.parse(await readFile(new URL('horizontal-support-witness.json',import.meta.url),'utf8'));
  const {transported,domain}=witness.minimal;
  assert.equal(transported.xBounds[1],domain.x0);
  assert(a.measure(a.intersectBox(transported,domain.x0,0,domain.xmax,domain.zmax)).area>0,'old far-face anchor must reproduce the positive local-chart sliver');
  const source=witness.minimal.source.support,halo=source.axes[0][0];
  const anchored=a.boundaryGhostRectangle('left',domain,halo,source.origin[1],source.axes[1][1]);
  assert.equal(anchored.origin[0],domain.x0);assert.equal(a.measure(anchored).area,a.measure(source).area);
  const stationary=a.cutFault(anchored,witness.minimal.faultGraph).footwall;
  assert(stationary.length>0);
  for(const p of stationary)assert.equal(a.intersectBox(p,domain.x0,0,domain.xmax,domain.zmax),null);
  const top=a.boundaryGhostRectangle('top',domain,halo);
  assert.equal(a.intersectBox(top,domain.x0,0,domain.xmax,domain.zmax),null);
});
test('exact boundary exclusion preserves positive arbitrarily thin and unresolved chart extents',()=>{
  for(const width of[1e-18,1e-100,1e-250]){
    const resolved=a.rectangle(0,0,width,1),half=a.halfPlane(resolved,[1,0],[width/2,0]);
    assert(half);near(a.measure(half).area/width,.5,1e-14);
    const unresolved=a.rectangle(1,0,width,1),inside=a.intersectBox(unresolved,0,0,2,1);
    assert(inside);assert.equal(a.measure(inside).area,width);
  }
});
test('axis-aligned clipping honors exact declared vertex coordinates without outside-domain slivers',()=>{
  const p={origin:[.1,.1],axes:[[.2,0],[0,.2]],ring:[[1,1],[99.5,1],[99.5,3],[1,3]],jacobian:.04,xBounds:[.3,20],zBounds:[.3,.7],vertexX:[.3,20,20,.3],vertexZ:[.3,.3,.7,.7]};
  assert((p.origin[0]-20)+p.axes[0][0]*99.5>0,'raw chart predicate must reproduce false outside-domain contact');
  assert.equal(a.halfPlane(p,[1,0],[20,0]),null);
  assert.equal(a.halfPlane(p,[0,1],[0,.7]),null);
  assert.equal(a.halfPlane(p,[-1,0],[.3,0]),null);
  assert.equal(a.halfPlane(p,[0,-1],[0,.3]),null);
  const cells=a.cellIntersections(p,20,0,0);assert.equal(cells.length,1);assert.equal(cells[0].i,0);assert.equal(cells[0].k,0);
  assert.equal(a.measure(cells[0].support).area,a.measure(p).area);
});
for(const h of[40,20,10]){
  test(`owned support remains HW through two slips and conserves grains at ${h} m`,()=>{
    const H=h/40,margin=h/320,upperX=5*h,upperZ=20*h,lowerZ=25*h,sourceX=-h,top=lowerZ-margin-H;
    const P=[[-25*h,lowerZ],[0,lowerZ],[upperX,upperZ],[25*h,upperZ]],F=a.flowLine(P),firstSlip=h+upperX*Math.SQRT2;
    const source=a.rectangle(sourceX-h/2,top,h,H),p=payload(source),snapshot=structuredClone(p);
    const first=a.transportPiece(p,F,firstSlip),second=first.flatMap(q=>a.transportPiece(q,F,h));
    const remainingFW=first.flatMap(q=>a.cutFault(q.support,P).footwall);
    near(sum(remainingFW),0,1e-9);
    near(first.reduce((s,q)=>s+q.solid,0),p.solid);
    near(second.reduce((s,q)=>s+q.solid,0),p.solid);
    near(sum(first.map(q=>q.support)),h*H);near(sum(second.map(q=>q.support)),h*H);
    for(const q of [...first,...second]) for(const key of['bed','fraction','burial','loading'])assert.equal(q[key],p[key]);
    assert.deepEqual(p,snapshot);
    const got=centroid(second.map(q=>q.support));
    near(got[0],upperX+h);near(got[1],upperZ-margin-H/2);
    const m=centroid(first.map(q=>q.support));
    const c=Math.SQRT2-1,beta=1-1/Math.SQRT2,D=margin+H/2,D2=margin*margin+margin*H+H*H/3,Q=h/8+c*D/2+c*c*D2/(2*h);
    near(m[0],upperX-c*beta*D+beta*Q);near(m[1],upperZ-(1+c/Math.SQRT2)*D+Q/Math.SQRT2);
    assert.ok(m[0]>upperX&&m[1]-H/2>upperZ,'fixture centroid interval must be entirely FW though actual support is HW');
    const intersections=second.flatMap(q=>a.cellIntersections(q.support,h,-2000));
    near(sum(intersections.map(q=>q.support)),h*H);
    const projected=centroid(intersections.map(q=>q.support));near(projected[0],got[0]);near(projected[1],got[1]);
  });
  test(`intersection remap preserves a sub-ULP-thick positive bed at ${h} m`,()=>{
    const p=a.rectangle(-1720-h/2,699,h,1e-18),F=a.flowLine(fault),moved=a.deformHangingWall(p,F,120+200*Math.SQRT2);
    assert.ok(moved.length>0);near(sum(moved)/(h*1e-18),1,1e-12);
    const splits=moved.flatMap(q=>a.cellIntersections(q,h,-2000));assert.ok(splits.length>0);near(sum(splits.map(q=>q.support))/(h*1e-18),1,1e-10);
  });
}
test('true fault cut splits a rectangle across the lower bend with analytical areas',()=>{
  const source=a.rectangle(-1610,680,40,40),cut=a.cutFault(source,fault);
  near(sum(cut.hangingWall),400);near(sum(cut.footwall),1200);near(sum([...cut.hangingWall,...cut.footwall]),1600);
});
test('zero slip preserves support and independent payload storage exactly',()=>{
  const p=payload(a.rectangle(-1700,650,20,3)),got=a.transportPiece(p,a.flowLine(fault),0);
  assert.deepEqual(got,[p]);assert.notEqual(got[0].support,p.support);assert.notEqual(got[0].support.ring,p.support.ring);
});
test('reflected thrust direction gives reflected identical geometry',()=>{
  const source=a.rectangle(-1730,698,20,2),left=a.deformHangingWall(source,a.flowLine(fault),120+200*Math.SQRT2);
  const mirrored={...source,origin:[-source.origin[0],source.origin[1]],axes:source.axes.map(([x,z])=>[-x,z])};
  const right=a.deformHangingWall(mirrored,a.flowLine(fault.map(([x,z])=>[-x,z])),120+200*Math.SQRT2);
  const l=centroid(left),r=centroid(right);near(l[0],-r[0]);near(l[1],r[1]);near(sum(left),sum(right));
});
test('a compaction affine map transports support and an embedded fault marker together',()=>{
  const p=a.rectangle(10,30,20,8),marker=[.3,.6],point=a.world(p,marker);
  const M=[[1,0],[.1,.5]],moved=a.affineMap(p,M,[10,116]);
  const movedPoint=a.world(moved,marker);near(movedPoint[0],point[0]);near(movedPoint[1],100+.1*point[0]+.5*point[1]);
  near(a.measure(moved).area,a.measure(p).area*.5);
  assert.throws(()=>a.affineMap(p,[[1,0],[0,-1]],[0,0]),/inverted/);
});
test('cell overlay conserves area and first moments under arbitrary affine shear',()=>{
  const p=a.rectangle(13,7,57,19),mapped=a.affineMap(p,[[1,.4],[0,1]],[15.8,7]);
  for(const h of[40,20,10]){const q=a.cellIntersections(mapped,h);near(sum(q.map(r=>r.support)),57*19);const expected=a.measure(mapped).centroid,got=centroid(q.map(r=>r.support));near(got[0],expected[0]);near(got[1],expected[1]);}
});
test('random affine-region partitions preserve total area and independent first moments',()=>{
  let seed=27371;const rng=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  for(let trial=0;trial<200;trial++){
    const F=a.flowLine(fault),w=1+rng()*80,H=.01+rng()*25,x=-1700+rng()*260,top=400+rng()*30,s=-100+rng()*700;
    const p=a.rectangle(x-w/2,top,w,H),parts=a.deformHangingWall(p,F,s),got=centroid(parts),d=a.flowAreaDisplacement(F,s,w)(x,top,H);
    near(sum(parts),w*H,Math.max(1e-9,w*H*1e-12));near(got[0],x+d[0]);near(got[1],top+H/2+d[1]);
    near(sum(parts.flatMap(q=>a.cutFault(q,fault).footwall)),0,1e-7);
  }
});
