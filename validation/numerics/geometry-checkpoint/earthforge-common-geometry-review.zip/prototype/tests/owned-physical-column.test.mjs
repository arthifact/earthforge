import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=process.env.EARTHFORGE_SOURCE??fileURLToPath(new URL('..',import.meta.url));
const require=createRequire(path.join(process.env.EARTHFORGE_DEPENDENCIES??root,'package.json'));
const {build}=require('esbuild');
const compiled=await build({stdin:{contents:'export * from "./src/commonColumnCompaction";export * from "./src/strata";',resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const {compactPhysicalColumn,emptyLayer,layerLengths,withLayerLengths}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].contents).toString('base64'));
const beds=[{carbonate:false},{carbonate:true}];
const law={porosity:()=>.5,effectiveDepth:d=>d};
const near=(a,b,t=2e-8)=>assert.ok(Math.abs(a-b)<t,`${a} != ${b}`);
const p=(bed,height,solid,offsetZ=0)=>({bed,height,solid,fraction:.37,burial:80,loading:60,offsetX:0,offsetZ});
function stack(scale=1,compact=true){return [emptyLayer(-1,100*scale),p(1,100*scale,(compact?25:50)*scale,100*scale),p(0,100*scale,50*scale,-100*scale),emptyLayer(-2,700*scale)];}
function physicalParts(c){let z=0;return c.flatMap(q=>{const a=z+q.offsetZ;z+=q.height;return q.bed===-1?[]:[{...q,top:a,bottom:a+q.height}];});}
// An independent exact-binary oracle, at the binary64 minimum exponent.
function units(x){const view=new DataView(new ArrayBuffer(8));view.setFloat64(0,x);const bits=view.getBigUint64(0),e=Number((bits>>52n)&2047n),m=bits&((1n<<52n)-1n);return (e?m+(1n<<52n):m)<<BigInt(e?e-1:0);}
const support=c=>c.reduce((a,q)=>a+layerLengths(q).reduce((b,h)=>b+units(h),0n),0n);

test('one physical map keeps the independent two-bed material/fault ordering at40/20/10m',()=>{
 for(const h of[40,20,10]){
  const s=h/40,c=stack(s),copy=structuredClone(c),r=compactPhysicalColumn(c,1000*s,beds,null,law),parts=physicalParts(r.column);
  assert.deepEqual(c,copy);assert.deepEqual(r.sourceOrder,[2,1,3]);
  near(r.oldSurface,100*s);near(r.newSurface,150*s);
  near(parts[0].top,150*s);near(parts[0].bottom,250*s);
  near(parts[1].top,250*s);near(parts[1].bottom,300*s);
  near(r.mapDepth(290*s),295*s);near(r.mapDepth(289*s),294.5*s);
  near(r.mapDepth(290*s)-r.mapDepth(289*s),.5*s);
  near(r.mapDepth(100*s),parts[0].top);near(r.mapDepth(200*s),parts[0].bottom);near(r.mapDepth(300*s),parts[1].bottom);
  for(const original of c.filter(q=>q.bed>=0)){
   const moved=parts.find(q=>q.bed===original.bed);
   assert.equal(moved.solid,original.solid);assert.equal(moved.fraction,original.fraction);
   assert.ok(moved.loading>=original.loading&&moved.burial>=original.burial);
   near(moved.solid/moved.height,.5);
  }
  assert.equal(support(r.column),units(1000*s));
 }
});

test('gauge-equivalent storage orders have identical constitutive output and physical maps',()=>{
 const shuffled=stack(),ordered=[emptyLayer(-1,100),{...shuffled[2],offsetZ:0},{...shuffled[1],offsetZ:0},emptyLayer(-2,700)];
 const pressureLaw={porosity:(fraction,d,carbonate)=>(carbonate?.35:.48)*Math.exp(-d/500),effectiveDepth:(d,p)=>d*(1-(p??0))};
 const a=compactPhysicalColumn(shuffled,1000,beds,.3,pressureLaw),b=compactPhysicalColumn(ordered,1000,beds,.3,pressureLaw);
 assert.deepEqual(a.column,b.column);
 for(let z=0;z<=1000;z+=2.5)assert.equal(a.mapDepth(z),b.mapDepth(z));
});

test('identity compaction preserves physical positions including arbitrary valid storage permutation',()=>{
 const c=stack(1,false),before=physicalParts(c).sort((a,b)=>a.top-b.top),r=compactPhysicalColumn(c,1000,beds,null,law),after=physicalParts(r.column);
 for(let j=0;j<before.length;j++){
  near(after[j].top,before[j].top);near(after[j].bottom,before[j].bottom);
  assert.equal(after[j].solid,before[j].solid);assert.equal(after[j].fraction,before[j].fraction);
 }
 for(let z=0;z<=1000;z+=.5)near(r.mapDepth(z),z,1e-12);
});

test('invalid physical support is rejected without overlap repair, clipping, or boundary grain loss',()=>{
 const overlap=stack();overlap[2].offsetZ=-99;assert.throws(()=>compactPhysicalColumn(overlap,1000,beds,null,law),/Overlapping/);
 const gap=stack();gap[2].height=99;gap[3].height=701;assert.throws(()=>compactPhysicalColumn(gap,1000,beds,null,law),/gap/);
 const top=stack();top[2].offsetZ=-201;assert.throws(()=>compactPhysicalColumn(top,1000,beds,null,law),/outside/);
 const bottom=stack();bottom[3].offsetZ=1;assert.throws(()=>compactPhysicalColumn(bottom,1000,beds,null,law),/outside/);
 const bottomGap=stack();bottomGap[3].offsetZ=-1;bottomGap[1].offsetZ=99;bottomGap[2].offsetZ=-101;assert.throws(()=>compactPhysicalColumn(bottomGap,1000,beds,null,law),/bottom/);
 const lateral=stack();lateral[1].offsetX=.1;assert.throws(()=>compactPhysicalColumn(lateral,1000,beds,null,law),/lateral/);
 assert.throws(()=>compactPhysicalColumn(stack(),1001,beds,null,law),/exactly cover/);
 const r=compactPhysicalColumn(stack(),1000,beds,null,law);
 for(const z of[-1,1001,NaN,Infinity])assert.throws(()=>r.mapDepth(z),/outside/);
});

test('positive2^-40and2^-60beds retain exact boundary ownership and grains under identity compaction',()=>{
 for(const h of[40,20,10])for(const tiny of[2**-40,2**-60]){
  const delta=2**-30,c=[emptyLayer(-1,h-delta),emptyLayer(-1,delta-tiny),p(0,tiny,tiny/2),emptyLayer(-2,h)],copy=structuredClone(c);
  const r=compactPhysicalColumn(c,2*h,beds,null,law),rock=r.column.find(q=>q.bed===0);
  assert.deepEqual(c,copy);assert.equal(rock.height,tiny);assert.equal(rock.solid,tiny/2);assert.equal(support(r.column),units(2*h));
  const j=r.column.indexOf(rock);assert.equal(support(r.column.slice(0,j))+units(tiny),units(h));
 }
});

test('empty water and inert basement are valid identity cases; porosity and invalid material fail explicitly',()=>{
 for(const c of[[emptyLayer(-1,1000)],[emptyLayer(-2,1000)]]){
  const r=compactPhysicalColumn(c,1000,beds,null,law);assert.deepEqual(r.column,c);near(r.mapDepth(333),333);
 }
 for(const value of[-.1,1,Infinity,NaN])assert.throws(()=>compactPhysicalColumn(stack(),1000,beds,null,{...law,porosity:()=>value}),/porosity/);
 assert.throws(()=>compactPhysicalColumn(stack(),1000,beds,null,{...law,effectiveDepth:()=>NaN}),/effective depth/);
 const invalid=stack();invalid[1].solid=-1;assert.throws(()=>compactPhysicalColumn(invalid,1000,beds,null,law),/constituent/);
 const bad=stack();bad[1].lengths=[99];assert.throws(()=>compactPhysicalColumn(bad,1000,beds,null,law),/Inconsistent/);
});

test('common physical map is increasing and two-column interpolation uses that same deformation',()=>{
 const a=compactPhysicalColumn(stack(),1000,beds,null,law),b=compactPhysicalColumn(stack(1,false),1000,beds,null,law);
 let last=-Infinity;for(let z=0;z<=1000;z+=.125){const now=a.mapDepth(z);assert.ok(now>last);last=now;}
 const at=(z,w)=>(1-w)*a.mapDepth(z)+w*b.mapDepth(z);
 for(const w of[0,.25,.5,1])near(at(290,w)-at(289,w),.5+.5*w);
});
