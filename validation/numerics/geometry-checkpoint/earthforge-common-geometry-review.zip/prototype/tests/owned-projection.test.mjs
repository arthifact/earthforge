import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const root=resolve(process.env.EARTHFORGE_SOURCE??fileURLToPath(new URL('..',import.meta.url)));
const require=createRequire(resolve(process.env.EARTHFORGE_DEPENDENCY_ROOT??root,'package.json'));
const {build}=require('esbuild');
const bundle=await build({stdin:{contents:'export * from "./src/ownedProjection";export * from "./src/geometricSupport";export * from "./src/strata";export * from "./src/exactLength";export * from "./src/sedimentBudget";',resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const a=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].contents).toString('base64'));
const {unitAt}=await import(pathToFileURL(resolve(root,'validation/numerics/metrics.mjs')));
const near=(actual,expected,t=2e-12)=>assert.ok(Math.abs(actual-expected)<=t*Math.max(1,Math.abs(expected)),`${actual} != ${expected}`);
const part=(support,bed,density=.5)=>({support,bed,solid:bed<0?0:a.measure(support).area*density,fraction:.37,burial:80.25,loading:60.5});
const exactSum=parts=>{const xs=parts.flatMap(p=>p.lengths??[p.height]),scale=a.exactLengthScale(xs);return {scale,units:xs.reduce((n,x)=>n+scale.units(x),0n)};};
const assertHeight=(parts,end)=>{const xs=parts.flatMap(p=>p.lengths??[p.height]),scale=a.exactLengthScale([...xs,end]);assert.equal(xs.reduce((n,x)=>n+scale.units(x),0n),scale.units(end));};
function assertPayload(p,q){for(const k of['bed','fraction','burial','loading'])assert.equal(q[k],p[k]);}

test('flat full-domain area/raster and physical profiles preserve inventory and all payloads at40/20/10m',()=>{
 for(const h of[40,20,10]){
  const nx=2,nz=2,pieces=[part(a.rectangle(0,0,2*h,h/2),-1),part(a.rectangle(0,h/2,2*h,h/4),0),part(a.rectangle(0,3*h/4,2*h,5*h/4),-2)];
  const before=JSON.stringify(pieces),grid={nx,nz,h,x0:0},out=a.projectOwnedSupport(pieces,grid),profiles=a.physicalProfileColumns(pieces,grid);
  near(out.diagnostics.projectedSolidArea,pieces[1].solid);for(const d of out.diagnostics.adjustments){assert.ok(d.height<=d.limit);assert.ok(d.bed<0);}
  for(const c of out.areaColumns){assertHeight(c,2*h);near(c.filter(p=>p.bed===0).reduce((s,p)=>s+p.height,0),h/4);for(const p of c)assertPayload(pieces.find(q=>q.bed===p.bed),p);}
  for(const c of profiles.profileColumns){assertHeight(c,2*h);near(c.find(p=>p.bed===0).solid,h/8);}
  const rebuilt=a.columnsFromRaster(out.raster,nx,nz,h);near(rebuilt.flat().reduce((s,p)=>s+h*p.solid,0),pieces[1].solid);
  assert.equal(JSON.stringify(pieces),before);
 }
});

test('diagonal partition has conservative area averages and separately measured physical line thickness',()=>{
 for(const h of[40,20,10]){
  const chart={origin:[0,0],axes:[[h,0],[0,h]],jacobian:h*h,xBounds:[0,h]};
  const upper=part({...chart,ring:[[0,0],[1,0],[1,1]]},0),lower=part({...chart,ring:[[0,0],[1,1],[0,1]]},1,.25);
  const out=a.projectOwnedSupport([upper,lower],{nx:1,nz:1,h,x0:0});
  near(out.areaColumns[0].find(p=>p.bed===0).height,h/2);near(out.areaColumns[0].find(p=>p.bed===1).solid,h/8);
  for(const f of[.25,.5,.75]){const q=a.physicalProfileColumn([upper,lower],f*h,h);near(q.column.find(p=>p.bed===0).height,f*h);near(q.column.find(p=>p.bed===1).height,(1-f)*h);}
  // Projection first moments remain explicitly available despite virtual stack order.
  let top=0;for(const p of out.areaColumns[0]){const original=[upper,lower].find(q=>q.bed===p.bed),m=a.measure(original.support);near(h/2+p.offsetX,m.centroid[0]);near(top+p.height/2+p.offsetZ,m.centroid[1]);top+=p.height;}
 }
});

test('one-sided vertical seams are owned exactly once and preserve separate histories',()=>{
 const h=20,left=part(a.rectangle(0,0,h/2,h),0),right=part(a.rectangle(h/2,0,h/2,h),1);right.loading=91;
 const r=a.physicalProfileColumn([left,right],h/2,h,'right'),l=a.physicalProfileColumn([left,right],h/2,h,'left');
 assert.deepEqual(r.column.map(p=>p.bed),[1]);assert.deepEqual(l.column.map(p=>p.bed),[0]);assert.equal(r.column[0].loading,91);
 near(a.projectOwnedSupport([left,right],{nx:1,nz:1,h,x0:0}).diagnostics.projectedSolidArea,h*h/2);
});

test('sub-ULP distinct beds survive projection, raster lifecycle and measured profiles without grain normalization',()=>{
 for(const h of[40,20,10])for(const tiny of[2**-40,2**-60]){
  const base={origin:[0,700],axes:[[h,0],[0,1]],ring:[[0,tiny],[1,tiny],[1,300],[0,300]],jacobian:h,xBounds:[0,h]};
  const pieces=[part(a.rectangle(0,0,h,700),-1),part(a.rectangle(0,700,h,tiny),7),part(base,-2)],before=JSON.stringify(pieces);
  const out=a.projectOwnedSupport(pieces,{nx:1,nz:1000/h,h,x0:0}),profile=a.physicalProfileColumn(pieces,h/2,1000);
  for(const c of[out.areaColumns[0],a.columnsFromRaster(out.raster,1,1000/h,h)[0],profile.column]){
   const retained=c.filter(p=>p.bed===7);assert.equal(retained.length,1);assert.equal(retained[0].height,tiny);assert.equal(retained[0].solid,tiny*.5);assertPayload(pieces[1],retained[0]);assertHeight(c,1000);
  }
  assert.equal(out.diagnostics.projectedSolidArea,pieces[1].solid);assert.equal(JSON.stringify(pieces),before);
  for(const d of out.diagnostics.adjustments){assert.ok(d.height>0&&d.height<=d.limit);assert.ok(d.bed<0);}
 }
});

test('physical profile refuses actual gaps and overlaps including sub-ULP endpoint mismatch',()=>{
 for(const delta of[1,2**-60]){
  const water=part(a.rectangle(0,0,20,700),-1);
  const gap=part({origin:[0,700],axes:[[20,0],[0,1]],ring:[[0,delta],[1,delta],[1,300],[0,300]],jacobian:20,xBounds:[0,20]},-2);
  assert.throws(()=>a.physicalProfileColumn([water,gap],10,1000),/gap/);
  const overlap=part({origin:[0,700],axes:[[20,0],[0,1]],ring:[[0,-delta],[1,-delta],[1,300],[0,300]],jacobian:20,xBounds:[0,20]},-2);
  assert.throws(()=>a.physicalProfileColumn([water,overlap],10,1000),/overlap/);
 }
});

test('domain crossing and missing inventory fail rather than create clipping flux or normalize sediment',()=>{
 assert.throws(()=>a.projectOwnedSupport([part(a.rectangle(-1,0,21,20),0)],{nx:1,nz:1,h:20,x0:0}),/outside/);
 assert.throws(()=>a.projectOwnedSupport([part(a.rectangle(0,0,20,19),0)],{nx:1,nz:1,h:20,x0:0}),/does not (?:fill extent|form a full area partition)/);
 const pieces=[part(a.rectangle(0,0,1,.1),0),part(a.rectangle(0,.1,1,.9),1)];
 assert.throws(()=>a.projectOwnedSupport(pieces,{nx:1,nz:1,h:1,x0:0}),/Sediment-only/);
});

test('declared inert projection corrections cannot remove a tiny interval or repair material-scale errors',()=>{
 // Double coverage is not a full partition; a large residual must fail even
 // though inert material would be available for a misleading normalization.
 const pieces=[part(a.rectangle(0,0,20,20),-1),part(a.rectangle(0,10,20,10),-2)];
 assert.throws(()=>a.projectOwnedSupport(pieces,{nx:1,nz:1,h:20,x0:0}),/does not (?:fill extent|form a full area partition)/);
});

test('frozen interval metrics require physical columns; a partial-width inventory average is a different quantity',()=>{
 const h=20,x0=-2000-h/2,end=10*h,split=x0+.25*h;
 const pieces=[part(a.rectangle(x0,0,h,h),-1),
  part(a.rectangle(x0,h,.25*h,3*h),0),part(a.rectangle(split,h,.75*h,4*h),0),
  part(a.rectangle(x0,4*h,.25*h,6*h),-2),part(a.rectangle(split,5*h,.75*h,5*h),-2)];
 const area=a.projectOwnedSupport(pieces,{nx:1,nz:10,h,x0}).areaColumns;
 const physical=a.physicalProfileColumns(pieces,{nx:1,nz:10,h,x0}).profileColumns;
 const b={h,beds:[{unit:0}],faults:[]},query=columns=>unitAt({...b,columns},-2000,0,()=>2000,[0,end]);
 const p=query(physical),q=query(area);assert.equal(p.status,'matched');near(p.metrics.thickness_m,4*h);near(p.metrics.solid_height_m,2*h);
 assert.equal(q.status,'matched');near(q.metrics.thickness_m,3.75*h);assert.notEqual(p.metrics.thickness_m,q.metrics.thickness_m);
 // The physical columns are line queries, not the source-area inventory.
 near(physical[0].reduce((s,p)=>s+p.solid*h,0),2*h*h);near(pieces.reduce((s,p)=>s+p.solid,0),1.875*h*h);
});


test('direct authoritative inventory and area export agree per bed and component; physical profiles are excluded',()=>{
 const h=20,pieces=[part(a.rectangle(0,0,h,4),-1),part(a.rectangle(0,4,h,3),0,.7),part(a.rectangle(0,7,h,2),1,.6),part(a.rectangle(0,9,h,11),-2)],beds=[{carbonate:false},{carbonate:true}];
 const direct=a.inventoryOfOwnedSupport(pieces,beds),projection=a.projectOwnedSupport(pieces,{nx:1,nz:1,h,x0:0});
 const out=a.inventoryOf({columns:projection.areaColumns,h,beds,...projection.raster});
 near(direct.total,66);near(direct.sand,42*.37);near(direct.shale,42*.63);near(direct.carbonate,24);
 for(const k of['total','sand','shale','carbonate'])near(out[k],direct[k]);
 for(let i=0;i<2;i++){near(out.byBed[i],direct.byBed[i]);for(const k of['sand','shale','carbonate'])near(out.byBedComponents[k][i],direct.byBedComponents[k][i]);}
});

test('repeated immutable export is deterministic and does not accumulate support or physical parcels',()=>{
 const h=20,pieces=[part(a.rectangle(0,0,h,5),-1),part(a.rectangle(0,5,h,7),0),part(a.rectangle(0,12,h,8),-2)],before=JSON.stringify(pieces);
 const expected=a.projectOwnedSupport(pieces,{nx:1,nz:1,h,x0:0});
 for(let j=0;j<100;j++){const q=a.projectOwnedSupport(pieces,{nx:1,nz:1,h,x0:0});assert.deepEqual(q.areaColumns,expected.areaColumns);assert.deepEqual(q.diagnostics,expected.diagnostics);assert.equal(pieces.length,3);assert.equal(JSON.stringify(pieces),before);}
});

test('authoritative tagged shared nodes govern profile seams without rounding untagged thin extents',()=>{
 // The declared cut is x=.3. The right chart reconstructs its first vertex as
 // .1+.2=.30000000000000004. The exact vertex tag, not a tolerance, owns the cut.
 // Likewise the sediment top is the shared node z=.3 while its chart origin
 // plus local depth reconstructs .1+.2. Both histories must survive the seam.
 const chart=(zOrigin,zScale,topLocal,bottomLocal,topWorld,bottomWorld)=>({
  origin:[.1,zOrigin],axes:[[.2,0],[0,zScale]],
  ring:[[1,topLocal],[99.5,topLocal],[99.5,bottomLocal],[1,bottomLocal]],
  jacobian:.2*zScale,xBounds:[.3,20],zBounds:[topWorld,bottomWorld],
  vertexX:[.3,20,20,.3],vertexZ:[topWorld,topWorld,bottomWorld,bottomWorld]
 });
 const left=part(a.rectangle(0,0,.3,20),2);left.loading=14;
 const right=[part(chart(0,.3,0,1,0,.3),-1),part(chart(.1,.2,1,3,.3,.7),7),part(chart(.7,19.3,0,1,.7,20),-2)];
 right[1].loading=91;
 const pieces=[left,...right],before=JSON.stringify(pieces);
 assert.notEqual(.1+.2,.3);assert.notEqual(.1+.2*3,.7);
 const r=a.physicalProfileColumn(pieces,.3,20,'right'),l=a.physicalProfileColumn(pieces,.3,20,'left');
 assert.deepEqual(r.column.map(p=>p.bed),[-1,7,-2]);
 assert.deepEqual(l.column.map(p=>p.bed),[2]);assert.equal(l.column[0].loading,14);
 assert.equal(r.sections[0].bottomWorldNode,.3);assert.equal(r.sections[1].topWorldNode,.3);
 assert.equal(r.sections[1].bottomWorldNode,.7);assert.equal(r.sections[2].topWorldNode,.7);
 const sediment=r.column.find(p=>p.bed===7);near(sediment.height,.4);near(sediment.solid,.2);assert.equal(sediment.loading,91);
 assertHeight(r.column,20);assertHeight(l.column,20);
 const interior=a.physicalProfileColumn(pieces,10,20);near(interior.column.find(p=>p.bed===7).height,.4);
 const projected=a.projectOwnedSupport(pieces,{nx:1,nz:1,h:20,x0:0});
 near(projected.diagnostics.projectedSolidArea,3+19.7*.2);
 assert.equal(JSON.stringify(pieces),before);
 // A sloping shared edge is approached through different charts. The same
 // tagged endpoint pair must give one common interpolated world node, too.
 const upper=part({origin:[0,0],axes:[[20,0],[0,1]],ring:[[0,0],[1,0],[1,.7],[0,.3]],jacobian:20,
  xBounds:[0,20],vertexX:[0,20,20,0],vertexZ:[0,0,.7,.3]},-1);
 const lower=part({origin:[0,.1],axes:[[20,0],[0,.2]],ring:[[0,1],[1,3],[1,4.5],[0,4.5]],jacobian:4,
  xBounds:[0,20],vertexX:[0,20,20,0],vertexZ:[.3,.7,1,1]},3);
 const bottom=part(a.rectangle(0,1,20,19),-2);bottom.support.vertexZ=[1,1,20,20];
 const ramp=[upper,lower,bottom],rampBefore=JSON.stringify(ramp);
 for(const x of[.3,5,10,17]){
  const q=a.physicalProfileColumn(ramp,x,20);
  assert.equal(q.sections[0].bottomWorldNode,q.sections[1].topWorldNode);
  near(q.column.find(p=>p.bed===3).height,.7-.4*x/20);
  near(q.column.find(p=>p.bed===3).solid,.5*(.7-.4*x/20));assertHeight(q.column,20);
 }
 assert.equal(JSON.stringify(ramp),rampBefore);
});
