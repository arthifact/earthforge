import assert from 'node:assert/strict';
import {test} from 'node:test';
import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const here=fileURLToPath(new URL('.',import.meta.url)),root=resolve(process.env.EARTHFORGE_GEOMETRY_SOURCE??resolve(here,'..'));
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourcePaths=['src/ownedSurface.ts','src/geometricSupport.ts','src/ownedProfiles.ts','src/strata.ts','src/exactLength.ts'];
const sourceHashes=Object.fromEntries(sourcePaths.map(p=>[p,sha(resolve(root,p))]));
const {outputFiles}=await build({stdin:{contents:'export * from "./src/ownedSurface";export * from "./src/geometricSupport";export * from "./src/ownedProfiles";export * from "./src/strata";',resolveDir:root},bundle:true,platform:'node',format:'esm',write:false});
const api=await import(`data:text/javascript;base64,${Buffer.from(outputFiles[0].contents).toString('base64')}`);
const {rectangle,measure,ownedProfile,depositOwned,initializeOwned,subsideOwned,erodeOwned}=api;
const near=(a,b,t=1e-11)=>assert.ok(Math.abs(a-b)<=t*Math.max(1,Math.abs(b)),`${a} != ${b}`);
const make=(support,bed,density=.5)=>({support,bed,solid:bed<0?0:density*measure(support).area,fraction:.3,burial:20,loading:10});
const grain=p=>p.reduce((n,q)=>n+q.solid,0),area=p=>p.reduce((n,q)=>n+measure(q.support).area,0);
const physics={porosity:()=>.5,effectiveDepth:d=>d};
const plan=(options={})=>({first:1,count:1,fill:0,drape:0,base:()=>0,fraction:()=>.3,beds:[{carbonate:false},{carbonate:false}],pressure:null,physics,...options});
const row=(bed,height,solid=0)=>({bed,height,solid,fraction:.3,burial:20,loading:10,offsetX:0,offsetZ:0});
const records=[];
function frozen(x){for(const v of Object.values(x))if(v&&typeof v==='object')frozen(v);return Object.freeze(x);}

test('deposition rejects a pre-existing internal water gap instead of silently removing its support',()=>{
 const d={h:20,x0:0,xmax:20,zmax:200},pieces=[make(rectangle(0,0,20,10),-1),make(rectangle(0,10,20,10),0),make(rectangle(0,20,20,10),-1),make(rectangle(0,30,20,170),-2)];
 let out,error;try{out=depositOwned(frozen(pieces),d,plan());}catch(e){error=e.message;}
 records.push({case:'internal-water',beforeArea:area(pieces),afterArea:out?area(out.pieces):null,beforeGrains:grain(pieces),afterGrains:out?grain(out.pieces):null,depositedGrains:out?grain(out.deposited):null,rejected:!!error,error});
 assert.ok(error,'Internal water must be explicitly rejected until a collapse map has removed it');
});

test('initialization either preserves a positive sub-ULP layer boundary or rejects its unsupported coordinates',()=>{
 for(const tiny of[2**-40,2**-60]){
  const d={h:20,x0:0,xmax:20,zmax:1000},column=[row(-1,700),row(0,tiny,tiny/2),row(-2,300)];
  // Grouped exact support is1000: the basement is the exact complement.
  // withLayerLengths uses a positive expansion; choose an exact signed slice
  // of a300m basement so the input topology is a valid full-domain column.
  column[2]=api.sliceColumn([row(-2,300)],[tiny],300)[0];
  const before=structuredClone(column);let out,error;try{out=initializeOwned([column],d);}catch(e){error=e.message;}
  const sections=out?ownedProfile(out,10):[];const bed=sections.find(q=>q.piece.bed===0),base=sections.find(q=>q.piece.bed===-2);
  const gap=bed&&base?(base.originZ-bed.originZ)+(base.topOffset-bed.bottomOffset):null;
  records.push({case:'initial-thin',tiny,error,rejected:!!error,taggedArea:out?.filter(q=>q.bed===0).reduce((n,q)=>n+measure(q.support).area,0),taggedSolid:out?.filter(q=>q.bed===0).reduce((n,q)=>n+q.solid,0),gapAfterTag:gap});
  assert.deepEqual(column,before);
  if(!error){assert.ok(bed&&base);assert.equal(bed.height,tiny);assert.equal(bed.solidHeight,tiny/2);assert.equal(gap,0,'Initialization made the subsequent interval overlap a retained tiny bed');}
 }
});

test('initialization rejects incomplete horizontal domain coverage',()=>{
 const d={h:20,x0:0,xmax:40,zmax:1000};let error;
 try{initializeOwned([[row(-1,700),row(-2,300)]],d);}catch(e){error=e.message;}
 records.push({case:'initial-width',expectedArea:40000,rejected:!!error,error});assert.ok(error,'One20m column cannot initialize a40m domain');
});

test('a positive thin drape is preserved or explicitly rejected, never reported as zero deposition',()=>{
 for(const tiny of[2**-40,2**-60]){
  const d={h:20,x0:0,xmax:20,zmax:1000},pieces=[make(rectangle(0,0,20,700),-1),make(rectangle(0,700,20,300),-2)];let out,error;
  try{out=depositOwned(frozen(pieces),d,plan({drape:tiny}));}catch(e){error=e.message;}
  const expectedSolid=20*tiny*.5,actual=out?grain(out.deposited):null;
  records.push({case:'thin-drape',tiny,expectedSolid,actualSolid:actual,rejected:!!error,error});
  if(!error){assert.ok(actual>0,'Positive requested drape silently disappeared');near(actual/expectedSolid,1,1e-12);}
 }
});

test('affine-only subsidence cannot use a nonlinear point map while polygons undergo a different affine map',()=>{
 const d={h:20,x0:0,xmax:20,zmax:200},pieces=[make(rectangle(0,0,20,200),0)],shift=x=>10+Math.sin(Math.PI*x/10);let out,error;
 try{out=subsideOwned(frozen(pieces),d,shift);}catch(e){error=e.message;}
 // Endpoints and midpoint match an affine translation, quarter-points do not.
 const actualSurface=out?ownedProfile(out.pieces,5).find(q=>q.piece.bed===0)?.top:null,mapSurface=out?.mapPoint([5,0])[1];
 records.push({case:'nonlinear-subsidence',actualSurface,mapSurface,rejected:!!error,error});
 if(!error)assert.equal(actualSurface,mapSurface,'Material and marker received different maps');
});

test('independent sloping-accommodation integral, per-bed grains and source immutability',()=>{
 for(const h of[40,20,10]){
  const d={h,x0:0,xmax:h,zmax:200},support={origin:[0,0],axes:[[h,0],[0,1]],ring:[[0,20],[1,60],[1,200],[0,200]],jacobian:h,xBounds:[0,h]};
  const water={origin:[0,0],axes:[[h,0],[0,1]],ring:[[0,0],[1,0],[1,60],[0,20]],jacobian:h,xBounds:[0,h]};
  const pieces=[make(water,-1),make(support,-2)],before=JSON.stringify(pieces);
  const p=plan({first:0,count:2,fill:.8,base:()=>40,beds:[{carbonate:false},{carbonate:true}],fraction:id=>id===0?.2:.8});
  const out=depositOwned(frozen(pieces),d,p);
  // Positive accommodation is a triangle on the right half: integral=5h;
  // fill.8 and grain density.5 yield2h total, split equally between beds.
  near(grain(out.deposited),2*h);near(area(out.pieces),200*h);
  for(const id of[0,1]){const selected=out.deposited.filter(q=>q.bed===id);near(grain(selected),h);for(const q of selected)assert.equal(q.fraction,id===0?.2:.8);}
  assert.equal(JSON.stringify(pieces),before);
 }
});

test('erosion and affine subsidence preserve independent grain accounts and frozen input payloads',()=>{
 const d={h:20,x0:0,xmax:20,zmax:200},pieces=[make(rectangle(0,0,20,200),0,.3)],before=JSON.stringify(pieces);frozen(pieces);
 const erosion=erodeOwned(pieces,d,30);near(grain(erosion.eroded),180);near(grain(erosion.pieces),1020);near(area(erosion.pieces),4000);
 const sub=subsideOwned(pieces,d,{atLeft:10,gradient:1});near(grain(sub.outflowBottom),120);near(grain(sub.pieces),1080);near(area(sub.pieces),4000);
 assert.equal(JSON.stringify(pieces),before);
 for(const q of[...erosion.eroded,...erosion.pieces,...sub.outflowBottom,...sub.pieces].filter(q=>q.bed>=0)){assert.equal(q.fraction,.3);assert.equal(q.burial,20);assert.equal(q.loading,10);}
});

test('polygon water guard detects below-surface support even when the water centroid is above its local surface',()=>{
 const d={h:10,x0:0,xmax:20,zmax:200};
 const pieces=[make(rectangle(0,0,10,10),-1),make(rectangle(0,10,10,10),0),
  make(rectangle(0,20,20,10),-1),make(rectangle(10,0,10,20),-1),make(rectangle(10,30,10,70),-1),
  make(rectangle(0,30,10,170),-2),make(rectangle(10,100,10,100),-2)];
 near(area(pieces),4000);const sharedWater=pieces[2],centroid=measure(sharedWater.support).centroid;
 assert.deepEqual(centroid,[10,25]);assert.ok(centroid[1]<100,'Right-sided centroid is above100m exposed surface');
 assert.throws(()=>depositOwned(frozen(pieces),d,plan()),/internal-water/);
});

test('save bounded independent review evidence',()=>{for(const p of sourcePaths)assert.equal(sha(resolve(root,p)),sourceHashes[p]);writeFileSync(resolve(here,'evidence.json'),JSON.stringify({schema:'earthforge.owned-surface-independent-review.v1',sourceRoot:root,sourceHashes,records,scope:'Analytical fixtures only. No original writes, observations/holdout or simulations.'},null,2)+'\n');});
