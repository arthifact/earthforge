EarthForge common geometry review — INCOMPLETE REPAIR

The original repository was not modified. These experimental modules are isolated
in prototype/. The simulate() function still follows the previous implementation.
Do not infer a production repair or improved convergence from this package.

To run the new focused checks from prototype/ with Node.js installed:
  npm ci
  node --test tests/owned-*.test.mjs
  npm run check

The full 40/20/10 m study under control/ is an unchanged baseline rerun.
Its50 JSON files are byte-identical to the current stored comparison.
The experimental geometric path has only analytical tests and a first-thrust
coupled-case admission probe; it has not completed the full comparison.

No observational or holdout data is included. The two FORCE files in prototype/
are the specifically allowed source/plan metadata used by the frozen tests.
The evidence archive preserves failure witnesses and source hashes. Some original
witness scripts retain workspace-relative paths; the consolidated tests above
are the portable entry point. Read earthforge-common-geometry-status.html first.
